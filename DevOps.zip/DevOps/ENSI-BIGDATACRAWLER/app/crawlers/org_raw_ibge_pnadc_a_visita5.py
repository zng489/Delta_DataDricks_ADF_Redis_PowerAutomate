import os
import re
import shutil
import time
import traceback
import zipfile
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
from typing import List, Tuple
from unicodedata import normalize

import pandas as pd
import redis
import requests
from azure.storage.filedatalake import FileSystemClient
from bs4 import BeautifulSoup


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __normalize(string: str) -> str:
    return normalize('NFKD', string.strip()).encode('ASCII', 'ignore').decode('ASCII')


def __normalize_replace(string: str) -> str:
    return re.sub(r'[,;:{}()\n\t=*%]', '', __normalize(string)
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('|', '_')
                  .replace('/', '_')
                  .replace('.', '_')
                  .upper())


def __check_path_exists(adl: FileSystemClient, path: str) -> bool:
    try:
        next(adl.get_paths(path, recursive=False, max_results=1))
        return True
    except:
        return False


def __read_in_chunks(file_object, chunk_size: int = 100 * 1024 * 1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl: FileSystemClient, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode='rb') as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as err:
        file_client.delete_file()
        raise err


def __create_directory(schema: str = None, table: str = None, year=None) -> str:
    if year:
        return f'{LND}/{schema}__{table}/{year}'
    return f'{LND}/{schema}__{table}'


def __drop_directory(adl, schema: str = None, table: str = None, year=None) -> None:
    adl_drop_path = __create_directory(schema=schema, table=table, year=year)
    if __check_path_exists(adl, adl_drop_path):
        adl.delete_directory(adl_drop_path)


def __upload_file(adl, schema: str, table: str, file: str, year=None) -> None:
    split = os.path.basename(file).split('.')
    filename = __normalize_replace(split[0])
    file_type = list(
        map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0])
    )

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = '.'.join(file_type)
    adl_write_path = f'{directory}/{filename}.{file_type}'

    __upload_bs(adl, file, adl_write_path)


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __extract_all_zip(output_path: str, remover: bool = True) -> None:
    for file_ in os.listdir(output_path):
        if file_.endswith('.zip'):
            file_ = os.path.join(output_path, file_)
            try:
                with zipfile.ZipFile(file_) as z:
                    z.extractall(path=output_path)
            except Exception as err:
                raise Exception(f'Falha ao descompactar arquivo {file_}. Erro: {err}.')
            if remover:
                os.remove(file_)


def __get_date(string: str) -> date or None:
    date = re.search('\d{4}-\d{2}-\d{2}', string)
    if date:
        return datetime.strptime(date.group(0), '%Y-%m-%d').date()


def __get_files_and_update_dates(url: str, pattern: str) -> List[Tuple[str, date]]:
    webpage = requests.get(url).content
    table = BeautifulSoup(webpage, 'html.parser').find('table')
    file_date_list = [
        (tag_a.get('href'), __get_date(tag_a.parent.parent.text))
        for tag_a in table.find_all('a', href=True)
        if pattern in tag_a.get('href')
    ]
    if not file_date_list:
        raise Exception('Error: No file was returned!')
    return file_date_list


def __download_file(url_file: str, output_path: str) -> None:
    response = requests.get(url_file)
    if response.status_code != 200:
        raise Exception(
            f'Erro: Status code {response.status_code}. File: {output_path}'
        )
    try:
        with open(output_path, 'wb') as f:
            f.write(response.content)
    except Exception as err:
        raise Exception(
            f'Falha ao escrever arquivo {output_path}. \nErro: {err}'
        )


def __get_year_metadata_dict(metadata_list: list) -> dict:
    dict_year_input = {}
    out_standard = [m for m in metadata_list if re.search('\d{4}_a_\d{4}', m)]
    within_standard = [m for m in metadata_list if not re.search('\d{4}_a_\d{4}', m)]
    for item in out_standard:
        s = re.search('(\d{4})_a_(\d{4})', item)
        year_i, year_f = int(s.group(1)), int(s.group(2))
        for year in range(year_i, year_f + 1):
            dict_year_input[year] = item

    for item in within_standard:
        year = int(re.search('PNADC_(\d{4})', item).group(1))
        dict_year_input[year] = item

    return dict_year_input


def __get_input_data(url_file: str) -> str:
    try:
        input_data = requests.get(url_file).content.decode('cp1252')
    except UnicodeDecodeError:
        input_data = requests.get(url_file).content.decode()
    except Exception as err:
        raise Exception(f'Falha ao obter arquivo de input dos dados. Erro: {err}')
    return input_data


def __parse_sas_input(input_data: str) -> Tuple[List[str], List[Tuple[int, int]]]:
    """Esta função extrai, a partir de um arquivo de texto, as informações quanto aos
    nomes das colunas e as posições inicial e final de cada coluna de uma tabela de
    linhas formatadas de largura fixa.

    Args:
        input_data (str): caminho do arquivo que contem as informações quanto aos nomes
            das colunas e as posições inicial e final de cada coluna.

    Returns:
        Tuple[List[str], List[Tuple[int, int]]]: Tupla que contém uma lista com os
            nomes das colunas e uma lista de tuplas cujos valores indicam as posições
            inicial e final de cada coluna.
    """
    struct = re.findall(r'@(\d+)\s([\w|\d]+)\s+\$*(\d+)\.', input_data)
    formats = [(int(f[0]) - 1, int(f[0]) + int(f[2]) - 1) for f in struct]
    column_names = [str(f[1]) for f in struct]
    return column_names, formats


def __parse_txt(file_path: str, input_data: str) -> pd.DataFrame:
    """Esta função lê um arquivo de texto contendo uma tabela de linhas formatadas de
    largura fixa como um DataFrame do Pandas.

    Args:
        file_path (str): caminho do arquivo de texto a ser lido.
        input_data (str): caminho do arquivo que contem as informações quanto aos nomes
            das colunas e as posições inicial e final de cada coluna.

    Returns:
        pd.DataFrame: DataFrame com os dados devidamente lidos.
    """
    column_list, list_start_end_position = __parse_sas_input(input_data)
    try:
        df = pd.read_fwf(
            file_path,
            names=column_list,
            colspecs=list_start_end_position,
            header=None,
            dtype=str
        )
    except Exception as err:
        raise Exception(f'Falha ao ler arquivo {file_path}. Erro: {err}')

    dict_columns = {}
    for column in df.columns:
        dict_columns.update({column: __normalize_replace(str(column).strip())})

    df = df.rename(columns=dict_columns)
    return df


def __process_dataframe_chunksize_parquet(
        file_path: str, input_data: str, schema: str, table: str
    ) -> None:
    column_list, list_start_end_position = __parse_sas_input(input_data)
    try:
        df_chunks = pd.read_fwf(
            file_path,
            names=column_list,
            colspecs=list_start_end_position,
            header=None,
            dtype=str,
            chunksize=30000,
        )
    except Exception as err:
        raise Exception(f'Falha ao ler arquivo {file_path}. Erro: {err}.')

    adl = authenticate_datalake()
    header = True
    dict_columns = {}
    for idx, chunk in enumerate(df_chunks):
        if header:
            for column in chunk.columns:
                dict_columns.update({column: __normalize_replace(str(column).strip())})

        chunk = chunk.rename(columns=dict_columns)

        parquet_output = f'{file_path.replace(".txt", "")}_{idx}.parquet'
        try:
            chunk.to_parquet(parquet_output, index=False)
        except Exception as err:
            raise Exception(f'Falha ao salvar arquivo {parquet_output}. Erro: {err}.')
        header = None

        try:
            __upload_file(adl, schema=schema, table=table, file=parquet_output)
        except Exception as err:
            raise Exception(
                f'Falha ao enviar arquivo {parquet_output} para o datalake.'
                f'Erro: {err}.'
            )
    del df_chunks


def main(**kwargs):
    '''Esta função realiza a captura dos dados anuais da categoria 'Visita_5' da página
    da PNAD contínua do site do IBGE (https://ftp.ibge.gov.br/).
    '''
    host, passwd = kwargs.pop('host'), kwargs.pop('passwd')

    visit_number = 5
    url_base = 'https://ftp.ibge.gov.br/'
    url = (
        url_base
        + 'Trabalho_e_Rendimento/Pesquisa_Nacional_por_Amostra_de_Domicilios_continua/'
        + f'Anual/Microdados/Visita/Visita_{visit_number}/'
    )
    schema = 'ibge'
    table = f'pnadc_a_visita{visit_number}'

    key_name = f'org_raw_{schema}_{table}'
    tmp = f'/tmp/{key_name}/'
    os.makedirs(tmp, mode=0o777, exist_ok=True)

    try:
        if kwargs['reset']:
            __call_redis(host, passwd, 'delete', key_name)

        if kwargs['reload'] is not None:
            raise Exception(
                'Erro: O parâmetro \"reload\" não é utilizado nesse bot!'
                'Por favor, defina o parâmetro \"reload\" como vazio.'
            )

        if __call_redis(host, passwd, 'exists', key_name):
            _date_str = __call_redis(host, passwd, 'get', key_name).decode()
            last_update = datetime.strptime(_date_str, '%Y-%m-%d').date()
        else:
            _reference_day = date.today().replace(day=1)
            last_update = _reference_day - relativedelta(years=1)

        adl = authenticate_datalake()

        file_date_list = __get_files_and_update_dates(url + 'Dados/', pattern='zip')
        for file_, update_date in file_date_list:
            if update_date > last_update:
                __download_file(
                    url_file=f'{url}Dados/{file_}',
                    output_path=os.path.join(tmp, file_)
                )

        __extract_all_zip(tmp)
        __drop_directory(adl, schema=schema, table=table)

        metadata_list = __get_files_and_update_dates(url + 'Documentacao/', 'txt')
        metadata_list = [m[0] for m in metadata_list]
        year_metadata_dict = __get_year_metadata_dict(metadata_list)

        make_chunks = True

        for file_path in os.listdir(tmp):
            if not file_path.endswith('.txt'):
                continue

            year = int(re.search('\d{4}', file_path).group(0))
            file_path = os.path.join(tmp, file_path)
            input_data = __get_input_data(
                f'{url}Documentacao/{year_metadata_dict[year]}'
            )

            if make_chunks:
                __process_dataframe_chunksize_parquet(
                    file_path, input_data, schema, table
                )
            else:
                df = __parse_txt(file_path, input_data)
                parquet_output = f'{file_path.replace(".txt", "")}.parquet'
                df.to_parquet(parquet_output, index=False)
                __upload_file(adl, schema=schema, table=table, file=parquet_output)

        update_date = max(set(item[1] for item in file_date_list))
        if kwargs['reload'] is None:
            __call_redis(host, passwd, 'set', key_name, str(update_date))

        return {'exit': 200}
    except Exception as err:
        raise err
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {'finished_with_errors': False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata['exit'] = 500
        metadata['finished_with_errors'] = True
        metadata['msg'] = str(e)
        metadata['traceback'] = traceback.format_exc()
    finally:
        metadata['execution_time'] = time.time() - start

    if kwargs['callback'] is not None:
        requests.post(kwargs['callback'], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=False, callback=None))
