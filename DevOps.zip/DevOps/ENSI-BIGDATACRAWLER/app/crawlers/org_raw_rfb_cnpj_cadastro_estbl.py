import concurrent.futures
import os
import re
import shutil
import time
import traceback
import zipfile
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
from typing import Tuple
from unicodedata import normalize

import pandas as pd
import redis
import requests
from azure.storage.filedatalake import FileSystemClient
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter, Retry


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __normalize(string: str) -> str:
    return normalize('NFKD', string.strip()).encode('ASCII', 'ignore').decode('ASCII')


def __normalize_replace(string: str) -> str:
    return re.sub(r'[,;:{}()\n\t=*%]', '', __normalize(string)
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('|', '_')
                  .replace('/', '_')
                  .replace('.', '_')
                  .upper())


def __check_path_exists(adl: FileSystemClient, path: str) -> bool:
    try:
        next(adl.get_paths(path, recursive=False, max_results=1))
        return True
    except:
        return False


def __read_in_chunks(file_object, chunk_size: int = 100 * 1024 * 1024) -> tuple:
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl: FileSystemClient, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode='rb') as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True, timeout=1800)
    except Exception as err:
        file_client.delete_file()
        raise err


def __create_directory(schema: str = None, table: str = None, year=None) -> str:
    if year:
        return f'{LND}/{schema}__{table}/{year}'
    return f'{LND}/{schema}__{table}'


def __drop_directory(
        adl: FileSystemClient, schema: str = None, table: str = None, year=None
    ) -> None:
    adl_drop_path = __create_directory(schema=schema, table=table, year=year)
    if __check_path_exists(adl, adl_drop_path):
        adl.delete_directory(adl_drop_path)


def __upload_file(
        adl: FileSystemClient, schema: str, table: str, file: str, year=None
    ) -> None:
    split = os.path.basename(file).split('.')
    filename = __normalize_replace(split[0])
    file_type = list(
        map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0])
    )

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = '.'.join(file_type)
    adl_write_path = f'{directory}/{filename}.{file_type}'

    __upload_bs(adl, file, adl_write_path)


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __extract_all_zip(output_path: str, remover: bool = True) -> None:
    for file_ in sorted(os.listdir(output_path)):
        if file_.endswith('.zip'):
            file_ = os.path.join(output_path, file_)
            try:
                with zipfile.ZipFile(file_) as z:
                    z.extractall(path=output_path)
            except Exception as err:
                raise Exception(f'Falha ao descompactar arquivo {file_}. Erro: {err}')
            if remover:
                os.remove(file_)


def __get_update_date_and_files(url: str, patterns: str or list) -> Tuple[date, list]:
    webpage = requests.get(url).content
    table = BeautifulSoup(webpage, 'html.parser').find('table')
    urlpart_date_list_func = lambda pattern : [
        tag_tr.text.split()[:2]
        for tag_tr in table.find_all('tr')
        if pattern in tag_tr.text
    ]

    urlpart_date_list = []
    if isinstance(patterns, list):
        for pattern in patterns:
            urlpart_date_list += urlpart_date_list_func(pattern)
    elif isinstance(patterns, str):
        urlpart_date_list += urlpart_date_list_func(patterns)
    else:
        raise TypeError(
            'Error: Invalid type! The `patterns` parameter must be str or list!'
        )

    if urlpart_date_list == []:
        raise Exception('Error: No file was returned!')

    update_date = max(set(item[1] for item in urlpart_date_list))
    update_date = datetime.strptime(update_date, '%Y-%m-%d').date()
    files_list = [item[0] for item in urlpart_date_list]
    return update_date, files_list


def __download_file(session: requests.Session, url_file: str, output_path: str) -> None:
    response = session.get(url_file)
    if response.status_code != 200:
        raise Exception(
            f'Erro: Status code {response.status_code}. File: {output_path}'
        )
    try:
        with open(output_path, 'wb') as f:
            f.write(response.content)
    except Exception as err:
        raise Exception(
            f'Falha ao escrever arquivo {output_path}. \nErro: {err}'
        )


def __download_part(
        session: requests.Session,
        url_file: str,
        header: dict,
        partfilename: str,
        chunk_size: int,
    ) -> int:
    response = session.get(url_file, headers=header)
    if response.status_code != 206:
        raise Exception(
            f'Erro: Status code {response.status_code}. Part file: {partfilename}'
        )
    size = 0
    try:
        with open(partfilename, 'wb') as f:
            for chunk in response.iter_content(chunk_size):
                if chunk:
                    size += f.write(chunk)
    except Exception as err:
        raise Exception(
            f'Falha ao escrever parte do arquivo {partfilename}. \nErro: {err}'
        )
    return size


def __make_headers(start: int, chunk_size: int) -> dict:
    end = start + chunk_size - 1
    return {'Range': f'bytes={start}-{end}'}


def __download_multipart(
        url_file: str, output_path: str, chunk_size: int = 1024 * 1024
    ) -> None:
    retry_strategy = Retry(
        total=10, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)

    session = requests.Session()
    session.mount('http://', adapter)
    session.mount('https://', adapter)

    response = session.get(url_file, stream=True)
    if response.status_code != 200:
        raise Exception(f'Erro: Status code {response.status_code}.')

    file_size = int(response.headers.get('content-length', 0))
    if file_size == 0:
        raise Exception('Erro: file_size is zero.')

    if file_size > chunk_size:
        chunks = range(0, file_size, chunk_size)
        headers_partfiles_list = [
            (__make_headers(chunk, chunk_size), f'{output_path}.part{i}')
            for i, chunk in enumerate(chunks)
        ]

        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
            jobs = [
                executor.submit(
                    __download_part, session, url_file, header, partfilename, chunk_size
                )
                for header, partfilename in headers_partfiles_list
            ]

        try:
            with open(output_path, 'wb') as outfile:
                for i in range(len(chunks)):
                    chunk_path = f'{output_path}.part{i}'
                    with open(chunk_path, 'rb') as s:
                        outfile.write(s.read())
                    os.remove(chunk_path)
        except Exception as err:
            raise Exception(
                f'Falha ao escrever arquivo {output_path}. \nErro: {err}'
            )
    else:
        __download_file(session, url_file, output_path)


def __make_uploads(tmp: str, schema: str, table: str) -> None:
    for file_path in sorted(os.listdir(tmp)):
        if file_path.endswith('.parquet'):
            adl = authenticate_datalake()
            file_path = os.path.join(tmp, file_path)
            try:
                __upload_file(adl, schema=schema, table=table, file=file_path)
            except Exception as err:
                raise Exception(
                    f'Falha ao enviar arquivo {file_path} para o datalake.'
                    f'Erro: {err}.'
                )


def __process_dataframe_chunksize_parquet(file_path: str) -> None:
    try:
        df_chunks = pd.read_csv(
            file_path,
            sep=";",
            header=None,
            encoding='ISO-8859-1',
            dtype=str,
            chunksize=2*10**6,
        )
    except Exception as err:
        raise Exception(f'Falha ao ler arquivo {file_path}. Erro: {err}.')

    header = True
    dict_columns = {}
    for idx, chunk in enumerate(df_chunks):
        if header:
            for column in chunk.columns:
                dict_columns.update({column: __normalize_replace(str(column).strip())})

        chunk = chunk.rename(columns=dict_columns)

        parquet_output = f'{file_path}_{idx}.parquet'
        try:
            chunk.to_parquet(parquet_output, index=False)
        except Exception as err:
            raise Exception(f'Falha ao salvar arquivo {parquet_output}. Erro: {err}.')
        header = None
    del df_chunks


def __parse_csv(file_path: str) -> pd.DataFrame:
    df = pd.read_csv(
        file_path,
        sep=";",
        header=None,
        encoding='ISO-8859-1',
        dtype=str
    )

    # Deletar possiveis colunas nulas:
    filter_ = df.notnull().sum(axis=0) == 0
    df.drop(columns=df.columns[filter_], inplace=True)

    dict_columns = {}
    for column in df.columns:
        dict_columns.update({column: __normalize_replace(str(column).strip())})

    df = df.rename(columns=dict_columns)
    return df


def main(**kwargs):
    '''Esta função realiza a captura de dados de Estabelecimentos da página de
    "Dados Públicos CNPJ" do site da Receita Federal (www.gov.br/receitafederal/).
    '''
    host, passwd = kwargs.pop('host'), kwargs.pop('passwd')

    url = 'http://200.152.38.155/CNPJ/'
    pattern = 'Estabelecimento'
    schema = 'rfb_cnpj'
    table = 'cadastro_estbl'

    key_name = f'org_raw_{schema}_{table}'
    tmp = f'/tmp/{key_name}/'
    os.makedirs(tmp, mode=0o777, exist_ok=True)

    try:
        if kwargs['reset']:
            __call_redis(host, passwd, 'delete', key_name)

        if kwargs['reload'] is not None:
            raise Exception(
                'Erro: O parâmetro \"reload\" não é utilizado nesse bot!'
                'Por favor, defina o parâmetro \"reload\" como vazio.'
            )

        update_date, files_list = __get_update_date_and_files(url, pattern)

        if __call_redis(host, passwd, 'exists', key_name):
            _date_str = __call_redis(host, passwd, 'get', key_name).decode()
            last_update = datetime.strptime(_date_str, '%Y-%m-%d').date()
        else:
            last_update = update_date - relativedelta(months=1)

        if update_date > last_update:
            adl = authenticate_datalake()

            for file_ in files_list:
                __download_multipart(
                    url_file=f'{url}{file_}',
                    output_path=os.path.join(tmp, file_),
                    chunk_size=2 * 1024 * 1024
                )

            __extract_all_zip(tmp)
            __drop_directory(adl, schema=schema, table=table)

            make_chunks = True

            for file_path in sorted(os.listdir(tmp)):
                file_path = os.path.join(tmp, file_path)
                if make_chunks:
                    __process_dataframe_chunksize_parquet(file_path)
                else:
                    df = __parse_csv(file_path)
                    parquet_output = f'{file_path}.parquet'
                    df.to_parquet(parquet_output, index=False)

            __make_uploads(tmp, schema, table)

            if kwargs['reload'] is None:
                __call_redis(host, passwd, 'set', key_name, str(update_date))

        return {'exit': 200}
    except Exception as err:
        raise err
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {'finished_with_errors': False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata['exit'] = 500
        metadata['finished_with_errors'] = True
        metadata['msg'] = str(e)
        metadata['traceback'] = traceback.format_exc()
    finally:
        metadata['execution_time'] = time.time() - start

    if kwargs['callback'] is not None:
        requests.post(kwargs['callback'], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=False, callback=None))
