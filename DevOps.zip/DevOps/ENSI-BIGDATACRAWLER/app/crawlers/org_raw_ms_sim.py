import gc
import os
import re
from textwrap import indent
from bs4 import BeautifulSoup
from numpy import dtype
import requests
import shlex
import shutil
import subprocess
import time
from datetime import date
from threading import Timer
from unicodedata import normalize
from datetime import datetime
from dateutil.relativedelta import relativedelta
import pandas as pd

import redis
from azure.storage.filedatalake import FileSystemClient
from simpledbf import Dbf5


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __normalize(string: str) -> str:
    return normalize('NFKD', string.strip()).encode('ASCII', 'ignore').decode('ASCII')


def __normalize_replace(string: str) -> str:
    return re.sub(r'[.,;:{}()\n\t=]', '', __normalize(string)
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('|', '_')
                  .replace('/', '_')
                  .replace('.', '_')
                  .upper())


def __check_path_exists(adl, path) -> bool:
    try:
        next(adl.get_paths(path, recursive=False, max_results=1))
        return True
    except:
        return False


def __read_in_chunks(file_object, chunk_size=100 * 1024 * 1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode='rb') as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as e:
        file_client.delete_file()
        raise e


def __create_directory(schema=None, table=None, year=None) -> str:
    if year:
        return f'{LND}/{schema}__{table}/{year}'
    return f'{LND}/{schema}__{table}'


def __drop_directory(adl, schema=None, table=None, year=None) -> None:
    adl_drop_path = __create_directory(schema=schema, table=table, year=year)
    if __check_path_exists(adl, adl_drop_path):
        adl.delete_directory(adl_drop_path)


def __upload_file(adl, schema, table, file, year=None) -> None:
    split = os.path.basename(file).split('.')
    filename = __normalize_replace(split[0])
    file_type = list(
        map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0])
    )

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = '.'.join(file_type)
    adl_write_path = f'{directory}/{filename}.{file_type}'

    __upload_bs(adl, file, adl_write_path)


def __download_file(url, output) -> None:
    request = f'wget --no-check-certificate --progress=bar:force {url} -O {output}'
    process = subprocess.Popen(
        shlex.split(request), stdin=subprocess.PIPE, stdout=subprocess.PIPE
    )
    timer = Timer(300, process.kill)
    try:
        timer.start()
        process.communicate()
    finally:
        timer.cancel()


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __page_to_bs4(url:str) -> BeautifulSoup:
    resp = requests.get(url)

    if resp.status_code != 200 or resp.content is None:
        raise Exception('Falha ao consultar site open datasus.')

    soup = BeautifulSoup(resp.content, "html.parser")

    return soup


months_dict = {
    'Janeiro': '01',
    'Fevereiro': '02',
    'Março': '03',
    'Abril': '04',
    'Maio': '05',
    'Junho': '06',
    'Julho': '07',
    'Agosto': '08',
    'Setembro': '09',
    'Outubro': '10',
    'Novembro': '11',
    'Dezembro': '12',
}


def main(**kwargs):
    '''
    '''

    host, passwd = kwargs.pop('host'), kwargs.pop('passwd')

    schema = 'ms'
    table = 'sim'

    key_name = f'org_raw_{schema}_{table}'
    tmp = f'/tmp/{key_name}/'
    os.makedirs(tmp, mode=0o777, exist_ok=True)

    try:
        if kwargs['reset']:
            __call_redis(host, passwd, 'delete', key_name)

        if kwargs['reload'] is not None:
            raise NotImplementedError('Reload não implementado nessa base') 
 
        if __call_redis(host, passwd, 'exists', key_name):
            _date_str = __call_redis(host, passwd, 'get', key_name).decode()
            last_update = datetime.strptime(_date_str, '%Y-%m-%d').date()
        else:
            last_update = None

        adl = authenticate_datalake()

        base_url = "https://opendatasus.saude.gov.br{id}"
        datasets = ['/dataset/sim-2020-2021', '/dataset/sim-1979-2019']

        for dataset in datasets:
            main_pg = __page_to_bs4(base_url.format(id=dataset))
            source_update = main_pg.find('span', {'class':'automatic-local-datetime'}).get('data-datetime')
            source_update = datetime.strptime(source_update, '%Y-%m-%dT%H:%M:%S%z').date()
            
            if not last_update or source_update > last_update:
                resource_list = main_pg.find('ul', {'class': 'resource-list'})
                resources = resource_list.find_all('a', {'class': 'heading'})
                resources = list(filter(lambda x: x.find('span', {'data-format': 'csv'}), resources))
                
                for r in resources:
                    r_page = __page_to_bs4(base_url.format(id=r.get('href')))
                    r_update = r_page.find_all('tr')
                    r_update = list(filter(lambda x: True if x.find('th').text.startswith('Dados atualizados') else None, r_update))[0]
                    r_update = r_update.find('td').text

                    # Substituindo nome dos meses para numero
                    for month_name, month_nu in months_dict.items():
                        r_update = r_update.replace(month_name, month_nu)

                    r_update = datetime.strptime(r_update, '%d/%m/%Y').date()
                    
                    if not last_update or r_update > last_update:
                        r_url = r_page.find_all('p')
                        r_url = list(filter(lambda x: True if x.text.startswith('URL:') else None, r_url))[0].find('a').get('href')
                        file_name = r_url.rsplit('/', 1)[1].replace('.csv','.parquet')

                        print(r_url)
                        df: pd.DataFrame = pd.read_csv(r_url, sep=';', dtype=str, encoding='iso-8859-1', keep_default_na=False)
                        df.columns = map(str.upper, df.columns)

                        parquet_output = os.path.join(tmp, file_name)
                        
                        df.to_parquet(parquet_output, index=False)
                        __upload_file(adl, schema=schema, table=table, file=parquet_output)
        __call_redis(host, passwd, 'set', key_name, str(date.today()))

        return {'exit': 200}
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {'finished_with_errors': False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata['exit'] = 500
        metadata['finished_with_errors'] = True
        metadata['msg'] = str(e)
    finally:
        metadata['execution_time'] = time.time() - start

    if kwargs['callback'] is not None:
        requests.post(kwargs['callback'], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=False, callback=None))
