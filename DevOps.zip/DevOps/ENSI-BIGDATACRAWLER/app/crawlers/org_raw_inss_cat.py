import os
import re
import shlex
import shutil
import subprocess
import zipfile
import time
import csv
from threading import Timer
from unicodedata import normalize
from datetime import date
from datetime import datetime
from dateutil.relativedelta import relativedelta

import chardet
import pandas as pd
import redis
import requests
from azure.storage.filedatalake import FileSystemClient


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __read_in_chunks(file_object, chunk_size=100 * 1024 * 1024) -> tuple:
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode='rb') as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as e:
        file_client.delete_file()
        raise e


def __create_directory(schema=None, table=None, year=None) -> str:
    return f'{LND}/{schema}__{table}/{year}'


def __adl_file_path(schema: str, table: str, year: str, file: str) -> str:
    split = os.path.basename(file).split('.')
    filename = __normalize_str(split[0])
    file_type = list(map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0]))

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = '.'.join(file_type)
    adl_file_path = f'{directory}/{filename}.{file_type}'

    return adl_file_path


def __drop_file(adl, schema, table, year, file) -> None:
    adl_file_path = __adl_file_path(schema, table, year, file)

    try:
        file = adl.get_file_client(adl_file_path)
        file.get_file_properties()
        file.delete_file()

    except:
        pass


def __upload_file(adl, schema, table, year, file) -> None:
    split = os.path.basename(file).split('.')
    filename = __normalize_str(split[0])
    file_type = list(map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0]))

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = '.'.join(file_type)
    adl_write_path = f'{directory}/{filename}.{file_type}'

    __upload_bs(adl, file, adl_write_path)


def __find_download_link() -> tuple:
    
    url = 'https://dados.gov.br/api/publico/conjuntos-dados/inss-comunicacao-de-acidente-de-trabalho-cat1'

    stdin = requests.Session().get(url).json()
    
    if len(stdin.get('resources')) == 0:
        raise Exception('Something bad is occurring')

    for resource in stdin.get('resources'):
        urls = []

        title = __normalize_str(resource['name']).lower()

        if 'dicionario' in title:
            continue

        year = int(re.findall(re.compile("(?:(?:19|20)[0-9]{2})"), title)[0])

        urls.append((title, resource['url']))

        if len(urls) > 0:
            yield year, urls


def __extract_files(zip_output: str, tmp: str, prefixes: str) -> list:
    with zipfile.ZipFile(zip_output) as _zip:
        data_files = [file for file in _zip.filelist if
                      all(prefix.lower() in (normalize('NFKD', file.filename.lower())
                                             .encode('ASCII', 'ignore')
                                             .decode('ASCII')) for prefix in prefixes)]

        return [_zip.extract(member=data_file, path=tmp) for data_file in data_files
                if '$' not in data_file.filename]


def __download_file(url: str, output: str) -> None:
    request = 'wget --no-check-certificate --progress=bar:force -e use_proxy=yes {url} -O {output}'.format(url=url, output=output)
    process = subprocess.Popen(shlex.split(request), stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    timer = Timer(300, process.kill)
    try:
        timer.start()
        process.communicate()
    finally:
        timer.cancel()


def __normalize_str(_str: str) -> str:
    return re.sub(r'[,{}()\n\t=-]', '', normalize('NFKD', _str)
                  .encode('ASCII', 'ignore')
                  .decode('ASCII')
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('|', '_')
                  .replace('/', '_')
                  .replace('.', '_')
                  .upper())


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(host=host, password=password, port=6379, db=0, socket_keepalive=True, socket_timeout=2)
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __parse_csv(output: str) -> pd.DataFrame:
    df = pd.DataFrame()
    header = None

    rawdata = open(output, 'rb').readlines()
    
    result = chardet.detect(rawdata[0]+rawdata[1])
    encoding = result['encoding']


    with open(output, 'r', encoding=encoding) as infile:
        inputs = csv.reader(infile)

        if not header:

            for row in inputs:
                if inputs.line_num==1:
                    header = __normalize_str(row[0].strip()).split(';')
                    break

            skip = inputs.line_num
    for index, name in enumerate(header):
        for index_ in range(index+1, len(header)):

            if name==header[index_]:
                header[index_]=header[index_]+'_'

    df = pd.read_csv(output, sep=';', header=None, names=header, skiprows=skip, index_col=False, encoding=encoding)
    df['NOME_ARQUIVO'] = os.path.basename(output)
    
    for col in df.columns:
        df[col] = df[col].astype(str)
        
    return df


def files_to_parse(list_file: list) -> list:
    list_return = []
    files_not_parse = ('CPC', 'CAPES', 'ATUALI')

    for file in list_file:
        not_contain = 0
        for not_file in files_not_parse:

            if not_file not in file.upper():
                not_contain+=1
                
        if not_contain==len(files_not_parse):
            list_return.append(file)

    return list_return


def find_in_list(list_params: list, text: str) -> tuple:
    for index, params in enumerate(list_params):
        for param in params:
            if param in text:
                find = list_params.pop(index)[0]

                return find, list_params

    return False, list_params


def rename_file(name: str, year: str) -> str:

    trimestre = {
        '.1': ('jan', 'mar'),
        '.2': ('abr', 'jun'),
        '.3': ('jul', 'set'),
        '.4': ('out', 'dez')
    }
    for trim, months in trimestre.items():
        if months[0] in name and months[1] in name:
            return year+trim


def main(**kwargs):
    '''Esta função realiza a captura de dados trimestrais da página do
    `INSS - Comunicação de Acidente de Trabalho - CAT` encontrada no link
    `https://dados.gov.br/api/publico/conjuntos-dados/inss-comunicacao-de-acidente-de-trabalho-cat1`
    '''
    host, passwd = kwargs.pop('host'), kwargs.pop('passwd')

    schema = 'inss'
    table = 'cat'

    key_name = f'org_raw_{schema}_{table}'
    tmp = f'/tmp/{key_name}/'

    try:
        os.makedirs(tmp, mode=0o777, exist_ok=True)

        if kwargs['reset']:
            __call_redis(host, passwd, 'delete', key_name)
 
        if __call_redis(host, passwd, 'exists', key_name):
            _date_str = __call_redis(host, passwd, 'get', key_name).decode()
            last_update = datetime.strptime(_date_str, '%Y-%m-%d').date()
        else:
            _reference_day = date.today().replace(day=5)
            last_update = _reference_day - relativedelta(months=1)

        adl = authenticate_datalake()
        if last_update + relativedelta(months=1) <= date.today():
            for year, urls in __find_download_link():
                for file_name, url in urls:
                    quarter_year = rename_file(file_name, str(year))

                    output = tmp + file_name + '.' + url.split('.')[-1]
                    __download_file(url, output)

                    parquet_output = os.path.join(tmp, f'{quarter_year}.parquet')
                    __drop_file(adl, schema=schema, table=table, year=str(year), file=parquet_output)

                    if '.csv' in output:
                        df = __parse_csv(output)

                    elif '.zip' in output:
                        file = __extract_files(output, tmp, ['.csv'])

                        assert len(file) == 1
                        
                        df = __parse_csv(file[0])

                    df.to_parquet(parquet_output, index=False)

                    __upload_file(adl, schema=schema, table=table, year=year, file=parquet_output)

            if kwargs['reload'] is None:
                __call_redis(host, passwd, 'set', key_name, str(date.today()))

        return {'exit': 200}
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {'finished_with_errors': False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata['exit'] = 500
        metadata['finished_with_errors'] = True
        metadata['msg'] = str(e)
    finally:
        metadata['execution_time'] = time.time() - start

    if kwargs['callback'] is not None:
        requests.post(kwargs['callback'], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=False, callback=None))
