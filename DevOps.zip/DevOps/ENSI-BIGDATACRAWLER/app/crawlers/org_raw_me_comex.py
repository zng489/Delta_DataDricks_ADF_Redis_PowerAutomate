import os
import io
import re
import shutil
import time
import json
from datetime import date
from unicodedata import normalize
from datetime import datetime
from bs4 import BeautifulSoup

import requests
import redis
import pandas as pd
from azure.storage.filedatalake import FileSystemClient


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __normalize(string: str) -> str:
    return normalize("NFKD", string.strip()).encode("ASCII", "ignore").decode("ASCII")


def __normalize_replace(string: str) -> str:
    return re.sub(
        r"[.,;:{}()\n\t=]",
        "",
        __normalize(string)
        .replace(" ", "_")
        .replace("-", "_")
        .replace("|", "_")
        .replace("/", "_")
        .replace(".", "_")
        .upper(),
    )


def __read_in_chunks(file_object, chunk_size=100 * 1024 * 1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode="rb") as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as e:
        file_client.delete_file()
        raise e


def __create_directory(schema=None, table=None, year=None) -> str:
    if year:
        return f"{LND}/{schema}__{table}/{year}"
    return f"{LND}/{schema}__{table}"


def __upload_file(adl, schema, table, year, file) -> None:
    split = os.path.basename(file).split(".")
    filename = __normalize_replace(split[0])
    file_type = list(
        map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0])
    )

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = ".".join(file_type)
    adl_write_path = f"{directory}/{filename}.{file_type}"

    __upload_bs(adl, file, adl_write_path)


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2,
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __get(url: str) -> requests.Response:
    """Funcao que realiza o download dos dados e também gerencia o encaminhar 
    da requisição. Recebe a url e retorna a resposta.
    """
    resp = requests.get(url, verify=False)

    if not resp.status_code == 200:
        raise Exception(
            f"O Site do Ministério da Economia retornou um status inválido {resp.status_code}!\n{resp.reason}"
        )
    if not resp.content:
        raise Exception(
            "O Site do Ministério da Economia não retornou um conteúdo para chamada HTTP!"
        )

    return resp


def __check_diff(
    bases: dict,
    base_url: str,
    metadata: dict,
    tmp_path: str,
    schema: str,
    table: str,
    adl: FileSystemClient,
) -> dict:
    """Esta função verifica se possui metadados da ultima execução
    e se possui, faz a comparação dos metadados da fonte para verificar se houve atualização de algum ano.
    Caso haja diferença a própria função já baixa e armazena os arquivos.
    """
    for base in bases:
        new_files = None

        resp = __get(base_url.format(file=bases[base].get("check_file")))

        source_df = pd.read_csv(io.BytesIO(resp.content), sep=";")
        if metadata and metadata.get(base):
            redis_df = pd.DataFrame(metadata[base])
            diff_df = pd.merge(source_df, redis_df, how="outer", indicator=True)
            diff_df = diff_df[diff_df["_merge"] == "left_only"]
            new_files = diff_df["ARQUIVO"].tolist()
        else:
            new_files = source_df["ARQUIVO"].tolist()

        for file in new_files:
            end_url = f"{base.split('_')[0]}/{file}"
            file_url = base_url.format(file=end_url)

            file_resp = __get(file_url)

            data_df = pd.read_csv(io.BytesIO(file_resp.content), sep=";")
            parquet_file_name = (
                tmp_path
                + f"{schema}_{table}_{base.split('_')[0]}_{file.split('.')[0].lower()}.parquet"
            )
            data_df.to_parquet(parquet_file_name, index=False)
            __upload_file(
                adl, schema=schema, table=table, year=base, file=parquet_file_name
            )
        metadata[base] = source_df.to_dict()

    return metadata


def __get_dims(tmp_path: str, schema: str, table: str, adl: FileSystemClient) -> None:
    """Esta função baixa o arquivo excel "TABELAS_AUXILIARES" que contem os dados
    dimensionais da base. Os dados vem separados dentro de planilhas diferentes no mesmo arquivo,
    a função baixa o arquivo e separa em arquivos parquet diferentes.
    """ 
    file_resp = __get("https://balanca.economia.gov.br/balanca/bd/tabelas/TABELAS_AUXILIARES.xlsx")

    aux_tab = pd.read_excel(
        io.BytesIO(file_resp.content), sheet_name=None, engine="xlrd"
    )
    dims_map = aux_tab["ÍNDICE"][["Número da aba", "Arquivo Referência"]]
    dims_map["Arquivo Referência"] = (
        dims_map["Arquivo Referência"].str.split(".").str[0]
    )
    for _, data in dims_map.iterrows():
        sheet_indx = data["Número da aba"]
        file_name = data["Arquivo Referência"].lower()
        parquet_file_name = tmp_path + f"{schema}_{table}_{file_name}.parquet"
        aux_tab[str(sheet_indx)].to_parquet(parquet_file_name, index=False)
        __upload_file(
            adl, schema=schema, table=table, year="dimensoes", file=parquet_file_name
        )


def main(**kwargs):
    """
    Esta funcao realiza a captura de dados do Ministério da Economia:
    Dados do comex. Ele verifica a data de atualização da página.
    Caso a data seja superior à ultima atualização então baixa novamente os dados dimensionais
    e verifica se houve diferença nos dados fato utilizando os metadados. Caso algum arquivo fato
    tenha sido atualizado, então o mesmo é baixado e atualizado.
    Por fim atualiza a data e os metadados salvando no redis.
    """

    host, passwd = kwargs.pop("host"), kwargs.pop("passwd")

    schema = "me"
    table = "comex"
    page_url = "https://www.gov.br/produtividade-e-comercio-exterior/pt-br/assuntos/comercio-exterior/estatisticas/base-de-dados-bruta"
    base_url = "https://balanca.economia.gov.br/balanca/bd/comexstat-bd/{file}"
    bases = {
        "ncm_exp": {"check_file": "ncm/EXP_TOTAIS_CONFERENCIA.csv"},
        "ncm_imp": {"check_file": "ncm/IMP_TOTAIS_CONFERENCIA.csv"},
        "mun_exp": {"check_file": "mun/EXP_TOTAIS_CONFERENCIA_MUN.csv"},
        "mun_imp": {"check_file": "mun/IMP_TOTAIS_CONFERENCIA_MUN.csv"},
    }

    key_name = f"org_raw_{schema}_{table}"
    tmp = f"/tmp/{key_name}/"
    os.makedirs(tmp, mode=0o777, exist_ok=True)

    try:
        if kwargs["reset"]:
            __call_redis(host, passwd, "delete", key_name)

        if kwargs["reload"]:
            raise NotImplementedError("Esta base não suporta o parâmetro reload")

        if __call_redis(host, passwd, "exists", key_name):
            redis_metadata = json.loads(__call_redis(host, passwd, "get", key_name))
        else:
            redis_metadata = {}

        adl = authenticate_datalake()

        response = __get(page_url)

        soup = BeautifulSoup(response.content, "html.parser")
        last_update_source = (
            soup.find("span", {"class": "documentModified"})
            .find("span", {"class": "value"})
            .text.replace("h", ":")
        )
        last_update_source = datetime.strptime(
            last_update_source, "%d/%m/%Y %H:%M"
        ).date()

        if redis_metadata and redis_metadata.get("last_update"):
            last_update = datetime.strptime(
                redis_metadata.get("last_update"), "%Y-%m-%d"
            ).date()

            if last_update_source > last_update:
                redis_metadata = __check_diff(
                    bases, base_url, redis_metadata, tmp, schema, table, adl
                )
                __get_dims(tmp, schema, table, adl)
            else:
                return {"exit": 200}
        else:
            redis_metadata = __check_diff(
                bases, base_url, redis_metadata, tmp, schema, table, adl
            )
            __get_dims(tmp, schema, table, adl)

        redis_metadata["last_update"] = str(date.today())

        __call_redis(host, passwd, "set", key_name, json.dumps(redis_metadata))

        return {"exit": 200}
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {"finished_with_errors": False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata["exit"] = 500
        metadata["finished_with_errors"] = True
        metadata["msg"] = str(e)
        raise e
    finally:
        metadata["execution_time"] = time.time() - start

    if kwargs["callback"] is not None:
        requests.post(kwargs["callback"], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=None, callback=None))
