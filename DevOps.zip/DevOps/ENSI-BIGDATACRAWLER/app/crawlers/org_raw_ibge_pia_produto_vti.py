import os
import re
import shutil
import time
from unicodedata import normalize
import json
from datetime import date
from datetime import datetime

import pandas as pd
import requests
import redis
from azure.storage.filedatalake import FileSystemClient
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __check_path_exists(adl, path):
    try:
        next(adl.get_paths(path, recursive=False, max_results=1))
        return True
    except:
        return False


def __read_in_chunks(file_object, chunk_size=100 * 1024 * 1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl, lpath, rpath):
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode='rb') as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as e:
        file_client.delete_file()
        raise e


def __create_directory(schema=None, table=None, year=None):
    if year:
        return '{lnd}/{schema}__{table}/{year}'.format(lnd=LND, schema=schema, table=table, year=year)
    return '{lnd}/{schema}__{table}'.format(lnd=LND, schema=schema, table=table)


def __drop_directory(adl, schema=None, table=None, year=None):
    adl_drop_path = __create_directory(schema=schema, table=table, year=year)
    if __check_path_exists(adl, adl_drop_path):
        adl.delete_directory(adl_drop_path)


def __upload_file(adl, schema=None, table=None, year=None, file=None):
    split = os.path.basename(file).split('.')
    filename = __normalize_str(split[0])
    file_type = list(map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0]))

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = '.'.join(file_type)
    adl_write_path = '{directory}/{file}.{type}'.format(directory=directory, file=filename, type=file_type)

    __upload_bs(adl, file, adl_write_path)


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2,
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __normalize_str(_str):
    return re.sub(r'[,;{}()\n\t=-]', '', normalize('NFKD', _str)
                  .encode('ASCII', 'ignore')
                  .decode('ASCII')
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('.', '_')
                  .upper())


def main(**kwargs):

    '''
    Esta funcao realiza a captura de dados, via api, dos dados IBGE PIA (Pesquisa Industrial Anual - Empresa - Dados Gerais)

    A captura adota os filtros abaixo:
        v	(Variável):
            all
        p (ano):
            all
        c12762 (Classificação Nacional de Atividades Econômicas (CNAE 2.0)):
            all

    Link da tabela no site ibge para consulta dos possíveis filtros: https://sidra.ibge.gov.br/tabela/1848
    '''
    host, passwd = kwargs.pop("host"), kwargs.pop("passwd")

    schema = 'ibge'
    table = 'pia_produto_vti'
    url_metadata = "https://sidra.ibge.gov.br/Ajax/JSon/Tabela/1/1848?versao=-1"
    url_base = 'https://apisidra.ibge.gov.br/values'

    end_points = {
        'pia_produto_vti':
            '/t/1848/n1/all/n3/all/v/810,811/p/all/c12762/all'
    }

    key_name = f"org_raw_{schema}_{table}"
    tmp = f"/tmp/{key_name}/"


    try:
        os.makedirs(tmp, mode=0o777, exist_ok=True)

        if kwargs["reset"]:
            __call_redis(host, passwd, "delete", key_name)

        if __call_redis(host, passwd, "exists", key_name):
            _date_str = __call_redis(host, passwd, "get", key_name).decode()
            last_update = datetime.strptime(_date_str, "%Y-%m-%d").date()
        else:
            last_update = None

        header = {"application": "json"}
        response = requests.get(url_metadata, headers=header)

        if not response.status_code == 200:
            raise Exception(
                f"API Sidra retornou um status inválido {response.status_code}: {response.text}!"
            )
        if not response.content:
            raise Exception("API Sidra não retornou um conteúdo para chamda HTTP!")

        dt_atualizacao_origem = response.json().get("DataAtualizacao", {})

        if not dt_atualizacao_origem:
            raise Exception(
                "Não foi encontrado o objeto DataAtualizacao no JSON (falha na resposta da api)!"
            )

        dt_atualizacao_origem = datetime.strptime(
                    str(dt_atualizacao_origem), "%Y-%m-%dT%H:%M:%S"
                ).date()

        adl = authenticate_datalake()
        if last_update==None or \
            dt_atualizacao_origem >= last_update or \
                kwargs['reload']:

            for _table, end_point in end_points.items():
                url = url_base+end_point

                s = requests.Session()

                retry = Retry(connect=3, backoff_factor=0.5)
                adapter = HTTPAdapter(max_retries=retry)
                s.mount('https://', adapter)

                response = s.get(url)

                if response.status_code!=200:
                    raise Exception('status_code not 200')

                response_list = response.json()
                dict_column_name = response_list.pop(0)
                response_json = json.dumps(response_list)

                for key, name_col in dict_column_name.items():
                    dict_column_name[key] = __normalize_str(name_col)

                df = pd.read_json(response_json)

                df.rename(columns=dict_column_name, inplace=True)

                __drop_directory(adl, schema=schema, table=_table)

                parquet_output = tmp + '{file}.parquet'.format(file=_table)
                df.to_parquet(parquet_output, index=False)

                __upload_file(adl, schema=schema, table=_table, file=parquet_output)

            if kwargs["reload"] is None:
                __call_redis(host, passwd, "set", key_name, str(date.today()))
                
        return {'exit': 200}
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {'finished_with_errors': False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata['exit'] = 500
        metadata['finished_with_errors'] = True
        metadata['msg'] = str(e)
    finally:
        metadata['execution_time'] = time.time() - start

    if kwargs['callback'] is not None:
        requests.post(kwargs['callback'], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=False, callback=None))
