import os
from io import StringIO
import re
import shlex
import shutil
import subprocess
import time
from datetime import date
from threading import Timer
from unicodedata import normalize
from datetime import datetime
from dateutil.relativedelta import relativedelta

import requests
import redis
import pandas as pd
from azure.storage.filedatalake import FileSystemClient


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __normalize(string: str) -> str:
    return normalize('NFKD', string.strip()).encode('ASCII', 'ignore').decode('ASCII')


def __normalize_replace(string: str) -> str:
    return re.sub(r'[.,;:{}()\n\t=]', '', __normalize(string)
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('|', '_')
                  .replace('/', '_')
                  .replace('.', '_')
                  .upper())


def __check_path_exists(adl, path) -> bool:
    try:
        next(adl.get_paths(path, recursive=False, max_results=1))
        return True
    except:
        return False


def __read_in_chunks(file_object, chunk_size=100 * 1024 * 1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode='rb') as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as e:
        file_client.delete_file()
        raise e


def __create_directory(schema=None, table=None, year=None) -> str:
    if year:
        return f'{LND}/{schema}__{table}/{year}'
    return f'{LND}/{schema}__{table}'


def __drop_directory(adl, schema=None, table=None, year=None) -> None:
    adl_drop_path = __create_directory(schema=schema, table=table, year=year)
    if __check_path_exists(adl, adl_drop_path):
        adl.delete_directory(adl_drop_path)


def __upload_file(adl, schema, table, year, file) -> None:
    split = os.path.basename(file).split('.')
    filename = __normalize_replace(split[0])
    file_type = list(
        map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0])
    )

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = '.'.join(file_type)
    adl_write_path = f'{directory}/{filename}.{file_type}'

    __upload_bs(adl, file, adl_write_path)


def __download_file(url, output) -> None:
    request = f'wget --no-check-certificate --progress=bar:force {url} -O {output}'
    process = subprocess.Popen(
        shlex.split(request), stdin=subprocess.PIPE, stdout=subprocess.PIPE
    )
    timer = Timer(300, process.kill)
    try:
        timer.start()
        process.communicate()
    finally:
        timer.cancel()


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __normalize_str(_str):
    return re.sub(r'[,{}()\n\t=-]', '', normalize('NFKD', _str)
                  .encode('ASCII', 'ignore')
                  .decode('ASCII')
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('|', '_')
                  .replace('/', '_')
                  .replace('.', '_')
                  .upper())


def __get_content_csv(year):

    url = 'http://www3.dataprev.gov.br/scripts10/dardoweb.cgi'

    s = requests.Session()
    nt = '76679883'
    payload = {
        'NT': nt,
        'EA': 'http://www3.dataprev.gov.br/aeat/GReg/Reg05/',
        'EC': '27',
        'AQ': 'Reg05.par',
        'AC': '0',
        'IN': '1',
        'UU': '0',
        'US': '',
        'CE1': 'Soma',
        'DF': 'http://www3.dataprev.gov.br/aeat/GReg/Reg05/Reg05.php',
        'VN': '1',
        'ND': '',
        'CJ': 'AEAT InfoLogo',
        'LI': 'UF',
        'V1': 'Ano inicial',
        'V2': 'Ano final',
        'CO': 'Motivo/Situação',
        'V3': 'Ano inicial',
        'V4': 'Ano final',
        'UB': '---------Não---------',
        'V9': 'Ano inicial',
        'V0': 'Ano final',
        'QU': 'Ano',
        'V5': 'Ano inicial',
        'V6': 'Ano final',
        'SL': 'Classe do CNAE 2.0',
        'V7': 'Ano inicial',
        'V8': 'Ano final',
        'CN': 'Qte de Acidentes',
        'OL': 'SemOrdem',
        'OC': 'SemOrdem',
        'OQ': 'SemOrdem',
        'PL': '',
        'YZAno': '0',
        'YCAno': '"%s":NOME;%s' % (year, year)
    }

    set_consulta = s.post(url, data=payload)
    if set_consulta.status_code!=200:
        Exception('Status code: {}'.format(set_consulta.status_code)) 

    if 'Valor de seleção incorreto: Seleção=Ano'.upper() in set_consulta.text.upper():
        return None

    payload = {
        'AQ': 'd:\sites\aeat\GReg\Reg05\Reg05.par',
        'FN': '80',
        'NO': '',
        'JG': '',
        'PP': '',
        'PS': '',
        'SP': '',
        'RR': '',
        'NU': 'false;false;false',
        'LA': '',
        'SH': '',
        'CE': 'SOMA',
        'GN': '',
        'FS': '1',
        'SU': '',
        'MH': '',
        'KA': '',
        'PT': '',
        'AT': f'd:\sites\temp\consulta{nt}.csv',
        'ER': f'http://www3.dataprev.gov.br/temp/consulta{nt}.csv',
        'CV': '',
        'SG': '1',
        'SK': '1',
        'PQ': '1',
        'AF': '',
        'US': '',
        'RP': ''
    }
    
    set_button_xml = s.post('http://www3.dataprev.gov.br/scripts10/netplus.cgi', data=payload)
    if set_button_xml.status_code!=200:
        Exception('Status code: {}'.format(set_button_xml.status_code)) 

    get_xml = s.get(f'http://www3.dataprev.gov.br/temp/consulta{nt}.csv')
    if get_xml.status_code!=200:
        Exception('Status code: {}'.format(get_xml.status_code))

    return get_xml.text


def __parse_csv(content_csv, year):

    df = pd.read_csv(StringIO(content_csv), sep=";", skiprows=2,encoding='utf-8')

    dict_columns = {}
    for column in df.columns:
        dict_columns.update({column: __normalize_str(column.strip())})

    df = df.rename(columns=dict_columns)

    df['ANO'] = year

    init_agg_total = df.index[df['UF'] == 'Ano = Total'].tolist()[0]
    df = df.filter(items = list(range(init_agg_total)), axis=0)

    for col in df.columns:
        df[col] = df[col].astype(str)

    for i in range(len(df['UF'])):
        if df.loc[i, 'UF']=='nan':
            df.loc[i, 'UF'] = df.loc[i-1, 'UF']

    return df


def main(**kwargs):
    '''
    Esta funcao realizado captura de dados da página - "Informações: Acidentes do trabalho por UF e CNAE2.0"

    o processo de captura, manual, se dá em 2 requisiciões:
        1 - Envio de requisição ao link "http://www3.dataprev.gov.br/AEAT/greg/reg05/reg05.PHP" com filtros: 
            
                Linha=UF
                Coluna=Motivo/Situação
                Subcoluna=----------Não----------
                Quadro=Ano
                Sublinha=Classe do CNAE 2.0
                Conteúdo=Qtd de acidentes

                Ano=Valor

        2 - Acesso ao botão de "Transfere arquivo CSV"
    '''

    host, passwd = kwargs.pop('host'), kwargs.pop('passwd')

    schema = 'mtp_aeat'
    table = 'motivo_class'

    key_name = f'org_raw_{schema}_{table}'
    tmp = f'/tmp/{key_name}/'
    os.makedirs(tmp, mode=0o777, exist_ok=True)

    try:
        if kwargs['reset']:
            __call_redis(host, passwd, 'delete', key_name)

        if kwargs['reload'] is not None:
            reload_year = [int(kwargs['reload'])]

        if __call_redis(host, passwd, 'exists', key_name):
            _date_str = __call_redis(host, passwd, 'get', key_name).decode()
            last_update = datetime.strptime(_date_str, '%Y-%m-%d').date()
        else:
            _reference_day = date.today().replace(day=1)
            last_update = _reference_day - relativedelta(months=1)

        adl = authenticate_datalake()

        year_today = date.today().year
        years = [*range(2006, year_today+1)] if kwargs['reload'] is None else reload_year

        if last_update + relativedelta(months=1) <= date.today():
            for  year in years:

                content_csv = __get_content_csv(year)
                if not content_csv:
                    continue

                df = __parse_csv(content_csv, year)

                __drop_directory(adl, schema=schema, table=table, year=year)

                parquet_output = tmp + f'{schema}_{table}_ANO_{year}.parquet'
                df.to_parquet(parquet_output, index=False)

                __upload_file(adl, schema=schema, table=table, year=year, file=parquet_output)

            if kwargs['reload'] is None:
                __call_redis(host, passwd, 'set', key_name, str(date.today()))

        return {'exit': 200}
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {'finished_with_errors': False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata['exit'] = 500
        metadata['finished_with_errors'] = True
        metadata['msg'] = str(e)
    finally:
        metadata['execution_time'] = time.time() - start

    if kwargs['callback'] is not None:
        requests.post(kwargs['callback'], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=False, callback=None))
