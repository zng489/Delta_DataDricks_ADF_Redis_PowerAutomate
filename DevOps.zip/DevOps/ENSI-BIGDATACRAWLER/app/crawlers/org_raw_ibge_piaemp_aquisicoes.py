import os
import re
import shlex
import shutil
import subprocess
import time
from datetime import date
from threading import Timer
from unicodedata import normalize
from datetime import datetime

import requests
import redis
import pandas as pd
from azure.storage.filedatalake import FileSystemClient


def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __normalize(string: str) -> str:
    return normalize("NFKD", string.strip()).encode("ASCII", "ignore").decode("ASCII")


def __normalize_replace(string: str) -> str:
    return re.sub(
        r"[.,;:{}()\n\t=]",
        "",
        __normalize(string)
        .replace(" ", "_")
        .replace("-", "_")
        .replace("|", "_")
        .replace("/", "_")
        .replace(".", "_")
        .upper(),
    )


def __check_path_exists(adl, path) -> bool:
    try:
        next(adl.get_paths(path, recursive=False, max_results=1))
        return True
    except:
        return False


def __read_in_chunks(file_object, chunk_size=100 * 1024 * 1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode="rb") as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as e:
        file_client.delete_file()
        raise e


def __create_directory(schema=None, table=None, year=None) -> str:
    if year:
        return f"{LND}/{schema}__{table}/{year}"
    return f"{LND}/{schema}__{table}"


def __drop_directory(adl, schema=None, table=None, year=None) -> None:
    adl_drop_path = __create_directory(schema=schema, table=table, year=year)
    if __check_path_exists(adl, adl_drop_path):
        adl.delete_directory(adl_drop_path)


def __upload_file(adl, schema, table, year, file) -> None:
    split = os.path.basename(file).split(".")
    filename = __normalize_replace(split[0])
    file_type = list(
        map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0])
    )

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = ".".join(file_type)
    adl_write_path = f"{directory}/{filename}.{file_type}"

    __upload_bs(adl, file, adl_write_path)


def __download_file(url, output) -> None:
    request = f"wget --no-check-certificate --progress=bar:force {url} -O {output}"
    process = subprocess.Popen(
        shlex.split(request), stdin=subprocess.PIPE, stdout=subprocess.PIPE
    )
    timer = Timer(300, process.kill)
    try:
        timer.start()
        process.communicate()
    finally:
        timer.cancel()


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2,
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def __normalize_str(_str):
    return re.sub(
        r"[,{}()\n\t=-]",
        "",
        normalize("NFKD", _str)
        .encode("ASCII", "ignore")
        .decode("ASCII")
        .replace(" ", "_")
        .replace("-", "_")
        .replace("|", "_")
        .replace("/", "_")
        .replace(".", "_")
        .upper(),
    )


def main(**kwargs):
    """
    Esta funcao realizado captura de dados da API Sidra:
    Dados gerais das empresas industriais com 1 ou mais pessoas ocupadas, segundo as divisões de atividades (CNAE 2.0)
    """

    host, passwd = kwargs.pop("host"), kwargs.pop("passwd")

    schema = "ibge"
    table = "piaemp_aquisicoes"
    url_metadata = "https://sidra.ibge.gov.br/Ajax/JSon/Tabela/1/1843?versao=-1"
    url_data = "https://apisidra.ibge.gov.br/values/t/1843/n1/all/v/all/p/{year}/c12762/all/d/v1000850%202,v1000851%202,v1000852%202,v1000853%202,v1000854%202,v1000855%202"

    key_name = f"org_raw_{schema}_{table}"
    tmp = f"/tmp/{key_name}/"
    os.makedirs(tmp, mode=0o777, exist_ok=True)

    try:
        if kwargs["reset"]:
            __call_redis(host, passwd, "delete", key_name)

        reload_year = None
        if kwargs["reload"] is not None:
            reload_year = [int(kwargs["reload"])]

        if __call_redis(host, passwd, "exists", key_name):
            _date_str = __call_redis(host, passwd, "get", key_name).decode()
            last_update = datetime.strptime(_date_str, "%Y-%m-%d").date()
        else:
            last_update = None

        adl = authenticate_datalake()

        header = {"application": "json"}
        response = requests.get(url_metadata, headers=header)

        if not response.status_code == 200:
            raise Exception(
                f"API Sidra retornou um status inválido {response.status_code}: {response.text}!"
            )
        if not response.content:
            raise Exception("API Sidra não retornou um conteúdo para chamda HTTP!")

        periods = response.json().get("Periodos", {}).get("Periodos", None)

        if not periods:
            raise Exception(
                "Não foi encontrado o objeto Periodos.Periodos, no JSON (falha na resposta da api)!"
            )

        periods = [
            (
                period["Codigo"],
                datetime.strptime(
                    str(period["DataLiberacao"]), "%Y-%m-%dT%H:%M:%S"
                ).date(),
            )
            for period in periods
        ]

        if last_update:
            periods = list(filter(lambda x: x[1] > last_update, periods))

        if reload_year:
            periods = [reload_year,]

        for period in periods:
            year = str(period[0])
            result = requests.get(url_data.format(year=year))

            if not result.status_code == 200:
                raise Exception(
                    f"API Sidra retornou um status inválido para a requisicao de dados {response.status_code}: {response.text}!"
                )
            if not result.content:
                raise Exception("API Sidra não retornou um conteúdo para chamada HTTP de dados!")

            df = pd.DataFrame.from_dict(result.json())[1:]

            __drop_directory(adl, schema=schema, table=table, year=year)

            parquet_file_name = tmp + f'{schema}_{table}_ANO_{year}.parquet'

            df.to_parquet(parquet_file_name, index=False)

            __upload_file(adl, schema=schema, table=table, year=year, file=parquet_file_name)

        if kwargs["reload"] is None:
            __call_redis(host, passwd, "set", key_name, str(date.today()))

        return {"exit": 200}
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp)


def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'

    start = time.time()
    metadata = {"finished_with_errors": False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata["exit"] = 500
        metadata["finished_with_errors"] = True
        metadata["msg"] = str(e)
    finally:
        metadata["execution_time"] = time.time() - start

    if kwargs["callback"] is not None:
        requests.post(kwargs["callback"], json=metadata)

    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    import dotenv
    from app import app

    dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=None, callback=None))
