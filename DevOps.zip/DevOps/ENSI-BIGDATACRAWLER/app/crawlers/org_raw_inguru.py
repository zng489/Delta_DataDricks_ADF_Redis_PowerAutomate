import gc
import os
import re
import requests
import shlex
import shutil
import subprocess
import time
import traceback
from datetime import date
from threading import Timer
from unicodedata import normalize
from datetime import datetime

from time import sleep
import pandas as pd


import os
import time
import redis
from azure.storage.filedatalake import FileSystemClient
import requests, zipfile, io
# import wget
import re
import shlex
import shutil
import subprocess
from zipfile import ZipFile
from threading import Timer
from unicodedata import normalize
import pandas as pd
import glob
from tqdm import tqdm
from urllib.request import urlopen
import concurrent.futures
from concurrent.futures import as_completed


import requests
import json
import pandas as pd

def authenticate_datalake() -> FileSystemClient:
    from azure.identity import ClientSecretCredential
    from azure.storage.filedatalake import DataLakeServiceClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    adl = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
        "https", os.environ['AZURE_ADL_STORE_NAME']), credential=credential)

    return adl.get_file_system_client(file_system=os.environ['AZURE_ADL_FILE_SYSTEM'])


def __normalize(string: str) -> str:
    return normalize("NFKD", string.strip()).encode("ASCII", "ignore").decode("ASCII")


def __normalize_replace(string: str) -> str:
    return re.sub(
        r"[.,;:{}()\n\t=]",
        "",
        __normalize(string)
        .replace(" ", "_")
        .replace("-", "_")
        .replace("|", "_")
        .replace("/", "_")
        .replace(".", "_")
        .upper(),
    )


def __check_path_exists(adl, path) -> bool:
    try:
        next(adl.get_paths(path, recursive=False, max_results=1))
        return True
    except:
        return False


def __read_in_chunks(file_object, chunk_size=100 * 1024 * 1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 100Mb."""
    offset, length = 0, 0
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break

        length += len(data)
        yield data, offset, length
        offset += chunk_size


def __upload_bs(adl, lpath, rpath) -> None:
    file_client = adl.get_file_client(rpath)
    try:
        with open(lpath, mode="rb") as file:
            for chunk, offset, length in __read_in_chunks(file):
                if offset > 0:
                    file_client.append_data(data=chunk, offset=offset)
                    file_client.flush_data(length)
                else:
                    file_client.upload_data(data=chunk, overwrite=True)
    except Exception as e:
        file_client.delete_file()
        raise e


def __create_directory(schema=None, table=None, year=None) -> str:
    if year:
        return f"{LND}/{schema}__{table}/{year}"
    return f"{LND}/{schema}__{table}"


def __drop_directory(adl, schema=None, table=None, year=None) -> None:
    adl_drop_path = __create_directory(schema=schema, table=table, year=year)
    if __check_path_exists(adl, adl_drop_path):
        adl.delete_directory(adl_drop_path)


def __upload_file(adl, schema, table, year, file) -> None:
    split = os.path.basename(file).split(".")
    filename = __normalize_replace(split[0])
    file_type = list(
        map(str.lower, [_str for _str in map(str.strip, split[1:]) if len(_str) > 0])
    )

    directory = __create_directory(schema=schema, table=table, year=year)
    file_type = ".".join(file_type)
    adl_write_path = f"{directory}/{filename}.{file_type}"

    __upload_bs(adl, file, adl_write_path)


def __download_file(url, output) -> None:
    request = f"wget --no-check-certificate --progress=bar:force {url} -O {output}"
    process = subprocess.Popen(
        shlex.split(request), stdin=subprocess.PIPE, stdout=subprocess.PIPE
    )
    timer = Timer(300, process.kill)
    try:
        timer.start()
        process.communicate()
    finally:
        timer.cancel()


def __call_redis(host, password, function_name, *args):
    db = redis.Redis(
        host=host,
        password=password,
        port=6379,
        db=0,
        socket_keepalive=True,
        socket_timeout=2,
    )
    try:
        method_fn = getattr(db, function_name)
        return method_fn(*args)
    except Exception as _:
        raise _
    finally:
        db.close()


def API_INGURU(url):
  headers = {
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
    'accept':'application/json',
    'authorization': '6f64d6a047fad369d35c3806f8f8e0560475075a432585973f91caae35b4ad74'}
  resp = requests.get(url, headers=headers)
  resp_json = resp.text
  data = json.loads(resp_json)
  return data


def __delete_file():
    test = os.listdir('././.')
    for item in test:
        if item.endswith(".tmp"):
            ## print(item)
            os.remove(item)





def main(**kwargs):
    """
    Função principal de download dos dados.
    Este crawler usa o Selenium para extrair os dados.
    Dentro de um for ele percorre todos os botões necessários para chegar no download,
    baixa o arquivo para uma pasta temporária, transforma para parquet e faz o upload para o ADL.
    Obs: Por algum motivo o proxy apresentou problemas no ADF e precisou ser modificado para ser
    utilizado nessa extração, por isso observa-se codigos como: 'httpProxy' : f'http://:@{proxy_addr}',
    onde usa-se apenas o endereço de ip e porta da variável de ambiente deixando o usuário e senha vazio.
    """
    adl = authenticate_datalake()

    host, passwd = kwargs.pop("host"), kwargs.pop("passwd")



    schema = "inguru"
    table = 'news'
    year = None

    key_name = f"org_raw_{schema}_{table}"
    tmp = f"/tmp/{key_name}/"
    os.makedirs(tmp, mode=0o777, exist_ok=True)

    
    try:
        time.sleep(5)
        nodeID = '820'
        urlNodeID = 'https://app.inguru.me/api/v1/taxonomies/nodes/'+str(nodeID)
        newsID = API_INGURU(url = urlNodeID)['data'][0]['id']
        time.sleep(5)
        url = 'https://app.inguru.me/api/v1/taxonomies/nodes/news/'+str(newsID)
        API_INGURU(url = url)
        df = pd.DataFrame.from_dict(API_INGURU(url = url)['data'])
        time.sleep(5)   
        df['date'] = pd.to_datetime('today').strftime("%d/%m/%Y")

        parquet_output = tmp + 'inguru' + '.parquet'
        df.to_parquet(parquet_output, index=False)
        print(parquet_output)

        __drop_directory(adl, schema, table)
        time.sleep(5)
        __upload_file(adl, schema, table,year=year,file=parquet_output)







        return {'exit': 200}
    except Exception as e:
        raise e
    finally:
        shutil.rmtree(tmp)
        #tempo = time.time() - start
        #print(tempo)



def execute(**kwargs):
    global DEBUG, LND

    DEBUG = bool(int(os.environ.get('DEBUG', 1)))
    LND = '/tmp/dev/lnd/crw' if DEBUG else '/lnd/crw'
    start = time.time()
    metadata = {'finished_with_errors': False}
    try:
        log = main(**kwargs)
        if log is not None:
            metadata.update(log)
    except Exception as e:
        metadata['exit'] = 500
        metadata['finished_with_errors'] = True
        metadata['msg'] = str(e)
    finally:
        __delete_file()
        metadata['execution_time'] = time.time() - start
    if kwargs['callback'] is not None:
        requests.post(kwargs['callback'], json=metadata)
    return metadata


DEBUG, LND = None, None
if __name__ == '__main__':
    #import dotenv
    #from app import app

    #dotenv.load_dotenv(app.ROOT_PATH + '/debug.env')
    exit(execute(host='localhost', passwd=None, reload=None, reset=False, callback=None))