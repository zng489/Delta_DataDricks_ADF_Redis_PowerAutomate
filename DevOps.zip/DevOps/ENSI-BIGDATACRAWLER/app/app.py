import importlib
import os
import subprocess
from multiprocessing import Process

import requests
from azure.mgmt.resource import ResourceManagementClient
from flask import Flask
from flask import jsonify, request
from msrestazure.azure_active_directory import ServicePrincipalCredentials
from werkzeug import run_simple

ROOT_PATH = os.path.dirname(__file__)
app = Flask(__name__)


@app.route('/v1/bot/list/', methods=['GET', 'POST'])
def _list():
    bots = map(lambda bot: bot[0], filter(lambda bot: bot[1].is_alive(), RUNNING_BOTS.items()))
    return __send_callback({'exit': 200, 'bots': list(bots)})


@app.route('/v1/ping', methods=['GET', 'POST'])
def ping():
    return __send_callback({'crawler_ip': HOST, 'redis_ip': REDIS_HOST})


@app.route('/v1/bot/run/<bot_name>', methods=['GET', 'POST'])
def run(bot_name):
    callback = __get_callback_uri()

    if not __bot_is_running(bot_name):
        crawler_path = 'crawlers/%s.py' % bot_name
        if not os.path.exists(crawler_path):
            return __send_callback({'exit': 500, 'msg': 'Bot not found at path %s' % crawler_path})

        crawler_module = 'crawlers.%s' % bot_name
        try:
            __execute_crawler(bot_name, crawler_module, callback=callback, **request.args)
            return jsonify({'exit': 200, 'msg': 'Started {bot}'.format(bot=bot_name)})
        except Exception as e:
            return __send_callback({'exit': 500, 'msg': str(e)})
    else:
        return __send_callback({'exit': 300, 'msg': '{bot} is running'.format(bot=bot_name)})


@app.route('/v1/bot/status/<bot_name>', methods=['GET', 'POST'])
def status(bot_name):
    bot_status = 'RUNNING' if __bot_is_running(bot_name) else 'STOPPED'
    return __send_callback({'status': bot_status})


@app.route('/v1/bot/stop/<bot_name>', methods=['GET', 'POST'])
def stop(bot_name):
    if __bot_is_running(bot_name):
        process = RUNNING_BOTS.pop(bot_name)
        process.terminate()

        return __send_callback({'exit': 200, 'msg': 'Stopped %s' % bot_name})

    return __send_callback({'exit': 200, 'msg': '%s was not running' % bot_name})


@app.route('/v1/git/pull', methods=['GET', 'POST'])
def pull():
    __execute_shell('git fetch')

    changes = __execute_shell('git pull')
    changes = changes.split('\n') if len(changes) > 0 else None

    commit_version = __execute_shell('git rev-parse HEAD')
    return __send_callback({'commit': commit_version, 'commit_prefix': commit_version[:8], 'log': changes})


def __key_vault_secret(key):
    from azure.identity import ClientSecretCredential
    from azure.keyvault.secrets import SecretClient

    credential = ClientSecretCredential(
        tenant_id=os.environ['AZURE_TENANT_ID'],
        client_id=os.environ['AZURE_CLIENT_ID'],
        client_secret=os.environ['AZURE_CLIENT_SECRET'])

    secret_client = SecretClient(
        vault_url=os.environ['AZURE_KEY_VAULT_URI'],
        credential=credential)

    return secret_client.get_secret(key).value


def __execute_shell(cmd):
    stdin, stdout = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE).communicate()
    return stdin.decode().strip()


def __execute_crawler(bot_name, crawler_module, **kwargs):
    module = importlib.import_module(crawler_module)
    main = getattr(module, 'execute')

    kwargs = __set_default_parameters(kwargs)
    RUNNING_BOTS[bot_name] = Process(target=main, name=bot_name, kwargs=kwargs)
    RUNNING_BOTS[bot_name].start()


def __set_default_parameters(kwargs):
    params = {'host': REDIS_HOST, 'passwd': REDIS_PASSWD, 'reload': None, 'reset': False, 'callback': None}
    for key, value in params.items():
        kwargs.setdefault(key, value)
    return kwargs


def __bot_is_running(bot_name):
    if bot_name in RUNNING_BOTS:
        process = RUNNING_BOTS[bot_name]
        if not process.is_alive():
            RUNNING_BOTS.pop(bot_name)

        return process.is_alive()

    return False


def __send_callback(data):
    callback = __get_callback_uri()
    if callback is not None:
        requests.post(callback, json=data)

    return jsonify(data)


def __get_callback_uri():
    body = request.get_json(silent=True)
    if body is not None and 'callBackUri' in body:
        return body['callBackUri']
    return None


def __find_containers_ip(*containers):
    credential = ServicePrincipalCredentials(tenant=os.environ['AZURE_TENANT_ID'],
                                             secret=os.environ['AZURE_CLIENT_SECRET'],
                                             client_id=os.environ['AZURE_CLIENT_ID'])
    client = ResourceManagementClient(credentials=credential, subscription_id=os.environ['AZURE_SUBSCRIPTION_ID'])

    for resource in client.resources.list_by_resource_group(resource_group_name=os.environ['RESOURCE_GROUP']):
        if resource.name in containers:
            if resource.type == 'Microsoft.ContainerInstance/containerGroups':
                resource_detail = client.resources.get_by_id(resource.id, api_version='2019-12-01')
                if resource_detail.properties['instanceView']['state'] != 'Running':
                    raise Exception('Main: %s instance is not running' % resource.name)
                yield resource.name, resource_detail.properties['ipAddress']['ip']


def setup_prd_env():
    global HOST, REDIS_HOST, REDIS_PASSWD
    containers = dict(__find_containers_ip(os.environ['CRAWLER_CONTAINER_NAME'],
                                           os.environ['REDIS_CONTAINER_NAME']))
    HOST, REDIS_HOST, REDIS_PASSWD = (containers[os.environ['CRAWLER_CONTAINER_NAME']],
                                      containers[os.environ['REDIS_CONTAINER_NAME']],
                                      __key_vault_secret(os.environ['AZURE_KEY_VAULT_REDIS_SECRET']))


HOST, REDIS_HOST, REDIS_PASSWD = '0.0.0.0', '0.0.0.0', None
if __name__ == '__main__':
    RUNNING_BOTS = dict()

    PRODUCTION = bool(int(os.environ.get('DEBUG', 1))) == 0
    if PRODUCTION:
        setup_prd_env()

    run_simple(hostname='0.0.0.0', port=int(os.environ['PORT']),
               application=app, threaded=True, use_reloader=True)
