# Databricks notebook source
# MAGIC %md
# MAGIC <h3>Tool Box Databricks Lab</h3>
# MAGIC Esse notebook contém exemplos de códigos básicos comentados para permitir uma exploração de dados no ambiente do Data Lake institucional usando o Databricks

# COMMAND ----------

# DBTITLE 1,Introdução
# MAGIC %md
# MAGIC Utilizaremos ao longo desse notebook, preferencialmente, a linguagem Python via Pyspark. Dessa forma, conseguimos usar todo o poder computacional do cluster, se beneficiando do fato das execuções serem feitas em um modelo de computação distribuída controlada pelo próprio Databricks. O cluster é um conjunto de máquinas que são configurados (pela STI) de acordo com a necessidade de cada área ou projeto. Ele é quem irá ser responsável pelas execuções. Vale ressaltar que ele pode ser usado somente pelas pessoas indicadas nas configurações de permissão.<br><br>
# MAGIC Dessa maneira, a primeira coisa a ser feita é indicar e iniciar o cluster que será usado nas execuções do seu notebook. Isso pode ser encontrado no canto superior esquerdo dessa tela: <img src="http://docs.databricks.com/_static/images/notebooks/detached.png"/>.<br>Clique nele e indique o cluster que deseja usar, aquele que foi indicado para a sua área. Ao clicar em **Start Cluster**, deverá aguardar ele iniciar, passando do status <img src="http://docs.databricks.com/_static/images/clusters/cluster-starting.png"/></a> para <img src="http://docs.databricks.com/_static/images/clusters/cluster-running.png"/></a>. Nesse momento, o cluster estará ativo e pronto para uso!

# COMMAND ----------

# DBTITLE 1,Índice
# MAGIC %md
# MAGIC [1. Escrevendo texto nos notebooks](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002389)<br>
# MAGIC [2. Abrindo uma sessão Spark](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002391)<br>
# MAGIC [3. Carregando dados do data lake](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002394)<br>
# MAGIC &ensp;&ensp;[3.1 Carregando dados já existentes no data lake](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002395)<br>
# MAGIC &ensp;&ensp;[3.2 Carregando arquivos externos](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002400)<br>
# MAGIC [4. Importação das funções SQL do pyspark](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002404)<br>
# MAGIC [5. Códigos de exemplo](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002407)<br>
# MAGIC &ensp;&ensp;[5.1 display](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002408)<br>
# MAGIC &ensp;&ensp;[5.2 dbutils](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002414)<br>
# MAGIC &ensp;&ensp;[5.3 del](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002417)<br>
# MAGIC &ensp;&ensp;[5.4 printSchema](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002422)<br>
# MAGIC &ensp;&ensp;[5.5 select](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002425)<br>
# MAGIC &ensp;&ensp;[5.6 filter ou where](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002430)<br>
# MAGIC &ensp;&ensp;[5.7 groupBy](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002433)<br>
# MAGIC &ensp;&ensp;[5.8 orderBy ou sort](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002436)<br>
# MAGIC &ensp;&ensp;[5.9 join](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002440)<br>
# MAGIC &ensp;&ensp;[5.10 drop](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002444)<br>
# MAGIC &ensp;&ensp;[5.11 withColumn](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002447)<br>
# MAGIC &ensp;&ensp;[5.12 when](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002450)<br>
# MAGIC &ensp;&ensp;[5.13 lit](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002453)<br>
# MAGIC &ensp;&ensp;[5.14 funções de agregação](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002455)<br>
# MAGIC &ensp;&ensp;[5.15 distinct](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002459)<br>
# MAGIC &ensp;&ensp;[5.16 escrever dados no data lake](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002463)<br>
# MAGIC [6. Usando outras linguagens](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002467)<br>
# MAGIC [7. Teclas de Atalho](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002470)<br>

# COMMAND ----------

# DBTITLE 1,1. Escrevendo texto nos notebooks
# MAGIC %md
# MAGIC Para escrever textos que não sejam códigos, que servirão para documentar o seu trabalho, inicie a linha de código com o comando `%md`. Isso indica que o conteúdo daquela célula é um texto que pode ser configurado com o uso da linguagem MarkDown (exemplos em https://www.markdownguide.org/cheat-sheet/)<br>
# MAGIC
# MAGIC
# MAGIC **Dessa forma, o código abaixo:**
# MAGIC ~~~
# MAGIC %md
# MAGIC Esse é um texto de exemplo escrito em MarkDown
# MAGIC ~~~
# MAGIC
# MAGIC **Terá a seguinte saída:**<br>
# MAGIC
# MAGIC Esse é um texto de exemplo escrito em MarkDown<br>
# MAGIC
# MAGIC **Para comentários no código...**<br>
# MAGIC Para adicionar comentários nas células de código, inicie a linha com `#`. Para comentar um trecho grande dentro da célula de código, use `'''` (3 aspas simples) antes e depois do trecho que quer comentar. Esses trechos indicados como comentários não interferem no código da célula e também são importantes para fins de documentação.

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# DBTITLE 1,2. Abrindo uma sessão Spark
# MAGIC %md
# MAGIC Inicialmente, é recomendado abrir uma sessão do Spark (SparkSession) para executar manipulações definidas por você em todo o cluster. Para abrir sua Spark Session, basta rodar o comando abaixo:

# COMMAND ----------

spark

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# DBTITLE 1,3. Carregando dados do data lake
# MAGIC %md
# MAGIC Podem ser usados arquivos contidos no data lake (para os quais você possui acesso de leitura) ou de fontes externas (desde que previamente importados para o diretório uds).

# COMMAND ----------

# MAGIC %md 
# MAGIC **3.1 Carregando dados já existentes no data lake**
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC ##### Utilize o banco de dados do unity catalog para encontra as tabelas do data lake que você tem acesso
# MAGIC
# MAGIC ##### A esquerda procure a opção catálogo, em seguida filtre pelo prefixo "datalake_" e por fim expanda para visualizar os esquemas e tabelas que você tem acesso, conforme a imagem
# MAGIC
# MAGIC ![Name of the image](/Workspace/Exemplos/images/Captura de tela 2024-11-11 150019.png)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Utilize a interface para obter o endereço da tabela, conforme a imagem
# MAGIC ![Name of the image](/Workspace/Exemplos/images/Captura de tela 2024-11-11 153058.png)

# COMMAND ----------

#Por fim, para ler a tabela basta utilizar o comando read.table
df = spark.read.table("datalake__trs.oni.me__rais_vinculo_publica")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##### Continua sendo possível consultar tabelas pelo endereço do datalake, mas essa informação do endereço só esta disponível nos "detalhes" da tabelas no banco de dados do unity.
# MAGIC ##### Exemplo: https://adb-6523536500265509.9.azuredatabricks.net/explore/data/datalake__trs/oni/me__rais_vinculo_publica?o=6523536500265509&activeTab=details
# MAGIC ![Name of the image](/Workspace/Exemplos/images/Captura de tela 2024-11-11 170639.png)
# MAGIC
# MAGIC
# MAGIC ##### Com essa informação do endereço da tabela no data lake é possivel ler os dados da seguinte forma:
# MAGIC

# COMMAND ----------

#esse método atualmente é legado e o seu uso em novos notebooks não é recomendado

#Indicando o endereço do data lake storage
''''var_adls_uri = "abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net"'''

# COMMAND ----------

#Passando o caminho relativo para o diretório do data lake em que irá consultar os dados. Nesse exemplo, usaremos a base de dados pública da RAIS, que está na camada trusted (trs).
''''var_path_file = "/trs/me/rais_vinculo_publica/"'''

# COMMAND ----------

#Montando o caminho absoluto do arquivo
'''var_file = var_adls_uri + var_path_file'''

'''
Fazendo a importação desse arquivo para o Databricks e associando ele a um dataframe
(por padrão da arquitetura do data lake, os arquivos de dados estão todos no formato parquet)
'''
'''df = spark.read.parquet(var_file)'''

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **3.2 Carregando arquivos externos**<br>
# MAGIC
# MAGIC Caso tenha uma base de dados fora do data lake que esteja em formato csv, txt ou parquet e precise trazer ela para o seu lab, é possível fazer isso e usar com o poder de processamento do Databricks, fazendo cruzamento com bases do data lake, por exemplo. Para isso carregue o arquivo na pasta uds/volume da sua área e carregue para o lab com os comandos abaixo:

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Primeiramente, procure pelo "volume" do "lab" da sua área no catálogo, conforme a imagem: 
# MAGIC ![Name of the image](/Workspace/Exemplos/images/Captura de tela 2024-11-11 183918.png)

# COMMAND ----------

#Após isso basta usar o comando abaixo para visualizar os dados do aquivo
df_titanic = spark.read.csv('/Volumes/lab_sti_cda/default/uds_inteligencia/titanic.csv', header=True, sep=",")

# COMMAND ----------

#esse método atualmente é legado e o seu uso em novos notebooks não é recomendado
#Outro exemplo, de carregamento de base externa em csv (previamente importada para o diretório uds do data lake)

#Indicando o endereço do data lake storage
'''var_adls_uri = "abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net"'''

#(observe a indicação de que os dados contém um cabeçalho - header=True - e a indicação do separador dos dados - sep=";")
'''var_path_file_cnae = "/uds/inteligencia/divisao_cnae/"
df_divcnae = spark.read.csv(var_adls_uri+var_path_file_cnae, header=True, sep=";")'''

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# DBTITLE 1,4. Importação das funções SQL do pyspark
# MAGIC %md
# MAGIC Lista de funções pyspark integradas ao Databricks e disponíveis para usar nos dataframes (`pyspark.sql.functions`).<br>
# MAGIC Usaremos algumas ao longo desse notebook, mas uma lista completa pode ser encontrada em https://spark.apache.org/docs/2.4.0/api/python/pyspark.sql.html#module-pyspark.sql.functions<br>
# MAGIC É importante considerar o uso integrado de mais de uma função em um mesmo código para otimizar suas análises. Veremos exemplos de implementações assim, **sempre usando um `f.<função>`**.

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# DBTITLE 1,5. Códigos de exemplo
# MAGIC %md
# MAGIC Códigos contendo exemplos comentados para realizar as tarefas mais comuns no uso do lab

# COMMAND ----------

# MAGIC %md
# MAGIC **5.1 display**<br>
# MAGIC Comando usado para visualizar os 1.000 primeiros registros do dataframe indicado

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Para limitar o número de registros a serem apresentados na tela, pode-se usar o `limit(n)` junto ao comando display (recomendável). O `n` representa o número de registros que deseja visualizar.

# COMMAND ----------

display(df.limit(5)) #aplicando um display limitado a apenas os 5 primeiros registros

# COMMAND ----------

# MAGIC %md
# MAGIC O comando `show` também pode ser usado para trazer uma apresentação dos dados na tela, mas o uso do comando `display` gera algumas vantagens, como uma visualização mais amigável em formato de tabela, a possibilidade de exportar os dados, usando o ícone <img src="https://docs.databricks.com/_images/download-results.png"/></a>, e gerar gráficos diretamente na tela, usando o ícone <img src="http://docs.databricks.com/_static/images/notebooks/chart-button.png"/></a>. Explore seus resultados para conhecer melhor essas funcionalidades!

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.2 dbutils**<br>
# MAGIC Databricks Utilities (*dbutils*) facilitam a execução de combinações poderosas de tarefas, no entanto, devem ser usados com cuidado já que podem levar a comportamentos inesperados caso não se tenha certeza do que está sendo feito. De todo modo, há um comando bem interessante usando o *dbutils* que pode abreviar o trabalho do usuário e esse pode ser usado sem problemas.<br><br>
# MAGIC Trata-se do `dbutils.fs.ls(<path>)` (onde `<path>` deve conter o caminho absoluto do diretório). Esse comando traz para o notebook uma lista dos arquivos contidos no diretório indicado. Isso pode ser visto no Portal Azure ou no Microsoft Storage Explorer, mas usando aqui, acaba sendo um atalho interessante para consultar o conteúdo de um diretório específico e ver o que tem nele ou até mesmo para validar se o caminho foi informado corretamente ou ainda para ver se o que se quer usar, de fato, existe nesse diretório.

# COMMAND ----------

#Exemplo de uso do dbutils para consultar um diretório. Observe que com esse comando foi possível avaliar aqui, dada a estratégia de particionamento da base, quais anos da RAIS estão disponíveis para consulta no data lake (ANO=2008 a ANO=2019)
dbutils.fs.ls(var_file)

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.3 del**<br>
# MAGIC Todos os dataframes carregados via comandos pyspark são alocados na memória do cluster para um acesso rápido e processamento distribuído eficiente. No entanto, alguns desses dataframes ao longo da sua construçõs podem ficar sem utilidade, sendo recomendável apagá-los da memória, liberando espaço para outros arquivos. Isso pode ser feito pelo comando `del`.

# COMMAND ----------

#Criando um dataframe de exemplo para ser usado nessa explicação do comando del
myRange = spark.range(10).toDF("number")
display(myRange.limit(5))

# COMMAND ----------

#Deletando o dataframe de exemplo (myRange)
del myRange

# COMMAND ----------

#A referência ao dataframe deletado agora irá gerar um erro de código, já que o Databricks não encontrará mais esse dataframe na memória
display(myRange.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.4 printSchema**<br>
# MAGIC O comando `printSchema` mostra na tela qual é a estrutura do arquivo (schema) do ponto de vista de tipo de variável e se aquele campo aceita dados nulos. Esse schema ao longo do processo de ingestão e transformação das camadas oficiais do data lake já é indicado, no entanto, quando se faz a carga de uma base de dados externa (como mostrado no item 3.2), esse tipo de informação torna-se particularmente importante já que pode indicar possíveis necessidades de ajuste nos dados. Por exemplo, uma variável que contém o ano de uma base, pode ser inferido como uma variável numérica, mas ter a natureza de categórica, logo uma conversão pode ser necessária.

# COMMAND ----------

df_divcnae = spark.read.table('datalake__biz.oni.oni_bases_referencia_cnae_cnae_20__cnae_divisao')

#Buscando o schema da base
df_divcnae.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.5 select**<br>
# MAGIC O comando `select` define um subconjunto de variáveis a serem consideradas, basta apenas informar quais são. Serão mostradas duas maneiras distintas de fazer isso esse uso: uma mais direta e outra montada a partir de um vetor de colunas indicado previamente.

# COMMAND ----------

#selecionando diretamente três colunas da base da RAIS e usando o comando "show" para mostrar o resultado dos 10 primeiros registros
df.select('ANO','CD_UF','CD_CNAE20_CLASSE').show(10)

# COMMAND ----------

#passando um vetor de colunas a serem considerados no select
cols = ['ANO','CD_UF','CD_CNAE20_CLASSE','CD_CNAE20_SUBCLASSE','CD_CAUSA_AFASTAMENTO1','CD_CAUSA_AFASTAMENTO2','CD_CAUSA_AFASTAMENTO3','VL_DIAS_AFASTAMENTO']

#usando o vetor de colunas indicado para fazer um select na base usando agora o comando "display" para mostrar os 10 primeiros registros
#observe que o vetor cols precisa precedido por um asterisco para que a referência seja feita corretamente
display(df.select(*cols).limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ##![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) **DICA**
# MAGIC Uma vantagem de se usar esse segundo caso é, que usando o vetor de colunas, o dataframe passará a ter as colunas na ordem indicada no vetor, o que pode ajudar a organizar suas bases de dados.

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.6 filter ou where**<br>
# MAGIC Enquanto o `select` restinge o número de colunas, a função `filter` é filtrar dados em linhas com base em valores de colunas específicas. A função `where` cumpre exatamente o mesmo efeito do `filter`. As duas existem basicamente, porque para o público com conhecimento de SQL o *where* faz mais sentido, já para o Scala (linguagem predominante no Spark, que é o "motor" por trás do Databricks) é o *filter* o comando que faz esse tipo de ação. No final da contas, ficaram as duas e você pode usar a que fizer mais sentido para você!
# MAGIC
# MAGIC P.S.: *A função `f.col` foi usada dessa forma porque a `col` faz parte da lista de funções carregadas no item 4. Para maiores detalhes, veja novamente o [item 4](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/4355373230923589).*

# COMMAND ----------

#filtrando os registros que possuem dias de afastamento maior que zero (('VL_DIAS_AFASTAMENTO')>0)
'''
observe o encadeamento de várias funções em um mesmo comando
- select para restrinigir o número de colunas
- filter para restringir o número de registros
- col para fazer referência a uma coluna específica com o apoio das funções spark carregadas no item 4
- display para exibir na tela o resultado de tudo isso
'''

display(df.select(*cols).filter(f.col('VL_DIAS_AFASTAMENTO')>0).limit(10))
#o filter poderia ser substituído pelo where sem o menor problema!

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.7 groupBy**<br>
# MAGIC O `groupBy` faz um agrupamento da base de dados segundo uma variável (ou conjunto de variáveis) e um critério de agregação

# COMMAND ----------

#fazendo um agrupamento que traz a contagem da variável FL_VINCULO_ATIVO_3112 por ano (sem ordenação)
display(df.select('ANO','FL_VINCULO_ATIVO_3112').groupby('ANO','FL_VINCULO_ATIVO_3112').count())

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.8 orderBy ou sort**<br>
# MAGIC Você pode usar as funções `orderBy` ou `sort` para classificar a base de dados ou o resultado de uma execução (um groupby, por exemplo) em ordem crescente ou decrescente com base em uma ou várias colunas. No entanto, há diferenças no código de implementação de cada uma.
# MAGIC
# MAGIC P.S.: *A função `f.col` foi usada dessa forma porque a `col` faz parte da lista de funções carregadas no item 4. Para maiores detalhes, veja novamente o [item 4](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/4355373230923589).*

# COMMAND ----------

#ORDERBY
#selecionando duas variáveis (ANO e FL_VINCULO_ATIVO_3112) fazendo uma ordenação decrescente por ano e crescente por FL_VINCULO_ATIVO_3112 de toda a base
df.select('ANO','FL_VINCULO_ATIVO_3112').orderBy(f.col('ANO').desc(),f.col('FL_VINCULO_ATIVO_3112').asc()).show(10)

# COMMAND ----------

#SORT
#contando o número de registros por ano e fazendo uma ordenação decrescente dos resultados por ano
display(df.groupBy("ANO").count().sort("ANO",ascending=False))

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.9 join**<br>
# MAGIC Essa é função bastante usada e serve para fazer a junção de bases de dados para que possam ser trabalhadas em um dataframe único.<br>
# MAGIC A sintaxe padrão dos joins no pyspark é a seguinte: <br><br>
# MAGIC **self.join(other, on, how)**
# MAGIC <br><br>
# MAGIC Onde:<br>
# MAGIC - self: dataframe de origem (left)
# MAGIC - other: dataframe que trará mais variáveis para o dataframe final (right)
# MAGIC - on: variável que servirá de chave para unificação dos dataframes
# MAGIC - how: como os dataframes se juntarão (o padrão é o inner). As formas mais comuns são inner, full, left e right join.
# MAGIC <br><br>
# MAGIC <img src="https://estatsite.com.br/wp-content/uploads/2019/04/1.png" width="25%"/>

# COMMAND ----------

#gerando um dataframe (df2) que receberá o resultado do join feito entre o df e o df_divcnae, com a coluna 'CD_CNAE20_DIVISAO' sendo a chave para a junção que será do tipo left.
#na prática, o resultado será um novo dataframe que passará a ter todas as variáveis do df e do df_divcnae. O conteúdo que já existia em df não irá sofrer alteração e receberá, sempre que a chave 'CD_CNAE20_DIVISAO' for igual nos dois dataframes, as informações das colunas de df_divcnae.

df2 = df.join(df_divcnae, df['CD_CNAE20_DIVISAO'] == df_divcnae['cd_cnae_divisao'], 'left')

display(df2.limit(10)) #observe as novas colunas incluídas ao final das colunas do df, todas provenientes de df_divcnae.

# COMMAND ----------

# MAGIC %md
# MAGIC ##![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) **DICA**
# MAGIC Para mais informações e exemplos, acesse: https://sparkbyexamples.com/pyspark/pyspark-join-explained-with-examples/

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.10 drop**<br>
# MAGIC Usado para remover colunas indicadas em um dataframe.

# COMMAND ----------

#removendo duas colunas (dh_insercao_trs e kv_process_control) do dataframe gerado com o join (df2)
df2 = df2.drop('dh_insercao_trs','kv_process_control')

df2.printSchema() #observe que essas colunas não fazem mais parte do dataframe

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.11 withColumn**<br>
# MAGIC A função `withColumn` é usada para manipular uma coluna ou para criar uma nova coluna com a coluna existente. É uma função de transformação, em que também podemos alterar o tipo de dados de qualquer coluna existente no dataframe.
# MAGIC
# MAGIC P.S.: *A função `f.substring` foi usada dessa forma porque a `substring` faz parte da lista de funções carregadas no item 4. Para maiores detalhes, veja novamente o [item 4](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/4355373230923589).*

# COMMAND ----------

#adicionando uma coluna com o código da região geográfica (CD_REGIAO) com base no primeiro caracter da coluna CD_UF.
#o cast("string") no final foi usado para converter o valor que entraria como numérico para string
df2 = df2.withColumn('CD_REGIAO', f.substring(f.col('CD_UF'), 1, 1).cast("string"))

#observe o uso da função "substring" para extrair o primeiro caracter de CD_UF
#substring(<campo de origem>,<posição de início>,<comprimento da nova string>)

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.12 when**<br>
# MAGIC A função `when` é usada para exibir uma saída com base em uma condição particular. Ela avalia a condição fornecida e, em seguida, retorna os valores de acordo com o que foi informado.
# MAGIC <br>
# MAGIC Quando foi usar essa função, pense da seguinte forma:
# MAGIC
# MAGIC ~~~
# MAGIC when(colunaXYZ == ABC, DEF)                        #quando a colunaXYZ for igual a ABC então faça o valor ser igual a DEF
# MAGIC when(colunaXYZ == ABC, DEF).otherwise(GHF)         #quando a colunaXYZ for igual a ABC então faça o valor ser igual a DEF, caso contrário faça o valor ser igual a GHF
# MAGIC
# MAGIC ~~~
# MAGIC P.S.: *As funções `f.when` e `f.lit` foram usadas dessa forma porque são parte da lista de funções carregadas no item 4. Para maiores detalhes, veja novamente o [item 4](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/4355373230923589).*

# COMMAND ----------

#será gerada uma nova coluna (comando withColumn) chamada 'DESC_REGIAO' e os valores dessa nova coluna serão gerados com base em uma condição testada na variável 'CD_REGIAO'.
#sempre que o valor de 'CD_REGIAO' for 1, a 'CD_REGIAO' irá assumir o valor 'Região Norte' e assim sucessivamente. Ao final ainda é colocado uma condição para avaliar a exceção (otherwise) e atribuir um valor para ela, que no caso, foi o texto 'Região não identificada'.
df2 = df2.withColumn('DESC_REGIAO', 
                     f.when(f.col('CD_REGIAO') == f.lit(1),'Região Norte')
                      .when(f.col('CD_REGIAO') == f.lit(2),'Região Nordeste')
                      .when(f.col('CD_REGIAO') == f.lit(3),'Região Sudeste')
                      .when(f.col('CD_REGIAO') == f.lit(4),'Região Sul')
                      .when(f.col('CD_REGIAO') == f.lit(5),'Região Centro-Oeste')
                     .otherwise(f.lit('Região não identificada'))
                    )

#gerando uma tabela para mostrar o resultado da implementação
display(df2
        .filter(f.col('ANO')=='2019')        #filtrando os registros para apresentar apenas o ano de 2019 e dessa maneira tornar a checagem mais rápida
        .select('CD_REGIAO','DESC_REGIAO')   #selecionando o grupo de variáveis que se deseja avaliar
        .groupBy('CD_REGIAO','DESC_REGIAO')  #fazendo o agrupamento das variáveis que serão avaliadas
        .count()                             #contando o número de registros
        .sort('CD_REGIAO'))                  #ordenando os dados de maneira crescente com base na coluna 'CD_REGIAO'

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.13 lit**<br>
# MAGIC A função `lit` atribui um valor constante ou literal como uma nova coluna ao DataFrame ou pode ser usado como uma condição de validação do conteúdo de uma coluna.
# MAGIC
# MAGIC <br>O comando executado anteriormente explorou bastante o uso dessa função.<br>
# MAGIC Observe que todas as vezes que for encontrado *literalmente* o valor 1 na coluna 'CD_REGIAO', o comando atribui um valor 'Região Norte' na variável 'DESC_REGIAO', quando encontra 2, atribui 'Região Nordeste' e assim sucessivamente. Ao fim, se não for encontrado nenhum dos valores indicados, toda a coluna 'DESC_REGIAO' receberá um valor constante dado por 'Região não identificada'.
# MAGIC
# MAGIC ~~~
# MAGIC df2 = df2.withColumn('DESC_REGIAO', 
# MAGIC                      f.when(f.col('CD_REGIAO') == f.lit(1),'Região Norte')
# MAGIC                       .when(f.col('CD_REGIAO') == f.lit(2),'Região Nordeste')
# MAGIC                       .when(f.col('CD_REGIAO') == f.lit(3),'Região Sudeste')
# MAGIC                       .when(f.col('CD_REGIAO') == f.lit(4),'Região Sul')
# MAGIC                       .when(f.col('CD_REGIAO') == f.lit(5),'Região Centro-Oeste')
# MAGIC                      .otherwise(f.lit('Região não identificada'))
# MAGIC                     )
# MAGIC ~~~
# MAGIC
# MAGIC *O comando não será executado novamente por já ter sido executado e detalhado no item 5.12*<br><br>
# MAGIC P.S.: *As funções `f.when` e `f.lit` foram usadas dessa forma porque são parte da lista de funções carregadas no item 4. Para maiores detalhes, veja novamente o [item 4](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/4355373230923589).*

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.14 funções de agregação**<br>
# MAGIC Existem várias funções de agregação que podem ser usadas nas suas análises, algumas inclusive usadas nesse notebook.
# MAGIC
# MAGIC | Método | Descrição |
# MAGIC |--------|-------------|
# MAGIC | `avg(..)` | Calcula a média para uma determinada coluna ou condição. |
# MAGIC | `count(..)` | Conta o número de registros que atendem a uma determinada condição |
# MAGIC | `sum(..)` | Calcula a soma para uma determinada coluna ou condição. |
# MAGIC | `min(..)` | Calcula o valor mínimo para uma determinada coluna ou condição. |
# MAGIC | `max(..)` | Calcula o valor máximo para uma determinada coluna ou condição. |
# MAGIC | `mean(..)` | Calcula a média para uma determinada coluna ou condição (mesma função do `avg`) |
# MAGIC | `agg(..)` | Computa o valor agregado de uma coluna. É útil quando precisamos fazer operações agregadas em colunas do DataFrame. As funções agregadas operam em um grupo de linhas e calculam um único valor de retorno para cada grupo. |
# MAGIC | `pivot(..)` | Faz o pivoteamento de uma determinada coluna do dataframe e gera a agregação indicada. |
# MAGIC

# COMMAND ----------

#USANDO AVG

'''
Exemplo usando avg para calcular a MÉDIA de dias de afastamento (VL_DIAS_AFASTAMENTO) por divisão da CNAE (CD_CNAE20_DIVISAO)
'''

display(df2
        .filter(f.col('ANO')=='2019')                                                    # Filtrando os registros para apresentar apenas o ano de 2019
        .select('CD_CNAE20_DIVISAO','VL_DIAS_AFASTAMENTO')                               # Selecionando apenas o subconjunto de variáveis de interesse
        .groupby('CD_CNAE20_DIVISAO')                                                    # Agrupando o resultado por uma variável específica
        .avg()                                                                           # Calculando a média da variável numérica
        .sort('avg(VL_DIAS_AFASTAMENTO)',ascending=False)                                # Ordenando os dados de forma decrescente pelo resultado da média de dias de afastamento - avg(VL_DIAS_AFASTAMENTO)
        .withColumnRenamed('avg(VL_DIAS_AFASTAMENTO)','MÉDIA DE DIAS DE AFASTAMENTO'))   # Dando um nome mais amigável para a coluna de resultados. Esse comando não foi explicado separadamente, mas basicamente está renomeando a coluna que vai apresentar o resultado como 'avg(VL_DIAS_AFASTAMENTO)' por 'MÉDIA DE DIAS DE AFASTAMENTO'

# COMMAND ----------

#EXEMPLO USANDO AGG, MAX E MIN

df_max_min = (df2
              .filter(f.col('ANO')=='2019')                                                 # filtrando 2019 para diminuir o número de registros
              .select('VL_REMUN_MEDIA_NOM', 'VL_REMUN_MEDIA_SM')                            # selecionando as variáveis de interesse
              .agg                                                                          # agg é usado para montar uma agregação das colunas conforme o cálculos que serão passados no decorrer do código
              (
                (f.max('VL_REMUN_MEDIA_NOM').alias('Maior salário (nominal)')),             # max está sendo usado para retornar o valor máximo da coluna VL_REMUN_MEDIA_NOM dentro do agg
                (f.max('VL_REMUN_MEDIA_SM').alias('Maior salário (em salários mínimos)')),  # max está sendo usado para retornar o valor máximo da coluna VL_REMUN_MEDIA_SM dentro do agg
                (f.min('VL_REMUN_MEDIA_NOM').alias('Menor salário (nominal)')),             # min está sendo usado para retornar o valor mínimo da coluna VL_REMUN_MEDIA_NOM dentro do agg
                (f.min('VL_REMUN_MEDIA_SM').alias('Menor salário (em salários mínimos)'))   # min está sendo usado para retornar o valor mínimo da coluna VL_REMUN_MEDIA_SM dentro do agg
              )
             )

print('Os maiores e menores salários de 2019 foram os seguintes:')
df_max_min.show()

del df_max_min

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **2.15 distinct** <br>
# MAGIC
# MAGIC O comando `distinct` é utilizado para retornar apenas uma ocorrência de campos que contenham dados repetidos. Esse recurso é útil para eliminar a duplicidade de informações e, assim, recuperar apenas o que será utilizado dali em diante. Imagine que tenha uma tabela com um grande volume de dados e com diversas pessoas de cidades em comum ou não. Se fizéssemos um `select` apenas para descobrir quais são as cidades existentes em uma tabela e tivéssemos dez pessoas cadastradas que moram em São Paulo, por exemplo, essa cidade seria listada dez vezes, o que, nesse caso, é desnecessário.
# MAGIC
# MAGIC O comando `distinct`, portanto, elimina a redundância de informação. Dessa forma, o retorno da nossa consulta ao utilizar esse recurso, seria apenas o de uma linha com a informação “São Paulo”.

# COMMAND ----------

# Imagine que se queira saber todos os códigos CNAE que existem na base da RAIS de 2019.
# O comando select vai retornar uma coluna com apenas as 1000 primeiras linhas da base, com muitos códigos repetidos e não teremos como saber, de fato, se teremos todos os códigos de CNAE existentes na base
display(df2.filter(f.col('ANO')=='2019').select('CD_CNAE20_DIVISAO'))

# COMMAND ----------

#Para saber isso então, será necessário usar o comando distinct associado ao código, eliminando essas duplicações e trazendo todos os valores distintos contidos nessa coluna.
display(df2.filter(f.col('ANO')=='2019').select('CD_CNAE20_DIVISAO').distinct())

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.16 escrever dados no data lake**<br>
# MAGIC
# MAGIC Da mesma forma que foi possível ler arquivos do datalake, é possível também escrever (salvar) dados no datalake.<br>
# MAGIC A partir do momento que suas análises estão associadas a um dataframe, poderá salvá-lo usando o comando `write`.

# COMMAND ----------

#Criando um dataframe (df_agg) com o cálculo da média de dias de afastamento do trabalho pelos trabalhadores de uma determinada atividade econômica, no ano de 2019.

df_agg = (df2
          .filter(f.col('ANO')=='2019')
          .groupby('CD_CNAE20_DIVISAO','NM_CNAE_DIVISAO')
          .agg(f.avg('VL_DIAS_AFASTAMENTO')
               .alias('MEDIA_DE_DIAS_DE_AFASTAMENTO'))
          .sort('MEDIA_DE_DIAS_DE_AFASTAMENTO',ascending=False))

# COMMAND ----------

#Esse dataframe será salvo no datalake em dois formatos (parquet e csv).

#Inicialmente deve indicar o caminho do diretório ao qual você tem acesso de escrita (o que foi usado aqui possivelmente não será o que você tem acesso).
#Por padrão, os diretório UDS disponibilizados para a sua área permitirão esse tipo de ação e você pode usá-los para isso.

path_resultado_parquet = "/Volumes/lab_sti_cda/default/uds_inteligencia/resultados/arquivos_parquet/"
path_resultado_csv = "/Volumes/lab_sti_cda/default/uds_inteligencia/resultados/arquivos_csv/"

#Para salvar em PARQUET use o comando abaixo.
#O parâmetro coalesce(n) é usado aqui para fixar que o arquivo gerado terá apenas uma partição.
#No caso do parquet, esse parâmetro é opcional e você pode também deixar o Databricks escolher a melhor forma de particionamento dos dados.
#O mode='overwrite' vai fazer com que o arquivo sempre sobrescreva o arquivo existente.

df_agg.coalesce(1).write.parquet(path_resultado_parquet, mode='overwrite')

#Para salvar em CSV use o comando abaixo.
#O parâmetro coalesce(n) é usado aqui para fixar que o arquivo gerado terá apenas uma partição.
#No caso do csv, esse parâmetro é recomendado para que seja gerado um arquivo único contendo seus dados.
#O mode='overwrite' vai fazer com que o arquivo sempre sobrescreva o arquivo existente.
#O header=True indica que esse arquivo deve conter os nomes das colunas
#O sep=';' indica que nesse caso o separador das colunas é um ponto-e-vírgula

df_agg.coalesce(1).write.csv(path_resultado_csv, mode='overwrite', header=True, sep=';')

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# DBTITLE 1,6. Usando outras linguagens
# MAGIC %md
# MAGIC Ao criar um notebook, será necessário indicar a linguagem padrão a ser usada nele. Por padrão, recomenda-se o uso da linguagem Python via pySpark.<br><br>
# MAGIC No entanto, outras linguagens são permitidas, inclusive com a possibilidade de serem usadas em uma trecho de código específico. Para usar SQL em uma célula, por exemplo, basta iniciar a célula com `%sql` que o Databricks irá entender que todo aquele conteúdo não estará mais usando a linguagem padrão (Python) e sim SQL.<br><br>
# MAGIC Em alguns casos, pode ser mais simples montar uma query SQL do que fazer uma programação usadno pyspark, no entanto, cabe ressaltar que usando SQL não é possível gerar dataframes na memória e o processamento não ocorre de maneira distribuída.

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from datalake__biz.oni.oni_bases_referencia_cnae_cnae_20__cnae_divisao;
# MAGIC
# MAGIC /*
# MAGIC Exemplo de SQL em uma célula.
# MAGIC */

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)

# COMMAND ----------

# DBTITLE 1,7. Teclas de Atalho
# MAGIC %md
# MAGIC **Observação**<br>
# MAGIC Algumas teclas de atalho funcionam com a célula selecionada (Command Mode), mas não no modo de edição (Edition Mode).<br> 
# MAGIC Para sair do modo de edição e manter a célula selecionada, pressione a tecla **esc**.<br>
# MAGIC
# MAGIC **Mais usadas**
# MAGIC - **a**: abre uma célula de código acima *(**a**bove)* da célula selecionada<br>
# MAGIC - **b**: abre uma célula de código abaixo *(**b**elow)* da célula selecionada<br>
# MAGIC - **dd**: delete a célula selecionada<br>
# MAGIC - **z**: volta com célula deletada para o exato ponto em que ela existia antes de ser deletada<br>
# MAGIC - **c**: copia a célula completa<br>
# MAGIC - **x**: recorta uma célula completa
# MAGIC - **v**: cola uma célula copiada ou recortada<br>
# MAGIC <br>
# MAGIC - **Crtl+c, Ctrl+v, Crtl+x, Ctrl+z**: possuem o mesmo efeito de outros aplicativos, mas só funcionam no modo edição<br>
# MAGIC <br>
# MAGIC - **Crtl+Enter**: executa a célula (funciona com a célula no modo edição ou no modo seleção)
# MAGIC <br>
# MAGIC
# MAGIC **Mais algumas opções...**<br>
# MAGIC <img src="https://docs.microsoft.com/pt-br/azure/databricks/_static/images/notebooks/short-cuts.png"/></a>

# COMMAND ----------

# MAGIC %md
# MAGIC [Voltar ao índice](https://adb-6523536500265509.9.azuredatabricks.net/?o=6523536500265509#notebook/1176777337395809/command/2249077497002388)