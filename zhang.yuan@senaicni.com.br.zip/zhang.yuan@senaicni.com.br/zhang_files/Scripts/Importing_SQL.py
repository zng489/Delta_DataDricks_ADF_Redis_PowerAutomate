# Databricks notebook source
def Saving_Files_From_SQL(Table_Name,address):
  df = spark.sql(f"select * from {Table_Name}")
  saving_df = df.coalesce(1).write.csv(f'{address}', mode='overwrite')
  # String problema => print(f"This is a book by {a_name}.")
  return saving_df

# COMMAND ----------

#%python
#--armazenamento no dw do databricks de tabela do azure storage

from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/uds/uniepro/saude/dim/geo/dim_geo.csv'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("csv").option("header","true").option('sep',';').load(path)
df.display()

#.option("encoding", "ISO-8859-1")
#datalake / uds / uniepro / saude / dim
#df.write.format("csv").mode("overwrite").saveAsTable("mapa_da_saude.dim_geobr")

# COMMAND ----------

df.write.format("csv").mode("overwrite").saveAsTable("mapa_da_saude.dim_geo")

# COMMAND ----------

#%python
#--armazenamento no dw do databricks de tabela do azure storage

from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/uds/uniepro/mapa_trabalho_TEMP/Projecao/DIM_SETOR'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)

#datalake / uds / uniepro / saude / dim
#df.write.format("parquet").mode("overwrite").saveAsTable("mapa_da_saude.f_sinan_lerd")

# COMMAND ----------

df.display()

# COMMAND ----------

df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)

# COMMAND ----------

#f = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)
#f.write.format("parquet").saveAsTable("mapa_da_saude.f_cat")
#rint(path)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create database mapa_da_saude
# MAGIC --drop table mapa_da_saude
# MAGIC
# MAGIC --drop table /FileStore/tables/.mapa_da_saude

# COMMAND ----------

#df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)
df.write.format("parquet").mode("overwrite").saveAsTable("mapa_da_saude.f_sinan_lerd")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC Select * from mapa_da_saude.f_sinan_lerd

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE mapa_da_saude

# COMMAND ----------


from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

#a = '/tmp/dev/trs/ms_sinan/pair/'
#var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
#path = f'{var_adls_uri}{a}'
df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Full_cbo')

df.write.format("parquet").mode("overwrite").saveAsTable("mapa_da_saude.dim_cbo")

# COMMAND ----------

class Escritor():
    def __init__(self):
        pass

    def escreve(self, text):
        print(text)

    @classmethod
    def escreve_novo(cls, text):
        print(text)


# COMMAND ----------

x = Escritor()

# COMMAND ----------

x.escreve("Olá!")

# COMMAND ----------


Escritor.escreve("Olá!") # Não vai executar
Escritor.escreve_novo("Olá!") # Vai executar

# COMMAND ----------

# Python program to demonstrate
# use of class method and static method.
from datetime import date
  
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
      
    # a class method to create a Person object by birth year.
    @classmethod
    def fromBirthYear(cls, name, year):
        return cls(name, date.today().year - year)
      
    # a static method to check if a Person is adult or not.
    @staticmethod
    def isAdult(age):
        return age > 18
  
person1 = Person('mayank', 21)
person2 = Person.fromBirthYear('mayank', 1996)
  
print (person1.age)
print (person2.age)
  
# print the result
print (Person.isAdult(22))

# COMMAND ----------

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
      
    # a class method to create a Person object by birth year.
    @classmethod
    def fromBirthYear(cls, name, year):
        return cls(name, date.today().year - year)
      
    # a static method to check if a Person is adult or not.
    @staticmethod
    def isAdult(age):
        return age > 18
  
person1 = Person('mayank', 21)
person2 = Person.fromBirthYear('mayank', 1996)
  
print (person1.age)
print (person2.age)
  
# print the result
print (Person.isAdult(22))

# COMMAND ----------



# COMMAND ----------

#uds/uniepro/mapa_trabalho_TEMP/Projecao/DIM_OCUPACAO/

# COMMAND ----------


from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/uds/uniepro/mapa_trabalho_TEMP/Projecao/DIM_OCUPACAO/'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)
df.display()

# COMMAND ----------


from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/uds/uniepro/mapa_trabalho/raw/CBO6/'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df_0 = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)
df_0.display()

# COMMAND ----------


from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/uds/uniepro/mapa_trabalho/raw/CBO6/'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)
df.display()


# COMMAND ----------

df_2008_2018_SEM_DUP_CPF = df_0.join(df, 'COD_CBO4', how='left')

# COMMAND ----------

df_2008_2018_SEM_DUP_CPF

# COMMAND ----------

df_2008_2018_SEM_DUP_CPF.coalesce(1).write.option("encoding", "ISO-8859-1").option('header','true').parquet('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Full_cbo', mode='overwrite')

# COMMAND ----------

df_2008_2018_SEM_DUP_CPF.display()

# COMMAND ----------

df.columns

# COMMAND ----------


from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/tmp/dev/trs/inss/cat/'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("encoding", "latin1").option("header","true").option('sep',';').load(path)
df.display()

# COMMAND ----------

df.select('DS_INDICA_OBITO_ACIDENTE').distinct().show()

# COMMAND ----------


from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/tmp/dev/trs/inss/cat/'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)
df.display()

# COMMAND ----------

df.filter(f.col('INDICA_OBITO_ACIDENTE').contains('NÃ£o')).display()

# COMMAND ----------



# COMMAND ----------

df.select('INDICA_OBITO_ACIDENTE').contains('o')

# COMMAND ----------

from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/tmp/dev/trs/inss/cat/'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("parquet").option("encoding", "ISO-8859-1").option("header","true").option('sep',';').load(path)
df.display()



# COMMAND ----------

df.select('DS_INDICA_OBITO_ACIDENTE').distinct().collect()

# COMMAND ----------

df = df.withColumn('DS_INDICA_OBITO_ACIDENTE', regexp_replace(col('DS_INDICA_OBITO_ACIDENTE'), 'Não                 ','Não')).withColumn('DS_INDICA_OBITO_ACIDENTE', regexp_replace(col('DS_INDICA_OBITO_ACIDENTE'), 'NÃ£o                 ','Não')).withColumn('DS_INDICA_OBITO_ACIDENTE', regexp_replace(col('DS_INDICA_OBITO_ACIDENTE'), 'Sim                 ','Sim'))

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

df.select('DS_INDICA_OBITO_ACIDENTE').distinct().collect()

# COMMAND ----------

df.select('DS_SEXO').distinct().collect()

# COMMAND ----------

df = df.withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Feminino  ','Feminino'))

# COMMAND ----------

df = df.withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Masculino           ','Masculino')).withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Indeterminado       ','Indeterminado')).withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Não Informado       ','Não Informado')).withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Feminino     ','Feminino')).withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Feminino            ','Feminino')).withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Masculino    ','Masculino')).withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'NÃ£o Informado       ','Não Informado')).withColumn('DS_SEXO', regexp_replace(col('DS_SEXO'), 'Feminino       ','Feminino'))

# COMMAND ----------

df.select('DS_INDICA_OBITO_ACIDENTE').distinct().collect()

# COMMAND ----------

df

# COMMAND ----------

df.select('DS_SEXO').distinct().collect()

# COMMAND ----------

df.coalesce(1).write.option("encoding", "ISO-8859-1").option('header','true').csv('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/dfdfdf', mode='overwrite')

# COMMAND ----------

df.columns

# COMMAND ----------

for x in df.columns:
  df = df.withColumn(x, regexp_replace(col(x), ' ',''))

# COMMAND ----------

df

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.functions import *
import pyspark.sql.functions as f
import pandas as pd

a = '/uds/uniepro/data/dfdfdf/'
var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = f'{var_adls_uri}{a}'
df = spark.read.format("csv").option("encoding", "ISO-8859-1").option("header","true").option('sep',',').load(path)
df.display()

# COMMAND ----------

df.write.format("csv").option("encoding", "ISO-8859-1").mode("overwrite").saveAsTable("mapa_da_saude.f_inss_cat")

# COMMAND ----------

