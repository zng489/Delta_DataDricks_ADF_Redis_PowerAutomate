# Databricks notebook source
https://spark.apache.org/docs/3.1.1/api/python/reference/api/pyspark.sql.Column.html#pyspark.sql.Column
'''python

from pyspark.sql.functions import when, col,lit, substring .... '''

# COMMAND ----------



# COMMAND ----------

def Adding(number:'integer')->'Soma':
  df = 10 + number
  return df

# COMMAND ----------

#dbutils.notebook.run("notebook_name", time(in sec) ,{ " "db_name" : "jmdc_20180731_test"}) @Christian Rodriguez @jayashree @Roger Erens
#
#For example:
#
#dbutils.notebook.run("notebook_1", 600,{ "db_name" : "jmdc_20180731_test"})
#
#Please let me know if you do have any issues.
#
#Mail id : vinayakbhrdwj@gmail.com

# COMMAND ----------

# MAGIC %md pip in databricks

# COMMAND ----------

dbutils.library.installPyPI("openpyxl")
import openpyxl

# COMMAND ----------

# MAGIC %md Reading

# COMMAND ----------

df = spark.read.format("csv").option("header","true").option('sep', ';').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/projecoes-daniel.csv')

df.display()

df = spark.read.parquet(var_adls_uri)

# COMMAND ----------

# MAGIC %md Saving

# COMMAND ----------

df.coalesce(1).write.option("encoding", "ISO-8859-1").option('header','true').csv('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/dfdfdf', mode='overwrite')

# COMMAND ----------

# MAGIC %md Spark Functions

# COMMAND ----------



columns = ["Category","ID","Value","string","Truth", 'Ponto_Virgula']
data = [("A", 1, 121.44, "true", True, 'um,dois'), ("B", 2, 300.01, "false", False, 'tres_quatro'),
        ("C", 3, 10.99, "none" , None, 'dois,tres'), ("D", 4, 33.87, "true" , True, 'cinco')]
df = spark.createDataFrame(data=data,schema=columns)
df.show()

# COMMAND ----------

df

# COMMAND ----------

#     data = [{"Category": 'A', "ID": 1, "Value": 121.44, "Truth": True},
#             {"Category": 'B', "ID": 2, "Value": 300.01, "Truth": False},
#             {"Category": 'C', "ID": 3, "Value": 10.99, "Truth": None},
#             {"Category": 'E', "ID": 4, "Value": 33.87, "Truth": True}
#             ]
#     
#     2. Import and create a SparkSession:
#     
#     from pyspark.sql import SparkSession
#     spark = SparkSession.builder.getOrCreate()
#     
#     3. Create a DataFrame using the createDataFrame method. Check the data type to confirm the variable is a DataFrame:
#     
#     df = spark.createDataFrame(data)
#     type(df)

# COMMAND ----------

# MAGIC %md 1- First Function

# COMMAND ----------

df.display()

# COMMAND ----------

df.columns[0]

# COMMAND ----------

df.columns[1]

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

for column in df.columns:
    print(column)
    df = df.withColumnRenamed(column, DF_1)
    '''
    df = df.withColumnRenamed('col_1', DF_1)
    -> "df" must have transformations col_1 contained inside in "df"
    df = df.withColumnRenamed('col_2', DF_1)
    '''

# COMMAND ----------

def rename_columns(dataframe):
  for column in dataframe.columns:
    print(columns)
    DF_1 = 'New_String ' + column
    dataframe = dataframe.withColumnRenamed(column, DF_1)
  return dataframe


rename_columns(df).display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

def rename_columns(column):
  DF = 'LOL LOL ' + column
  return DF

DATAFRAME_COLUMN_1 = df.withColumnRenamed('ID', rename_columns(df.columns[1]))

DATAFRAME_COLUMN_1.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

from pyspark.sql.types import *

def replace_function(df):
  from unicodedata import normalize  
  import re
  #regex = re.compile(r'[.,;{}()\n\t=]')
  DF = df + ' Adding_String '
  return DF

function = udf(lambda x: replace_function(x), StringType() )


DataFrame_2 = df.withColumn('Category', function(col('Category')))

# COMMAND ----------

DataFrame_2.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

def replace_function(df):
  from unicodedata import normalize  
  import re
  #regex = re.compile(r'[.,;{}()\n\t=]')
  DF = df.replace('e',' REPLACING_VALUES')
  return DF

function = udf(lambda x: replace_function(x), StringType() )

DataFrame_3 = df.withColumn('string', function(col('string')))
DataFrame_3.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

df.display()

# COMMAND ----------

from pyspark.sql.functions import pandas_udf, PandasUDFType

# Use pandas_udf to define a Pandas UDF
@pandas_udf('string', PandasUDFType.SCALAR)
# Input/output are both a pandas.Series of doubles

def pandas_plus_one(df):
  from unicodedata import normalize  
  import re
  DF = df.replace('A',' REPLACING_VALUES')
  return DF

# COMMAND ----------

DataFrame_4 = df.withColumn('Category', pandas_plus_one(col('Category')))
DataFrame_4.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

from unicodedata import normalize  
import re

regex = re.compile(r'[.,;{}()\n\t=]')
for col in df.columns:
  col_renamed = regex.sub('', normalize('NFKD', col.strip())
                          .encode('ASCII', 'ignore')        
                          .decode('ASCII')                 
                          .replace(' ', '_')                    
                          .replace('-', '_'))
  

# COMMAND ----------

def rename_columns(df):
  from unicodedata import normalize  
  import re
  
  regex = re.compile(r'[.,;{}()\n\t=]')
  for col in df.columns:
      col_renamed = regex.sub('', normalize('NFKD', col.strip())
                             .encode('ASCII', 'ignore')        
                             .decode('ASCII')                 
                             .replace(' ', '_')                    
                             .replace('-', '_')
                             .replace('/', '_')
                             .replace('$', 'S')
                             .upper())
      df = df.withColumnRenamed(col, col_renamed)
  return df


################################################################
# def replace(df):
#   text = df.replace('J','ZZZZZZ')
#   return text

# from pyspark.sql.functions import *
# df.withColumn("names_replace", replace(col('names_upper')))
# TypeError: 'Column' object is not callable
################################################################


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##### regex_replace with java regex

# COMMAND ----------

from pyspark.sql.functions import *
df_teste = df.withColumn('FORMACAO_INICIAL_BASE', round(col('FORMACAO_INICIAL_BASE'),2))
df_teste = df.withColumn('FORMACAO_INICIAL_BASE', regexp_replace(col('FORMACAO_INICIAL_BASE'), '\\.',','))

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.types import *

def replace_function(df):
  from unicodedata import normalize  
  import re
  #regex = re.compile(r'[.,;{}()\n\t=]')
  DF = df.replace('_',',,,,,,,,,,,,,,,,,,,,,,,')
  return DF

function = udf(lambda x: replace_function(x), StringType() )

# COMMAND ----------

DataFrame_5 = df.withColumn('Ponto_Virgula', function(f.col('Ponto_Virgula')))
DataFrame_5.display()

# .withColumn('datafinal', regexp_replace(col('datafinal'), '\\{ñ','0'))\

# COMMAND ----------

.withColumn('datafinal', regexp_replace(col('datafinal'), '\\{ñ','0'))\

# COMMAND ----------

import string
def remove_punct(text):
    return text.translate(str.maketrans('', '', string.punctuation))

import re
def removeEmoji(text):
    regrex_pattern = re.compile(pattern = "["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           "]+", flags = re.UNICODE)
    return regrex_pattern.sub(r'',text)

from pyspark.sql.functions import udf
punct_remove = udf(lambda s: remove_punct(s))
removeEmoji = udf(lambda s: removeEmoji(s))
但我得到以下错误:

TypeError                                 Traceback (most recent call last)
<ipython-input-29-e5d42d609b59> in <module>()
----> 1 new_df = new_df.withColumn("content", remove_punct(df_merge["content"]))
      2 new_df.show(5)
<ipython-input-21-dee888ef5b90> in remove_punct(text)
      2 
      3 def remove_punct(text):
----> 4     return text.translate(str.maketrans('', '', string.punctuation))
      5 
      6 
TypeError: 'Column' object is not callable
如何解决？有没有其他方法让用户编写的函数在数据帧上运行？

谢谢你，)

###堆栈跟踪表明您正在直接调用Python方法，而不是udf。

remove_punct是一个普通的Python函数，而punct_remove是一个udf，可以用作withColumn调用的第二个参数。

解决这个问题的一种方法是在withColumn调用中使用punct_remove而不是remove_punct。

另一种减少Python函数和udf混淆的方法是使用@udf注释:

from pyspark.sql import functions as F
from pyspark.sql import types as T
@F.udf(returnType=T.StringType())
def remove_punct(text):
    return text.translate(str.maketrans('', '', string.punctuation))
  
  
df.withColumn("content", remove_punct(F.col("content"))).show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

import pyspark.sql.functions as F

df.select(F.col('col_1'), F.col('col_2'), F.col('col_3'))

# or

df.select(df.col_1, df.col_2, df.col_3)

# or

df.select(df['col_1'], df['col_2'], df['col_3'])

# COMMAND ----------

def changeencode(data):
  cols = data.columns
  for col in cols:
    if data[col].dtype == 'O':
      data[col] = data[col].str.decode('utf-8').str.encode('ascii', 'ignore')
  return data 

# COMMAND ----------

pyspark.sql.Column¶
class pyspark.sql.Column(jc)[source]
A column in a DataFrame.

Column instances can be created by:

# 1. Select a column out of a DataFrame
df.colName
df["colName"]

# 2. Create from an expression
df.colName + 1
1 / df.colName

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.functions import *

def upper(df):
  text = df.upper()
  return text

from pyspark.sql.functions import *
df = df.withColumn("names_upper", upper(f.col('name')))
df.show()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # WORKING WITH PYSPARK,SAVING,SQL, and ETC

# COMMAND ----------

df_2008 = df.filter(f.col('ANO') == 2008).filter(f.col('FL_VINCULO_ATIVO_3112') == 1)
print(df_2008.select("COUNT_CD_SEXO").rdd.keys().sum())
#print(df_2008.count())
df_2008.coalesce(1).write.format("parquet").option("header", "true").save('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/rais_05_10_15_20/rais_25_2008_parquet/', mode='overwrite')
df_2008.write.format("parquet").saveAsTable("rais_25.rais_25_2008")