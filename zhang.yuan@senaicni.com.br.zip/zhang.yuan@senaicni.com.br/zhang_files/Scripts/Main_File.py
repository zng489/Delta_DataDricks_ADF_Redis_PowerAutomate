# Databricks notebook source
# https://medium.com/@YuhengD/best-practice-of-databricks-notebook-modulization-d2797dd29dd3

# COMMAND ----------

#https://docs.databricks.com/data/tables.html

# COMMAND ----------

######################################

# COMMAND ----------

# MAGIC %ls

# COMMAND ----------

dbutils.fs.help("ls")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Function Testing

# COMMAND ----------

x = %run ./Function_Test

if __name__ == "__main__":
  x

# COMMAND ----------

print(Adding(20))

# COMMAND ----------

# MAGIC %ls

# COMMAND ----------

dbutils.notebook.run("Function_Test", 60)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md 
# MAGIC # Importing_SQL

# COMMAND ----------

######################################

# COMMAND ----------

# MAGIC %run ./Importing_SQL

# COMMAND ----------

Saving_Files_From_SQL('oni_homolog.saude_catconsolidada','abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/')

# COMMAND ----------

dbutils.notebook.run("Importing_SQL", 1, {"foo": "Microsoft","foo2":'Azure'})

# COMMAND ----------

######################################

# COMMAND ----------

