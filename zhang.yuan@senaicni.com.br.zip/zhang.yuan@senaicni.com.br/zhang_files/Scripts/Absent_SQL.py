# Databricks notebook source
from pyspark.sql.window import Window
import pyspark.sql.functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import datediff,col,when,greatest

# COMMAND ----------

cbo_classificacoes = spark.read.format("csv").option("header","true").option('sep', ',').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Absent_SQL/cbo_classificacoes.csv')
#cbo_classificacoes.display()

raw_cnae_industrial = spark.read.format("csv").option("header","true").option('sep', ',').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Absent_SQL/raw_cnae_industrial.csv')
#raw_cnae_industrial.display()

rais_vinculo2008a2018 = spark.read.format("csv").option("header","true").option('sep', ',').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Absent_SQL/df_rais_vinculo2008a2018.csv')
#rais_vinculo2008a2018.display()

# COMMAND ----------

cbo_classificacoes = spark.read.format("csv").option("header","true").option('sep', ',').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Absent_SQL/cbo_classificacoes.csv')


cbo_classificacoes.createOrReplaceTempView('Table_df_cbo_classificacoes')

Spark_cbo_classificacoes = spark.sql("""SELECT * FROM Table_df_cbo_classificacoes""").withColumnRenamed('COD_CORPORATIVAS E TO INDUSTRIAIS', 'COD_CORPORATIVAS_E_TO_INDUSTRIAIS')

# COMMAND ----------

# Creating tables!!
cbo_classificacoes
cbo_classificacoes.createOrReplaceTempView('Table_df_cbo_classificacoes')


# Creating tables!!
raw_cnae_industrial
raw_cnae_industrial.createOrReplaceTempView('Table_raw_cnae_industrial')

# Creating tables!!
rais_vinculo2008a2018
rais_vinculo2008a2018.createOrReplaceTempView('Table_rais_vinculo2008a2018')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Two ways to read SQL Table in pyspark

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1 
# MAGIC ##### > DF_READING_1 = spark.sql("""SELECT * FROM Table_Name_Created""")
# MAGIC ##### > https://medium.com/analytics-vidhya/beginners-guide-on-databricks-spark-using-python-pyspark-de74d92e4885
# MAGIC
# MAGIC #####  2 
# MAGIC ##### > DF_READING_2 = spark.table("""Table_Name_Created""")
# MAGIC ##### > display(DF_READING_2.select('*'))
# MAGIC ##### > display(diamonds.select("*"))

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # 1- Working With SQL

# COMMAND ----------

# MAGIC %md
# MAGIC Error in SQL statement: AnalysisException: Attribute name "COD_CORPORATIVAS E TO INDUSTRIAIS" contains invalid character(s) among " ,;{}()\n\t=". Please use alias to rename it.;
# MAGIC Command took 0.51 seconds -- by zhang.yuan@senaicni.com.br at 13/06/2022 14:27:39 on uniepro

# COMMAND ----------

Spark_cbo_classificacoes = spark.sql("""SELECT * FROM Table_df_cbo_classificacoes""").withColumnRenamed('COD_CORPORATIVAS E TO INDUSTRIAIS', 'COD_CORPORATIVAS_E_TO_INDUSTRIAIS')

#Spark_cbo_classificacoes.createOrReplaceTempView('Spark_Table_df_cbo_classificacoes')

# COMMAND ----------

def rename_columns(dataframe):
  for column in Spark_cbo_classificacoes.columns:
    regex_column = column.replace(' ', '_')
    print(regex_column)
    dataframe = dataframe.withColumnRenamed(column, regex_column)
  return dataframe

# COMMAND ----------

rename_columns(Spark_cbo_classificacoes).display()

# COMMAND ----------

rename_columns(Spark_cbo_classificacoes).createOrReplaceTempView('Spark_Table_df_cbo_classificacoes')

rename_columns(raw_cnae_industrial).createOrReplaceTempView('Spark_Table_raw_cnae_industrial')

rename_columns(rais_vinculo2008a2018).createOrReplaceTempView('Spark_Table_rais_vinculo2008a2018')

# COMMAND ----------

# MAGIC %sql
# MAGIC --- Drop Table Table_df_cbo_classificacoes_0

# COMMAND ----------

w%sql

--- Spark_Table_df_cbo_classificacoes
--- Table_raw_cnae_industrial
--- Table_rais_vinculo2008a2018
DROP TABLE IF EXISTS Table_df_cbo_classificacoes_0;

CREATE TABLE Table_df_cbo_classificacoes_0 AS 
SELECT * FROM Spark_Table_df_cbo_classificacoes;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from Table_df_cbo_classificacoes_0

# COMMAND ----------

# 'Spark_Table_raw_cnae_industrial'

# 'Spark_Table_rais_vinculo2008a2018'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Spark_Table_raw_cnae_industrial

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from Spark_Table_rais_vinculo2008a2018

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # 2 - Working With SQL

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Table_df_cbo_classificacoes_0

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##### https://www.tutorialscampus.com/sql/delete-duplicate-rows.htm
# MAGIC
# MAGIC
# MAGIC """
# MAGIC CREATE TABLE (Create A New Table)
# MAGIC
# MAGIC EMPL_DEMO (Called EMPL_DEMO)
# MAGIC
# MAGIC AS (With The Data and structure of)
# MAGIC
# MAGIC SELECT * FROM employees WHERE 1=2; (Everything in employees where 1=2. Since 1 is never 2 - copy the structure and all 0 matching rows)
# MAGIC
# MAGIC ..Essentially copy structure and not data.
# MAGIC """

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS Temp_table;
# MAGIC create table Temp_table as
# MAGIC select * from Table_df_cbo_classificacoes_0 where 1=2;
# MAGIC
# MAGIC
# MAGIC insert into Temp_table
# MAGIC select distinct * from Table_df_cbo_classificacoes_0

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DELETE FROM Table_df_cbo_classificacoes_0

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO Table_df_cbo_classificacoes_0
# MAGIC SELECT DISTINCT * FROM Temp_table

# COMMAND ----------

cbo_classificacoes.display()

# COMMAND ----------

cbo_classificacoes.createOrReplaceTempView('TEMP_cbo_classificacoes')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from TEMP_cbo_classificacoes

# COMMAND ----------

# MAGIC %md
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/FFFF00/000000?text=+)
# MAGIC
# MAGIC ### Join

# COMMAND ----------

from pyspark.sql.window import Window
import pyspark.sql.functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import datediff,col,when,greatest

#

cbo_classificacoes = spark.read.format("csv").option("header","true").option('sep', ',').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Absent_SQL/cbo_classificacoes.csv')
#cbo_classificacoes.display()
cbo_classificacoes = cbo_classificacoes.withColumn('COD_CBO4', lpad(col('COD_CBO4'),4,'0'))
cbo_classificacoes = cbo_classificacoes.dropDuplicates(['COD_CBO4'])
cbo_classificacoes = cbo_classificacoes.select(['COD_CBO4','DESC_CBO4'])



raw_cnae_industrial = spark.read.format("csv").option("header","true").option('sep', ',').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Absent_SQL/raw_cnae_industrial.csv')
#raw_cnae_industrial.display()



rais_vinculo2008a2018 = spark.read.format("csv").option("header","true").option('sep', ',').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Absent_SQL/df_rais_vinculo2008a2018.csv')



def rename_columns(dataframe):
  for column in Spark_cbo_classificacoes.columns:
    regex_column = column.replace(' ', '_')
    print(regex_column)
    dataframe = dataframe.withColumnRenamed(column, regex_column)
  return dataframe



rename_columns(cbo_classificacoes).createOrReplaceTempView('Spark_Table_df_cbo_classificacoes')

rename_columns(raw_cnae_industrial).createOrReplaceTempView('Spark_Table_raw_cnae_industrial')

rename_columns(rais_vinculo2008a2018).createOrReplaceTempView('Spark_Table_rais_vinculo2008a2018')

# COMMAND ----------

# MAGIC %sql 
# MAGIC
# MAGIC select * from Spark_Table_df_cbo_classificacoes

# COMMAND ----------

# MAGIC %sql 
# MAGIC
# MAGIC DROP TABLE IF EXISTS TEMP_Spark_Table_rais_vinculo2008a2018;
# MAGIC create table TEMP_Spark_Table_rais_vinculo2008a2018 as
# MAGIC select * from Spark_Table_rais_vinculo2008a2018

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from TEMP_Spark_Table_rais_vinculo2008a2018;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --- Spark_Table_df_cbo_classificacoes
# MAGIC
# MAGIC --- Spark_Table_rais_vinculo2008a2018
# MAGIC
# MAGIC
# MAGIC
# MAGIC SELECT a.Nome, b.Nome
# MAGIC FROM TEMP_Spark_Table_rais_vinculo2008a2018 as A
# MAGIC RIGHT JOIN Spark_Table_rais_vinculo2008a2018 as B
# MAGIC                 ON TEMP_Spark_Table_rais_vinculo2008a201.ID_CPF = Spark_Table_rais_vinculo2008a2018.ID_CPF

# COMMAND ----------

SELECT table1.column1, table2.column2...
FROM table1
RIGHT JOIN table2
ON table1.common_field = table2.common_field;

# COMMAND ----------

df_2008_2018_SEM_DUP_CPF = df_2008_2018.join(df_2008_2018_group_by, 'ID_CPF', how='right')

# COMMAND ----------

SELECT column_name(s)
FROM table1
RIGHT JOIN table2
ON table1.column_name = table2.column_name;

# COMMAND ----------

SELECT
  aluno.nome as Aluno,
  turma.nome as Turma,
  professor.nome as Professor
FROM
  aluno
INNER JOIN
  turma ON turma.id = aluno.idturma
RIGHT JOIN
  professor ON turma.id = professor.idturma

# COMMAND ----------

SELECT Orders.OrderID, Employees.LastName, Employees.FirstName
FROM Orders
RIGHT JOIN Employees ON Orders.EmployeeID = Employees.EmployeeID
ORDER BY Orders.OrderID;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS Cbo_classificacoes_0;
# MAGIC
# MAGIC CREATE TABLE Cbo_classificacoes_0 AS 
# MAGIC
# MAGIC SELECT *, LPAD(COD_CBO4, 4, "0") AS COD_CBO4_4_Digitos FROM Table_df_cbo_classificacoes_0;
# MAGIC
# MAGIC SELECT DISTINCT
# MAGIC     column1, column2, ...
# MAGIC FROM
# MAGIC     table1;

# COMMAND ----------

# MAGIC %sql 
# MAGIC
# MAGIC Select * from Cbo_classificacoes_0;

# COMMAND ----------



# COMMAND ----------

