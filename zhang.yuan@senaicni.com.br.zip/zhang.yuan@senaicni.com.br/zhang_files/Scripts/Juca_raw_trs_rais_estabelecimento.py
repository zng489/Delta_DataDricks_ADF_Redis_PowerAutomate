# Databricks notebook source
#from cni_connectors import adls_gen1_connector as adls_conn
from pyspark.sql.window import Window
from pyspark.sql.functions import *
#from trs_control_field import trs_control_field as tcf
import json
import re


#var_adls_uri = adls_conn.adls_gen1_connect(spark, dbutils, scope="adls_gen1", #dynamic_overwrite="dynamic")
#var_adls_uri = adls_conn.adls_gen1_connect(spark, dbutils, scope="adls_gen1", #dynamic_overwrite="dynamic")

tables =  {
  "path_origin": "/usr/me/rais_estabelecimento",
  "path_destination":"/me/rais_estabelecimento"
}

dls = {"folders":{"landing":"/tmp/dev/lnd","error":"/tmp/dev/err","staging":"/tmp/dev/stg","log":"/tmp/dev/log","raw":"/tmp/dev/raw","trusted":"/tmp/dev/trs"}}
dls = {"folders":{"landing":"/lnd","error":"/err","staging":"/stg","log":"/log","raw":"/raw","trusted":"/trs"}}

adf = {
   'adf_factory_name': 'cnibigdatafactory', 
   'adf_pipeline_name': 'raw_trs_convenio_ensino_prof_carga_horaria',
   'adf_pipeline_run_id': 'p1',
   'adf_trigger_id': 't1',
   'adf_trigger_name': 'author_dev',
   'adf_trigger_time': '2020-10-14T15:00:06.0829994Z',
   'adf_trigger_type': 'Manual'
 }


raw = dls['folders']['raw']
trs = dls['folders']['trusted']


raw = dls['folders']['raw']
trs = dls['folders']['trusted']


var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
target = "{adl_path}{trs}{origin}".format(adl_path=var_adls_uri, trs=trs, origin=tables["path_destination"])
source = "{adl_path}{raw}{origin}".format(adl_path=var_adls_uri, raw=raw, origin=tables["path_origin"])
source
df = spark.read.parquet(source)

display(df.limit(5))


#df.printSchema()

#root
# |-- nm_arq_in: string (nullable = true)
# |-- ID_CEI_VINCULADO: long (nullable = true)
# |-- ID_CEPAO_ESTAB: double (nullable = true)
# |-- CD_CNAE10_CLASSE: integer (nullable = true)
# |-- ID_CNPJ_CEI: string (nullable = true)
# |-- ID_CNPJ_RAIZ: string (nullable = true)
# |-- DT_ABERTURA: integer (nullable = true)
# |-- DT_BAIXA: integer (nullable = true)
# |-- DT_ENCERRAMENTO: integer (nullable = true)
# |-- NM_EMAIL: string (nullable = true)
# |-- FL_IND_CEI_VINCULADO: integer (nullable = true)
# |-- FL_IND_ESTAB_PARTICIPA_PAT: integer (nullable = true)
# |-- FL_IND_RAIS_NEGAT: integer (nullable = true)
# |-- FL_IND_SIMPLES: integer (nullable = true)
# |-- CD_MUNICIPIO: integer (nullable = true)
# |-- CD_NATUREZA_JURIDICA: integer (nullable = true)
# |-- NM_LOGRADOURO: string (nullable = true)
# |-- NR_LOGRADOURO: double (nullable = true)
# |-- NM_BAIRRO: string (nullable = true)
# |-- NR_TELEFONE_EMPRE: long (nullable = true)
# |-- QT_VINC_ATIV: integer (nullable = true)
# |-- QT_VINC_CLT: integer (nullable = true)
# |-- QT_VINC_ESTAT: integer (nullable = true)
# |-- ID_RAZAO_SOCIAL: string (nullable = true)
# |-- CD_TAMANHO_ESTABELECIMENTO: integer (nullable = true)
# |-- CD_TIPO_ESTAB_ID: integer (nullable = true)
# |-- CD_IBGE_SUBSETOR: integer (nullable = true)
# |-- FL_IND_ATIV_ANO: integer (nullable = true)
# |-- CD_CNAE20_CLASSE: integer (nullable = true)
# |-- CD_CNAE20_SUBCLASSE: integer (nullable = true)
# |-- CD_UF: integer (nullable = true)
# |-- nr_reg: long (nullable = true)
# |-- dh_insercao_raw: timestamp (nullable = true)
# |-- dh_arq_in: timestamp (nullable = true)
# |-- ANO: integer (nullable = true)


# COMMAND ----------

# MAGIC %md 
# MAGIC ### df.filter | select | when(condition) [#]

# COMMAND ----------

# >> df.select('ANO').distinct().collect()
# >> Out[20]: [Row(ANO=2018), Row(ANO=2015), Row(ANO=2014), Row(ANO=2016), Row(ANO=2017)]
  
from pyspark.sql.functions import col

df_greater_or_equal_than_2018 = df.filter(col('ANO') == 2018).select(['ID_CNPJ_CEI',
                                                                      'ID_RAZAO_SOCIAL',
                                                                      'CD_CNAE10_CLASSE',
                                                                      'CD_CNAE20_CLASSE',
                                                                      'CD_TAMANHO_ESTABELECIMENTO',
                                                                      'CD_UF',
                                                                      'CD_MUNICIPIO',
                                                                      'QT_VINC_ATIV'])




DF_SELECTED = df_greater_or_equal_than_2018.withColumn('PORTE_ESTABELECIMENTO',
                                                when((col('CD_TAMANHO_ESTABELECIMENTO') >= '1') & (col('CD_TAMANHO_ESTABELECIMENTO') <= '3'),
                                                'MICRO').when((col('CD_TAMANHO_ESTABELECIMENTO') >= '4') & (col('CD_TAMANHO_ESTABELECIMENTO') <= '6'),
                                                'PEQUENA').when((col('CD_TAMANHO_ESTABELECIMENTO') >= '7') & (col('CD_TAMANHO_ESTABELECIMENTO') <= '8'),
                                                'MÉDIA').when((col('CD_TAMANHO_ESTABELECIMENTO') >= '9') & (col('CD_TAMANHO_ESTABELECIMENTO') <= '10'),
                                                'GRANDE').otherwise(df_greater_or_equal_than_2018.CD_TAMANHO_ESTABELECIMENTO)).withColumn('CD_UF', substring('CD_MUNICIPIO', 1,2))
display(DF_SELECTED.limit(3))

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### spark.createDataFrame(pd.read_csv | withColumn(substring) | withColumnRenamed

# COMMAND ----------

import pandas as pd

DF_MUNICIPIOS_M = spark.createDataFrame(pd.read_csv('https://raw.githubusercontent.com/leogermani/estados-e-municipios-ibge/master/municipios.csv')).withColumn('COD', substring('COD', 1,6)).withColumnRenamed("COD", "COD_MUNICIPIOS_M").withColumnRenamed("NOME", "NOME_MUNICIPIOS_M").withColumnRenamed("COD UF", "COD_UF_M")
# display(DF_MUNICIPIOS_M)


DF_UF = spark.createDataFrame(pd.read_csv('https://raw.githubusercontent.com/leogermani/estados-e-municipios-ibge/master/estados.csv')).withColumnRenamed("COD", "COD_UF_UF").withColumnRenamed("NOME", "NOME_UF_UF")
# display(df_uf)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### df_1.join(df_2, df_1['Column'] == df_2['Column'])

# COMMAND ----------

MATCHING_MUNICIPIOS = DF_SELECTED.join(DF_MUNICIPIOS_M , DF_SELECTED['CD_MUNICIPIO'] == DF_MUNICIPIOS_M['COD_MUNICIPIOS_M'])
display(MATCHING_MUNICIPIOS.limit(5))

# COMMAND ----------

MATCHING_UF = MATCHING_MUNICIPIOS.join(DF_UF, MATCHING_MUNICIPIOS['CD_UF'] == DF_UF['COD_UF_UF'])
display(MATCHING_UF.limit(3))

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### df.select | withColumnRenamed

# COMMAND ----------

MATCHING = MATCHING_UF.select(['ID_CNPJ_CEI', 'ID_RAZAO_SOCIAL', 'CD_CNAE10_CLASSE', 'CD_CNAE20_CLASSE', 'CD_TAMANHO_ESTABELECIMENTO', 'PORTE_ESTABELECIMENTO', 'CD_UF', 'NOME_UF_UF', 'SIGLA', 'CD_MUNICIPIO' , 'NOME_MUNICIPIOS_M', 'QT_VINC_ATIV']).withColumnRenamed("NOME_UF_UF", "NOME_UF").withColumnRenamed("NOME_MUNICIPIOS_M", "NOME_MUNICIPIO")


display(MATCHING)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Saving Files | df.coalesce(1).write.format('csv').option("header","true").save( )

# COMMAND ----------

#MATCHING.coalesce(1).write.format('csv').option("header","true").save("abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/Juca_Rais_Estabelecimento.csv")

# COMMAND ----------

display(MATCHING.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### groupBy | agg | sum
# MAGIC
# MAGIC ```python
# MAGIC GroupBy on multiple columns
# MAGIC df.groupBy("department","state") \
# MAGIC     .sum("salary","bonus") \
# MAGIC     .show(false)
# MAGIC ```

# COMMAND ----------

MATCHING.groupBy('ID_RAZAO_SOCIAL').agg(sum('CD_TAMANHO_ESTABELECIMENTO')).show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### df.withColumn( ,when((col, 'list comprehension').otherwise)

# COMMAND ----------

df.withColumn('New_Name_Column', when((col('column'))))
df_matched = df.select([col(c).alias(dict_items_SEM_N_A.get(c,c)) for c in df.columns])
display(df_matched.limit(4))

# COMMAND ----------

# MAGIC %md 
# MAGIC # dbutils.fs.rm(..., True )

# COMMAND ----------

# dbutils.help()
dbutils.fs.rm('dbfs:/ZY/zhang', True)

# COMMAND ----------

# MAGIC %md 
# MAGIC # spark.table | Database Tables

# COMMAND ----------

table_test = spark.table("dmfiep.dim_setor")
display(table_test.select("*"))

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Saving('dbfs:') | spark.read

# COMMAND ----------

FILE_NAME.coalesce(1).write.mode('overwrite').partitionBy('ur_partition').save('dbfs:/ZY/zhang', format="csv")

#prm = spark.read\
#.format("csv")\
#.option("header","true")\
#.option('sep', ';')\
#.load('dbfs:/ZY/zhang')

# COMMAND ----------

