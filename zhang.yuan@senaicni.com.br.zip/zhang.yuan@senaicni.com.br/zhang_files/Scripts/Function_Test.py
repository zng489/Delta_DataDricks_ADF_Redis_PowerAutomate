# Databricks notebook source
https://spark.apache.org/docs/3.1.1/api/python/reference/api/pyspark.sql.Column.html#pyspark.sql.Column
'''python

from pyspark.sql.functions import when, col,lit, substring .... '''

# COMMAND ----------



# COMMAND ----------

def Adding(number:'integer')->'Soma':
  df = 10 + number
  return df

# COMMAND ----------

#dbutils.notebook.run("notebook_name", time(in sec) ,{ " "db_name" : "jmdc_20180731_test"}) @Christian Rodriguez @jayashree @Roger Erens
#
#For example:
#
#dbutils.notebook.run("notebook_1", 600,{ "db_name" : "jmdc_20180731_test"})
#
#Please let me know if you do have any issues.
#
#Mail id : vinayakbhrdwj@gmail.com

# COMMAND ----------

# MAGIC %md pip in databricks

# COMMAND ----------

dbutils.library.installPyPI("openpyxl")
import openpyxl

# COMMAND ----------

# MAGIC %md Reading

# COMMAND ----------

df = spark.read.format("csv").option("header","true").option('sep', ';').option('encoding', 'ISO-8859-1').load('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/projecoes-daniel.csv')

df.display()

df = spark.read.parquet(var_adls_uri)

# COMMAND ----------

# MAGIC %md Saving

# COMMAND ----------

df.coalesce(1).write.option("encoding", "ISO-8859-1").option('header','true').csv('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/dfdfdf', mode='overwrite')

or 

rais_vinculo.coalesce(1).write.format("parquet").option("header", True).save(var_adls_uri + '/uds/uniepro/df_Ind_cresc_eco/raw/Dados/asdasda')

or rais_vinculo.repartition(40).write.parquet('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/df_Ind_cresc_eco/raw/Dados/asdasda', mode='overwrite')

# COMMAND ----------

# MAGIC %md Spark Functions

# COMMAND ----------

columns = ["Category","ID","Value","string","Truth", 'Ponto_Virgula']
data = [("A", 1, 121.44, "true", True, 'um,dois'), ("B", 2, 300.01, "false", False, 'tres_quatro'),
        ("C", 3, 10.99, "none" , None, 'dois,tres'), ("D", 4, 33.87, "true" , True, 'cinco')]
df = spark.createDataFrame(data=data,schema=columns)
df.show()

# COMMAND ----------

df

# COMMAND ----------

#     data = [{"Category": 'A', "ID": 1, "Value": 121.44, "Truth": True},
#             {"Category": 'B', "ID": 2, "Value": 300.01, "Truth": False},
#             {"Category": 'C', "ID": 3, "Value": 10.99, "Truth": None},
#             {"Category": 'E', "ID": 4, "Value": 33.87, "Truth": True}
#             ]
#     
#     2. Import and create a SparkSession:
#     
#     from pyspark.sql import SparkSession
#     spark = SparkSession.builder.getOrCreate()
#     
#     3. Create a DataFrame using the createDataFrame method. Check the data type to confirm the variable is a DataFrame:
#     
#     df = spark.createDataFrame(data)
#     type(df)

# COMMAND ----------

# MAGIC %md 1- First Function

# COMMAND ----------

df.display()

# COMMAND ----------

df.columns[0]

# COMMAND ----------

df.columns[1]

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

for column in df.columns:
    print(column)
    df = df.withColumnRenamed(column, DF_1)
    '''
    df = df.withColumnRenamed('col_1', DF_1)
    -> "df" must have transformations col_1 contained inside in "df"
    df = df.withColumnRenamed('col_2', DF_1)
    '''

# COMMAND ----------

def rename_columns(dataframe):
  for column in dataframe.columns:
    print(columns)
    DF_1 = 'New_String ' + column
    dataframe = dataframe.withColumnRenamed(column, DF_1)
  return dataframe


rename_columns(df).display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

def rename_columns(column):
  DF = 'LOL LOL ' + column
  return DF

DATAFRAME_COLUMN_1 = df.withColumnRenamed('ID', rename_columns(df.columns[1]))

DATAFRAME_COLUMN_1.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

for column in df.columns:
  df = df.withColumnRenamed(column, cf.normalize_str(column))

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

from pyspark.sql.types import *

def replace_function(df):
  from unicodedata import normalize  
  import re
  #regex = re.compile(r'[.,;{}()\n\t=]')
  DF = df + ' Adding_String '
  return DF

function = udf(lambda x: replace_function(x), StringType() )


DataFrame_2 = df.withColumn('Category', function(col('Category')))

# COMMAND ----------

DataFrame_2.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

def replace_function(df):
  from unicodedata import normalize  
  import re
  #regex = re.compile(r'[.,;{}()\n\t=]')
  DF = df.replace('e',' REPLACING_VALUES')
  return DF

function = udf(lambda x: replace_function(x), StringType() )

DataFrame_3 = df.withColumn('string', function(col('string')))
DataFrame_3.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

df.display()

# COMMAND ----------

from pyspark.sql.functions import pandas_udf, PandasUDFType

# Use pandas_udf to define a Pandas UDF
@pandas_udf('string', PandasUDFType.SCALAR)
# Input/output are both a pandas.Series of doubles

def pandas_plus_one(df):
  from unicodedata import normalize  
  import re
  DF = df.replace('A',' REPLACING_VALUES')
  return DF

# COMMAND ----------

DataFrame_4 = df.withColumn('Category', pandas_plus_one(col('Category')))
DataFrame_4.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

from unicodedata import normalize  
import re

regex = re.compile(r'[.,;{}()\n\t=]')
for col in df.columns:
  col_renamed = regex.sub('', normalize('NFKD', col.strip())
                          .encode('ASCII', 'ignore')        
                          .decode('ASCII')                 
                          .replace(' ', '_')                    
                          .replace('-', '_'))
  

# COMMAND ----------

def rename_columns(df):
  from unicodedata import normalize  
  import re
  
  regex = re.compile(r'[.,;{}()\n\t=]')
  for col in df.columns:
      col_renamed = regex.sub('', normalize('NFKD', col.strip())
                             .encode('ASCII', 'ignore')        
                             .decode('ASCII')                 
                             .replace(' ', '_')                    
                             .replace('-', '_')
                             .replace('/', '_')
                             .replace('$', 'S')
                             .upper())
      df = df.withColumnRenamed(col, col_renamed)
  return df


################################################################
# def replace(df):
#   text = df.replace('J','ZZZZZZ')
#   return text

# from pyspark.sql.functions import *
# df.withColumn("names_replace", replace(col('names_upper')))
# TypeError: 'Column' object is not callable
################################################################


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ##### regex_replace with java regex

# COMMAND ----------

from pyspark.sql.functions import *
df_teste = df.withColumn('FORMACAO_INICIAL_BASE', round(col('FORMACAO_INICIAL_BASE'),2))
df_teste = df.withColumn('FORMACAO_INICIAL_BASE', regexp_replace(col('FORMACAO_INICIAL_BASE'), '\\.',','))

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.types import *

def replace_function(df):
  from unicodedata import normalize  
  import re
  #regex = re.compile(r'[.,;{}()\n\t=]')
  DF = df.replace('_',',,,,,,,,,,,,,,,,,,,,,,,')
  return DF

function = udf(lambda x: replace_function(x), StringType() )

# COMMAND ----------

DataFrame_5 = df.withColumn('Ponto_Virgula', function(f.col('Ponto_Virgula')))
DataFrame_5.display()

# .withColumn('datafinal', regexp_replace(col('datafinal'), '\\{ñ','0'))\

# COMMAND ----------

.withColumn('datafinal', regexp_replace(col('datafinal'), '\\{ñ','0'))\

# COMMAND ----------

import string
def remove_punct(text):
    return text.translate(str.maketrans('', '', string.punctuation))

import re
def removeEmoji(text):
    regrex_pattern = re.compile(pattern = "["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           "]+", flags = re.UNICODE)
    return regrex_pattern.sub(r'',text)

from pyspark.sql.functions import udf
punct_remove = udf(lambda s: remove_punct(s))
removeEmoji = udf(lambda s: removeEmoji(s))
但我得到以下错误:

TypeError                                 Traceback (most recent call last)
<ipython-input-29-e5d42d609b59> in <module>()
----> 1 new_df = new_df.withColumn("content", remove_punct(df_merge["content"]))
      2 new_df.show(5)
<ipython-input-21-dee888ef5b90> in remove_punct(text)
      2 
      3 def remove_punct(text):
----> 4     return text.translate(str.maketrans('', '', string.punctuation))
      5 
      6 
TypeError: 'Column' object is not callable
如何解决？有没有其他方法让用户编写的函数在数据帧上运行？

谢谢你，)

###堆栈跟踪表明您正在直接调用Python方法，而不是udf。

remove_punct是一个普通的Python函数，而punct_remove是一个udf，可以用作withColumn调用的第二个参数。

解决这个问题的一种方法是在withColumn调用中使用punct_remove而不是remove_punct。

另一种减少Python函数和udf混淆的方法是使用@udf注释:

from pyspark.sql import functions as F
from pyspark.sql import types as T
@F.udf(returnType=T.StringType())
def remove_punct(text):
    return text.translate(str.maketrans('', '', string.punctuation))
  
  
df.withColumn("content", remove_punct(F.col("content"))).show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ========================================================================

# COMMAND ----------

import pyspark.sql.functions as F

df.select(F.col('col_1'), F.col('col_2'), F.col('col_3'))

# or

df.select(df.col_1, df.col_2, df.col_3)

# or

df.select(df['col_1'], df['col_2'], df['col_3'])

# COMMAND ----------

def changeencode(data):
  cols = data.columns
  for col in cols:
    if data[col].dtype == 'O':
      data[col] = data[col].str.decode('utf-8').str.encode('ascii', 'ignore')
  return data 

# COMMAND ----------

pyspark.sql.Column¶
class pyspark.sql.Column(jc)[source]
A column in a DataFrame.

Column instances can be created by:

# 1. Select a column out of a DataFrame
df.colName
df["colName"]

# 2. Create from an expression
df.colName + 1
1 / df.colName

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.functions import *

def upper(df):
  text = df.upper()
  return text

from pyspark.sql.functions import *
df = df.withColumn("names_upper", upper(f.col('name')))
df.show()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # WORKING WITH PYSPARK,SAVING,SQL, and ETC

# COMMAND ----------

df_2008 = df.filter(f.col('ANO') == 2008).filter(f.col('FL_VINCULO_ATIVO_3112') == 1)
print(df_2008.select("COUNT_CD_SEXO").rdd.keys().sum())
#print(df_2008.count())
df_2008.coalesce(1).write.format("parquet").option("header", "true").save('abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net/uds/uniepro/data/rais_05_10_15_20/rais_25_2008_parquet/', mode='overwrite')
df_2008.write.format("parquet").saveAsTable("rais_25.rais_25_2008")

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+)
# MAGIC
# MAGIC ### Coding in SQL in DataBricks (PySpark)
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+)

# COMMAND ----------

try:
  import databricks.koalas as ks
except:
  dbutils.library.installPyPI("koalas")

from pyspark.sql.window import Window
import pyspark.sql.functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import * 
from pyspark.sql.functions import datediff,col,when

# COMMAND ----------

columns = ["Category","ID","Value","string","Truth", 'Ponto_Virgula']
data = [("A", 1, 121.44, "true", True, 'N/A'), ("B", 2, 300.01, "false", False, 'tres_quatro'),
        ("C", 3, 10.99, "none" , None, 'dois,tres'), ("D", 4, 33.87, "true" , True, 'cinco')]

df = spark.createDataFrame(data=data,schema=columns)
df.show()

# COMMAND ----------

DF_SQL = df


# Creating table
DF_SQL.createOrReplaceTempView('Table_Test')
# table name!!

# SQL 
DF_SQL_Table_Test = spark.sql("""SELECT * FROM Table_Test""")
# https://medium.com/analytics-vidhya/beginners-guide-on-databricks-spark-using-python-pyspark-de74d92e4885

# Reading table as spark

DF_SQL_Table_Test.display()

# COMMAND ----------

DF_D = spark.table("""Table_Test""")
#display(diamonds.select("*"))

# reading table as spark

DF_D.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *, LPAD(Category, 4, "0") AS Category_LPAD FROM DF_D;
# MAGIC
# MAGIC IT DOES NOT WORK IT!!!! THIS ONE

# COMMAND ----------

SQL_CBO = spark.sql("""SELECT *, LPAD(Category, 4, "0") AS Category_LPAD FROM Table_Test""")

# COMMAND ----------

SQL_CBO.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC create database Consultas_ONI
# MAGIC
# MAGIC drop table Consultas_ONI.tb_aprendiz
# MAGIC
# MAGIC rais_df1.write.format("parquet").saveAsTable("Consultas_ONI.tb_aprendiz")
# MAGIC
# MAGIC DROP DATABASE mapa_da_saude
# MAGIC
# MAGIC SQL_CBO = spark.sql('select * from oni_homolog.saude_catconsolidada')

# COMMAND ----------

df.write.format("csv").mode("overwrite").saveAsTable("mapa_da_saude.dim_geo")

df.write.format("parquet").mode("overwrite").saveAsTable("mapa_da_saude.dim_cbo")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+)
# MAGIC
# MAGIC ### Função para buscar as colunas do De/Para e transformar para pyspark
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+)

# COMMAND ----------

columns = ["Category","ID","Value","string","Truth", 'Ponto_Virgula']
data = [("A", 1, 121.44, "true", True, 'N/A'), ("B", 2, 300.01, "false", False, 'tres_quatro'),
        ("C", 3, 10.99, "none" , None, 'dois,tres'), ("D", 4, 33.87, "true" , True, 'cinco')]

df = spark.createDataFrame(data=data,schema=columns)
df.show()

# COMMAND ----------

df.display()

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

df.select(f.col('Category')).collect()

#.first()[0]

# COMMAND ----------

for column in df.columns:
  print(column)
  if df.select(f.col(column)).collect() == "N/A":
    prin("N/A")
  else:
    print('dasd')

# COMMAND ----------

y_list = df.select("name").rdd.flatMap(lambda x: x).collect()

# COMMAND ----------

  for column, destination, _type in de_para_values[sheet]:
    if column == 'N/A':
        yield f.lit(None).cast(_type).alias(destination)
    else:
      col = f.col(column)
      if _type.lower() in ['decimal', 'double']:
        col = f.regexp_replace(column, ',', '.')
      yield col.cast(_type).alias(destination)

# COMMAND ----------

def select_columns_de_para(dataframe, de_para_adl_path, sheet):
  headers = {'name_header':'Tabela Origem','pos_header':'B','pos_org':'C','pos_dst':'E','pos_type':'F'}
  de_para_values = cf.parse_ba_doc(dbutils, de_para_adl_path, headers)
  
  cf.check_ba_doc(dataframe, de_para_values, sheet)
  
  for column, destination, _type in de_para_values[sheet]:
    if column == 'N/A':
        yield f.lit(None).cast(_type).alias(destination)
    else:
      col = f.col(column)
      if _type.lower() in ['decimal', 'double']:
        col = f.regexp_replace(column, ',', '.')
      yield col.cast(_type).alias(destination)

# COMMAND ----------



# COMMAND ----------

import crawler.functions as cf
import pyspark.sql.functions as f

# COMMAND ----------

df = df.select(*select_columns_de_para(df, de_para_path, sheet='2019'))