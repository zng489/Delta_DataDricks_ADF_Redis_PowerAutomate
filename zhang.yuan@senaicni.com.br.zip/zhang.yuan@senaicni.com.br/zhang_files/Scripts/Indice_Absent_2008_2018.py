# Databricks notebook source
#from IPython.display import Image
#from IPython.core.display import HTML 
#Image(url= "https://files.sunoresearch.com.br/n/uploads/2021/02/3b198fa1-databricks_logo-800x450.png")


# COMMAND ----------


                                                                      
                                                                       ANO, CNAE top 5, Agrupa_industria das top 5 CNAE (Maiores indice de absent), CBO4, Custo (industria )
                                                      sem 2010 e 2011/                                                                                                      \
                                          Estudo dos anos 2008 2018 /                                                                                                        \
                                        /                                                                                                                                     \
                            2008-2018 -                                                                                                                                        \ 
                          /                                                                                                                                                     \  Dado final
DADOS DA RAIS 2008 2018 -                                                                                                                                                        / 
                          \                                                                                                                                                     /
                            2010-2011 -                                                                                                                                        /
                                        \                                                                                                                                     /
                                          Estudo dos anos 2010 2011 \                                                                                                        /
                                                                     \                                                                                                      /
                                                                     ANO, CNAE top 5, Agrupa_industria das top 5 CNAE (Maiores indice de absent), CBO4, Custo (industria ) /
          

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC %md
# MAGIC
# MAGIC # Descrição Absenteismo por setor e estudo de porporção (CNAE, CBO, com CD_AFASTAMENTO 10,20,30,40 - por Indice)
# MAGIC - Número médio de absent por setores por ano;
# MAGIC - Por perfil;
# MAGIC - Setor com os maiores afastamento e menores afastamentos relacionado com os que pagam maiores salários ou menores salários;
# MAGIC - Dizer por que caiu ou porque subiu, tentar dizer o 'por que' dos acontecimentos;
# MAGIC - Pessoas afastados por anos;
# MAGIC - 'Calcular' o valor em porcentagem os motivos de afastamentos;
# MAGIC - Proporção de pessoas que estão afastando-se;
# MAGIC - Mulher ou Homem afastados, por exemplo licença de afastamento;
# MAGIC - 'Explorar' os dados!;
# MAGIC - Insights perdas e lucros!;
# MAGIC
# MAGIC # Problemas em RAIS(Trusted) e modificações feitos para o estudo:
# MAGIC
# MAGIC - 'DT_DIA_MES_ANO_DATA_ADMISSAO' contendo caracteres '*' e '/';
# MAGIC #
# MAGIC - 'ID_CPF' duplicados;
# MAGIC #
# MAGIC - 'ID_CPF','ID_CNPJ_CEI' em formato 'integer', em vez de estarem no formato 'string', devido ao valor 0 a esquerda;
# MAGIC #
# MAGIC - Acrescentados as tabelas 'cbo_classificacoes' e 'raw_cnae_industrial';
# MAGIC #
# MAGIC - Criação da coluna 'DATA_INICIO_AFAST_1' (1,2,3) através das colunas 'NR_DIA_INI_AF1', 'NR_MES_INI_AF1', 'ANO';
# MAGIC #
# MAGIC - Criação da coluna 'DATA_FIM_AFAST_1' (1,2,3) através das colunas 'NR_DIA_FIM_AF1', 'NR_MES_FIM_AF1', 'ANO';
# MAGIC #
# MAGIC - No caso do estudo do Absenteismo foram selecionados 'DATA_INICIO_AFAST_1' (1,2,3) 'DATA_FIM_AFAST_1' (1,2,3) com 'CD_DIAS_AFASTAMENTOS'['10','20','30','40','99'])
# MAGIC #
# MAGIC - Criação da coluna 'VL_DIAS_AFASTAMENTO1' (1,2,3) através da diferença das colunas 'DATA_INICIO_AFAST_1' (1,2,3), 'DATA_FIM_AFAST_1' (1,2,3);
# MAGIC #
# MAGIC - Criação da coluna 'VL_DIAS_AFASTAMENTO_TOT_CALC' por meio da somatória das colunas 'VL_DIAS_AFASTAMENTO1', 'VL_DIAS_AFASTAMENTO2', 'VL_DIAS_AFASTAMENTO3'
# MAGIC #
# MAGIC - Basicamente 'datafinal' = ANO,mes,dias de desligamento
# MAGIC - 'datafinal' criado por meio das colunas 'ANO', 'CD_MES_DESLIGAMENTO', 'DT_DIA_MES_ANO_DIA_DESLIGAMENTO'
# MAGIC - 'datafinal' com problemas de caracteres tais como: '{ñ'
# MAGIC #
# MAGIC - 'data_inicio' criado por meio das colunas 'ANO', mes: 01, dia:01
# MAGIC - 'data_fim' criado por meio das colunas 'ANO', mes: 12, dia:31
# MAGIC #
# MAGIC - 'dt_adm_corrigido' criado por meio da coluna 'DT_DIA_MES_ANO_DATA_ADMISSAO'
# MAGIC - 'dt_adm_corrigido' nos anos: 2009, 2012 contém carateres: '*', '/' 
# MAGIC  - VInculo 1
# MAGIC
# MAGIC
# MAGIC  .withColumn('dt_adm_corrigido', f.when(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('/') | f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('*'),
# MAGIC                                          f.expr("add_months(data_fim,-NR_MES_TEMPO_EMPREGO)")).otherwise(f.concat_ws('-', f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),5,4),
# MAGIC                                                                                                                       f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),3,2), 
# MAGIC                                                                                                                       f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),1,2))))\
# MAGIC
# MAGIC df_2008_2018_SEM_DUP_CPF_VL_AFAST = (
# MAGIC   df_2008_2018_SEM_DUP_CPF_VL_AFAST\
# MAGIC   .withColumn('DT_DIA_MES_ANO_DATA_ADMISSAO',f.lpad(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),8,'0'))\
# MAGIC   .withColumn('datafinal',f.concat_ws('-',f.col('ANO'),f.col('CD_MES_DESLIGAMENTO'),f.col('DT_DIA_MES_ANO_DIA_DESLIGAMENTO')))\
# MAGIC   .withColumn('datafinal', regexp_replace(col('datafinal'), '\\{ñ','0'))\
# MAGIC   
# MAGIC   .withColumn('data_inicio',f.concat_ws('-', f.col('ANO'), f.lit('01'), f.lit('01')))\
# MAGIC   .withColumn('data_fim',f.concat_ws('-', f.col('ANO'), f.lit('12'), f.lit('31')))\
# MAGIC   .withColumn('dt_adm_corrigido', f.when(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('/') | f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('*'),
# MAGIC                                          f.expr("add_months(data_fim,-NR_MES_TEMPO_EMPREGO)")).otherwise(f.concat_ws('-', f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),5,4),
# MAGIC                                                                                                                       f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),3,2), 
# MAGIC                                                                                                                       f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),1,2))))\
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/f03c15/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/1589F0/000000?text=+) ` 

# COMMAND ----------

![ChessUrl](https://upload.wikimedia.org/wikipedia/commons/7/71/ChessPawnSpecialMoves.gif "chess")

# COMMAND ----------

#from IPython.display import HTML
#HTML('<img src="https://veja.abril.com.br/wp-content/uploads/2021/02/Bolsonaro-sorrindo.jpg">')

# COMMAND ----------

#from IPython.display import HTML
#HTML('<img src="https://c.tenor.com/yhn_wHD5FPEAAAAd/great-job-clapping.gif">')

# COMMAND ----------

(df_2
.coalesce(1)
.write
.format('csv')
.save(var_adls_uri + '/uds/uniepro/ExportacoesCSV/nomedoarquivo.csv', sep=";", header = True, mode='overwrite', encoding='ISO-8859-1'))


from pyspark.sql.functions import *
df_teste = df.withColumn('FORMACAO_INICIAL_BASE', round(col('FORMACAO_INICIAL_BASE'),2))
df_teste = df.withColumn('FORMACAO_INICIAL_BASE', regexp_replace(col('FORMACAO_INICIAL_BASE'), '\\.',','))

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # DADOS DA RAIS 2008 2018
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/f03c15/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/1589F0/000000?text=+) `  `

# COMMAND ----------

from pyspark.sql.window import Window
import pyspark.sql.functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import datediff,col,when,greatest


#---------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------
###
# ABRINDO DADOS cbo_classificacoes
###

var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
cbo_classificacoes_path = '{uri}/uds/uniepro/cbo_classificacoes/'.format(uri=var_adls_uri)
cbo_classificacoes = spark.read.format("csv").option("header","true").option('sep',';').load(cbo_classificacoes_path)
cbo_classificacoes = cbo_classificacoes.withColumn('COD_CBO4', lpad(col('COD_CBO4'),4,'0'))
cbo_classificacoes = cbo_classificacoes.dropDuplicates(['COD_CBO4'])
cbo_classificacoes = cbo_classificacoes.select(['COD_CBO4','DESC_CBO4'])


###
# ABRINDO DADOS raw_cnae_industrial
###

var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
raw_cnae_industrial_path = '{uri}/raw/usr/uniepro/cnae_industrial/'.format(uri=var_adls_uri)
raw_cnae_industrial = spark.read.format("parquet").option("header","true").load(raw_cnae_industrial_path)
raw_cnae_industrial = raw_cnae_industrial.select('divisao','denominacao','agrupamento') 
raw_cnae_industrial  = raw_cnae_industrial.withColumn('divisao', lpad(col('divisao'),2,'0'))
#---------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------



#---------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------
###
# ABRINDO DADOS /trs/me/rais_vinculo
###

var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
trs_rais_vinculo2008a2018_path = '{uri}/trs/me/rais_vinculo'.format(uri=var_adls_uri)
df_rais_vinculo2008a2018 = spark.read.format("parquet").option("header","true").load(trs_rais_vinculo2008a2018_path)
#display(df_rais_vinculo2008a2018.limit(3))
# df = spark.read.parquet()
# df = spark.read.parquet.option('sep', ';')

# 2008,2009,2010,2011,2012,2013,2014,
ANOS = [2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018] 
 
df_2008_2018 = df_rais_vinculo2008a2018
df_2008_2018 = df_2008_2018.where(col('ANO').isin(ANOS))
 
df_2008_2018 = (
  df_2008_2018\
  .filter(col('FL_VINCULO_ATIVO_3112') == '1')\
  .withColumn('ID_CPF', lpad(col('ID_CPF'),11,'0'))\
  .withColumn('ID_CNPJ_CEI',f.lpad(f.col('ID_CNPJ_CEI'),14,'0'))\
  .withColumn('CD_CNAE20_DIVISAO', f.substring(f.col('CD_CNAE20_SUBCLASSE'),1,2))\
)
 
df_2008_2018_group_by = (
  df_2008_2018\
  .groupBy('ID_CPF')\
  .agg(countDistinct('ID_CNPJ_CEI').alias('CPF_DUPLICADO'))\
  .withColumn('%_DE_CPF_DUPLICADOS', col('CPF_DUPLICADO')/df_2008_2018.select('ID_CPF').count())\
  .orderBy('CPF_DUPLICADO', ascending=False)
)
 
  
# JOIN ENTRE A TABELA 'df_2008_2018' COM 'df_2008_2018_group_by'
# df_2008_2018_SEM_DUP_CPF
df_2008_2018_SEM_DUP_CPF = df_2008_2018.join(df_2008_2018_group_by, 'ID_CPF', how='right')


# JOIN ENTRE A TABELA 'df_2008_2018_SEM_DUP_CPF' COM 'cbo_classificacoes'
# df_2008_2018_SEM_DUP_CPF_cbo_classificacoes
df_2008_2018_SEM_DUP_CPF_cbo_classificacoes = df_2008_2018_SEM_DUP_CPF.join(cbo_classificacoes, df_2008_2018_SEM_DUP_CPF.CD_CBO4 == cbo_classificacoes.COD_CBO4, how='left')


# JOIN ENTRE A TABELA 'df_2008_2018_SEM_DUP_CPF_cbo_classificacoes' COM 'raw_cnae_industrial'
# df_2008_2018_SEM_DUP_CPF_cbo_classificacoes
df_2008_2018_SEM_DUP_CPF_cbo_classificacoes = df_2008_2018_SEM_DUP_CPF_cbo_classificacoes.join(raw_cnae_industrial, df_2008_2018_SEM_DUP_CPF_cbo_classificacoes.CD_CNAE20_DIVISAO == raw_cnae_industrial.divisao, how='left')
#---------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # 2008-2018 , sem 2010 e 2011
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/f03c15/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/1589F0/000000?text=+) ` 

# COMMAND ----------

#---------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------
df_2008_2018 = df_2008_2018_SEM_DUP_CPF_cbo_classificacoes.filter(col('ANO').isin([2008,2009,2012,2013,2014,2015,2016,2017,2018])) # 2008,2009,2012,2013,2014,2015,2016,2017,

df_2008_2018_SEM_DUP_CPF_DATA_INICIO_FIM = (
  df_2008_2018\
  .withColumn('DATA_INICIO_AFAST_1', f.when((f.col('NR_DIA_INI_AF1').isNotNull()) & (f.col('NR_MES_INI_AF1').isNotNull()) & (f.col('ANO').isNotNull()), f.concat_ws('-', "ANO",
                                                                                  f.lpad("NR_MES_INI_AF1", 2, '0'),
                                                                                  f.lpad("NR_DIA_INI_AF1", 2, '0')).cast('Date')))\
  .withColumn('DATA_FIM_AFAST_1', f.when((f.col('NR_DIA_FIM_AF1').isNotNull()) & (f.col('NR_MES_FIM_AF1').isNotNull()) & (f.col('ANO').isNotNull()), f.concat_ws('-', "ANO",
                                                                                  f.lpad("NR_MES_FIM_AF1", 2, '0'),
                                                                                  f.lpad("NR_DIA_FIM_AF1", 2, '0')).cast('Date')))\
  .withColumn('DATA_INICIO_AFAST_2', f.when((f.col('NR_DIA_INI_AF2').isNotNull()) & (f.col('NR_MES_INI_AF2').isNotNull()) & (f.col('ANO').isNotNull()), f.concat_ws('-', "ANO",
                                                                                  f.lpad("NR_MES_INI_AF2", 2, '0'),
                                                                                  f.lpad("NR_DIA_INI_AF2", 2, '0')).cast('Date')))\
  .withColumn('DATA_FIM_AFAST_2', f.when((f.col('NR_DIA_FIM_AF2').isNotNull()) & (f.col('NR_MES_FIM_AF2').isNotNull()) & (f.col('ANO').isNotNull()), f.concat_ws('-', "ANO",
                                                                                  f.lpad("NR_MES_FIM_AF2", 2, '0'),
                                                                                  f.lpad("NR_DIA_FIM_AF2", 2, '0')).cast('Date')))\
  .withColumn('DATA_INICIO_AFAST_3', f.when((f.col('NR_DIA_INI_AF3').isNotNull()) & (f.col('NR_MES_INI_AF3').isNotNull()) & (f.col('ANO').isNotNull()), f.concat_ws('-', "ANO",
                                                                                  f.lpad("NR_MES_INI_AF3", 2, '0'),
                                                                                  f.lpad("NR_DIA_INI_AF3", 2, '0')).cast('Date')))\
  .withColumn('DATA_FIM_AFAST_3', f.when((f.col('NR_DIA_FIM_AF3').isNotNull()) & (f.col('NR_MES_FIM_AF3').isNotNull()) & (f.col('ANO').isNotNull()), f.concat_ws('-', "ANO",
                                                                                  f.lpad("NR_MES_FIM_AF3", 2, '0'),
                                                                                  f.lpad("NR_DIA_FIM_AF3", 2, '0')).cast('Date')))
)
 
'''
df_2008_2018_SEM_DUP_CPF_VL_AFAST = (
  df_2008_2018_SEM_DUP_CPF_DATA_INICIO_FIM\
  .withColumn( 'VL_DIAS_AFASTAMENTO1',
              when(col('CD_CAUSA_AFASTAMENTO1').isin(['10','20','30','40','99']),datediff(col("DATA_FIM_AFAST_1"),col("DATA_INICIO_AFAST_1"))).otherwise(0))\
  .withColumn( 'VL_DIAS_AFASTAMENTO2', 
              when(col('CD_CAUSA_AFASTAMENTO2').isin(['10','20','30','40','99']), datediff(col("DATA_FIM_AFAST_2"),col("DATA_INICIO_AFAST_2"))).otherwise(0))\
  .withColumn( 'VL_DIAS_AFASTAMENTO3', 
              when(col('CD_CAUSA_AFASTAMENTO3').isin(['10','20','30','40','99']), datediff(col("DATA_FIM_AFAST_3"),col("DATA_INICIO_AFAST_3"))).otherwise(0))\
  .withColumn('VL_DIAS_AFASTAMENTO1',f.when(f.col('VL_DIAS_AFASTAMENTO1').isNull(),f.lit(0))
              .otherwise(f.col('VL_DIAS_AFASTAMENTO1')))\
  .withColumn('VL_DIAS_AFASTAMENTO2',f.when(f.col('VL_DIAS_AFASTAMENTO2').isNull(),f.lit(0))
              .otherwise(f.col('VL_DIAS_AFASTAMENTO2')))\
  .withColumn('VL_DIAS_AFASTAMENTO3',f.when(f.col('VL_DIAS_AFASTAMENTO3').isNull(),f.lit(0))
              .otherwise(f.col('VL_DIAS_AFASTAMENTO3')))\
  .withColumn('VL_DIAS_AFASTAMENTO_TOT_CALC', f.col('VL_DIAS_AFASTAMENTO1')+f.col('VL_DIAS_AFASTAMENTO2')+f.col('VL_DIAS_AFASTAMENTO3'))
)
'''

df_2008_2018_SEM_DUP_CPF_VL_AFAST = (
  df_2008_2018_SEM_DUP_CPF_DATA_INICIO_FIM\
                                     .withColumn(
  'VL_DIAS_AFASTAMENTO1', f.when(f.col('DATA_FIM_AFAST_1').isNull() & f.col('DATA_INICIO_AFAST_1').isNull(), 0)\
    .otherwise(
    f.when(f.col('DATA_FIM_AFAST_1') == f.col('DATA_INICIO_AFAST_1'), 1).otherwise(
      f.when(f.col('CD_CAUSA_AFASTAMENTO1').isin(['10','20','30','40','99']), datediff(col("DATA_FIM_AFAST_1"),col("DATA_INICIO_AFAST_1"))).otherwise(0)
        ))   
)
  )


df_2008_2018_SEM_DUP_CPF_VL_AFAST = (
  df_2008_2018_SEM_DUP_CPF_VL_AFAST\
                                     .withColumn(
  'VL_DIAS_AFASTAMENTO2', f.when(f.col('DATA_FIM_AFAST_2').isNull() & f.col('DATA_INICIO_AFAST_2').isNull(), 0)\
    .otherwise(
    f.when(f.col('DATA_FIM_AFAST_2') == f.col('DATA_INICIO_AFAST_2'), 1).otherwise(
      f.when(f.col('CD_CAUSA_AFASTAMENTO2').isin(['10','20','30','40','99']), datediff(col("DATA_FIM_AFAST_2"),col("DATA_INICIO_AFAST_2"))).otherwise(0)
        ))   
)
  )


df_2008_2018_SEM_DUP_CPF_VL_AFAST = (
  df_2008_2018_SEM_DUP_CPF_VL_AFAST\
                                     .withColumn(
  'VL_DIAS_AFASTAMENTO3', f.when(f.col('DATA_FIM_AFAST_3').isNull() & f.col('DATA_INICIO_AFAST_3').isNull(), 0)\
    .otherwise(
    f.when(f.col('DATA_FIM_AFAST_3') == f.col('DATA_INICIO_AFAST_3'), 1).otherwise(
      f.when(f.col('CD_CAUSA_AFASTAMENTO3').isin(['10','20','30','40','99']), datediff(col("DATA_FIM_AFAST_3"),col("DATA_INICIO_AFAST_3"))).otherwise(0)
        ))   
)
  )


df_2008_2018_SEM_DUP_CPF_VL_AFAST = (
  df_2008_2018_SEM_DUP_CPF_VL_AFAST.withColumn('VL_DIAS_AFASTAMENTO_TOT_CALC', f.col('VL_DIAS_AFASTAMENTO1')+f.col('VL_DIAS_AFASTAMENTO2')+f.col('VL_DIAS_AFASTAMENTO3'))
)
#---------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------
  
  
'''python
Considerando as 364
.withColumn('VL_DIAS_AFASTAMENT_TOT_CALC', f.when( f.col('VL_DIAS_AFASTAMENTO1') == f.col('VL_DIAS_AFASTAMENTO2') == f.col('VL_DIAS_AFASTAMENTO3'), f.lit(364)).otherwise('VL_DIAS_AFASTAMENT_TOT_CALC')
)
'''


df_2008_2018_SEM_DUP_CPF_VL_AFAST = (
  df_2008_2018_SEM_DUP_CPF_VL_AFAST\
  .withColumn('DT_DIA_MES_ANO_DATA_ADMISSAO',f.lpad(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),8,'0'))\
  .withColumn('datafinal',f.concat_ws('-',f.col('ANO'),f.col('CD_MES_DESLIGAMENTO'),f.col('DT_DIA_MES_ANO_DIA_DESLIGAMENTO')))\
  .withColumn('datafinal', regexp_replace(col('datafinal'), '\\{ñ','0'))\
  .withColumn('data_inicio',f.concat_ws('-', f.col('ANO'), f.lit('01'), f.lit('01')))\
  .withColumn('data_fim',f.concat_ws('-', f.col('ANO'), f.lit('12'), f.lit('31')))\
  .withColumn('dt_adm_corrigido', f.when(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('/') | f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('*'),
                                         f.expr("add_months(data_fim,-NR_MES_TEMPO_EMPREGO)")).otherwise(f.concat_ws('-', f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),5,4),
                                                                                                                      f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),3,2), 
                                                                                                                      f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),1,2))))\
.withColumn('dt_adm_corrigido', f.to_date(f.col('dt_adm_corrigido'),"yyyy-MM-dd"))\
.withColumn('ANO_ADMISSAO',f.substring(f.col('dt_adm_corrigido'),1,4).cast('int'))\
.withColumn('MES_ADMISSAO',f.substring(f.col('dt_adm_corrigido'),6,2).cast('int'))\
.withColumn('DIAS_TRABALHADOS', datediff(col('data_fim'),col('dt_adm_corrigido')))\
.withColumn('DIAS_TRABALHADOS', f.when( col('DIAS_TRABALHADOS') > 365, f.lit(365)).otherwise(col('DIAS_TRABALHADOS')))\
.withColumn('FERIAS_PROPORCIONAIS', f.round((f.col('DIAS_TRABALHADOS')/365)*30, 0))\
.withColumn('DIAS_ESPERADOS_TRABALHADOS', f.round(f.col('DIAS_TRABALHADOS')-f.col('FERIAS_PROPORCIONAIS'),0)))
#  \
#  .withColumn(
#    'VL_DIAS_AFASTAMENTO_TOT_CALC', f.when( f.col('VL_DIAS_AFASTAMENTO_TOT_CALC') > 335, f.lit(335)).otherwise(col('VL_DIAS_AFASTAMENTO_TOT_CALC')))
#)


# Criando tabela uma tabela unica com os maiores valores
df_2008_2018_SEM_DUP_CPF_VL_AFAST = df_2008_2018_SEM_DUP_CPF_VL_AFAST.withColumn('VL_MEDIA_NOM_DEZEMBRO_NOM', greatest('VL_REMUN_MEDIA_NOM', 'VL_REMUN_DEZEMBRO_NOM'))


# VL_DIAS_AFASTAMENTO_TOTC_CALC MENORES DO QUE 15 DIAS
df_2008_2018_SEM_DUP_CPF_VL_AFAST = df_2008_2018_SEM_DUP_CPF_VL_AFAST.withColumn('VL_DIAS_MENORES_15_CALC', f.when( 
  col('VL_DIAS_AFASTAMENTO_TOT_CALC') < 16, f.lit(col('VL_DIAS_AFASTAMENTO_TOT_CALC'))).otherwise('N_SELECT') )


#.withColumn('DIAS_TRABALHADOS', f.when( col('DIAS_TRABALHADOS') > 365, f.lit(365)).otherwise(col('DIAS_TRABALHADOS')))\

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # 2010-2011
# MAGIC
# MAGIC - Filter 2010
# MAGIC - mês de afastamento está como 'null'
# MAGIC
# MAGIC - Filter 2011
# MAGIC - Variáveis de datas de afastamento estão como '99' e de motivos de afastamento
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/f03c15/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/ffffff/000000?text=+) ` `
# MAGIC
# MAGIC ![#c5f015](https://via.placeholder.com/1500x20/1589F0/000000?text=+) ` 

# COMMAND ----------

#df_2010_2011 = df_2008_2018_SEM_DUP_CPF_cbo_classificacoes.filter(col('ANO').isin([2010,2011]))
# == f.lit(2010)

df_2010_2011_SEM_DUP_CPF_DATA_INICIO_FIM = (df_2008_2018_SEM_DUP_CPF_cbo_classificacoes.where(f.col('ANO').isin([2010,2011]))\
                                            .withColumn('CD_CNAE20_DIVISAO',f.substring(f.col('CD_CNAE20_SUBCLASSE'),1,2))\
                                            .filter(col('FL_VINCULO_ATIVO_3112') == '1')\
                                            .filter( (col('CD_CAUSA_AFASTAMENTO1').isin(['10','20','30','40','99']) & (col('CD_CAUSA_AFASTAMENTO2').isin(['10','20','30','40','99']) & (col('CD_CAUSA_AFASTAMENTO3').isin(['10','20','30','40','99']) )))))


#Filter 2010
#mês de afastamento está como 'null'

#Filter 2011
#Variáveis de datas de afastamento estão como '99' e de motivos de afastamento


ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST = (
  df_2010_2011_SEM_DUP_CPF_DATA_INICIO_FIM\
  .withColumn('DT_DIA_MES_ANO_DATA_ADMISSAO',f.lpad(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),8,'0'))\
  .withColumn('datafinal',f.concat_ws('-',f.col('ANO'),f.col('CD_MES_DESLIGAMENTO'),f.col('DT_DIA_MES_ANO_DIA_DESLIGAMENTO')))\
  .withColumn('datafinal', regexp_replace(col('datafinal'), '\\{ñ','0'))\
  .withColumn('data_inicio',f.concat_ws('-', f.col('ANO'), f.lit('01'), f.lit('01')))\
  .withColumn('data_fim',f.concat_ws('-', f.col('ANO'), f.lit('12'), f.lit('31')))\
  .withColumn('dt_adm_corrigido', f.when(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('/') | f.col('DT_DIA_MES_ANO_DATA_ADMISSAO').contains('*'),
                                         f.expr("add_months(data_fim,-NR_MES_TEMPO_EMPREGO)")).otherwise(f.concat_ws('-', f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),5,4),
                                                                                                                      f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),3,2), 
                                                                                                                      f.substring(f.col('DT_DIA_MES_ANO_DATA_ADMISSAO'),1,2))))\
.withColumn('dt_adm_corrigido', f.to_date(f.col('dt_adm_corrigido'),"yyyy-MM-dd"))\
.withColumn('ANO_ADMISSAO',f.substring(f.col('dt_adm_corrigido'),1,4).cast('int'))\
.withColumn('MES_ADMISSAO',f.substring(f.col('dt_adm_corrigido'),6,2).cast('int'))\
.withColumn('DIAS_TRABALHADOS', datediff(col('data_fim'),col('dt_adm_corrigido')))\
.withColumn('DIAS_TRABALHADOS', f.when( col('DIAS_TRABALHADOS') > 365, f.lit(365)).otherwise(col('DIAS_TRABALHADOS')))\
.withColumn('FERIAS_PROPORCIONAIS', f.round((f.col('DIAS_TRABALHADOS')/365)*30, 0))\
.withColumn('DIAS_ESPERADOS_TRABALHADOS', f.round(f.col('DIAS_TRABALHADOS')-f.col('FERIAS_PROPORCIONAIS'),0)))
#  \
#  .withColumn(
#    'VL_DIAS_AFASTAMENTO_TOT_CALC', f.when( f.col('VL_DIAS_AFASTAMENTO_TOT_CALC') > 335, f.lit(335)).otherwise(col('VL_DIAS_AFASTAMENTO_TOT_CALC')))
#)


# Criando tabela uma tabela unica com os maiores valores
ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST = ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST.withColumn('VL_MEDIA_NOM_DEZEMBRO_NOM', greatest('VL_REMUN_MEDIA_NOM', 'VL_REMUN_DEZEMBRO_NOM'))


# VL_DIAS_AFASTAMENTO_TOTC_CALC MENORES DO QUE 15 DIAS
ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST = ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST.withColumn('VL_DIAS_MENORES_15_CALC', f.when( 
  col('VL_DIAS_AFASTAMENTO') < 16, f.lit(col('VL_DIAS_AFASTAMENTO'))).otherwise('N_SELECT') )

#.withColumn('DIAS_TRABALHADOS', f.when( col('DIAS_TRABALHADOS') > 365, f.lit(365)).otherwise(col('DIAS_TRABALHADOS')))\

# COMMAND ----------

df_2008_2018_SEM_DUP_CPF_VL_AFAST.display()

# COMMAND ----------

ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST.display()

# COMMAND ----------

#

ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST.filter(col('ANO')== 2011).display()

# COMMAND ----------

df = df_2008_2018_SEM_DUP_CPF_VL_AFAST

# COMMAND ----------

#df_2008_2018_SEM_DUP_CPF_VL_AFAST.count()

# COMMAND ----------

df_2008_2018_SEM_DUP_CPF_VL_AFAST.display()

# COMMAND ----------

# MAGIC %md 
# MAGIC # Estudo dos anos 2008 2018 (nao incluindo 2010, 2011)
# MAGIC
# MAGIC ## - CNAE
# MAGIC ## - CBO4
# MAGIC ## - RANK CNAE
# MAGIC ## - ABSENT
# MAGIC ## - Custo
# MAGIC  ![#c5f015](https://via.placeholder.com/1500x20/c5f015/000000?text=+) ` `

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### ANO Absent

# COMMAND ----------

ANO_2008_2018 = (df_2008_2018_SEM_DUP_CPF_VL_AFAST
       .groupby('ANO')
       .agg(f.sum(f.col('VL_DIAS_AFASTAMENTO_TOT_CALC')).alias('Total_dias_afastamento'),
            f.round(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')),2).alias('Total_dias_trabalhados_esp'),
            f.count('ID_CPF'))
       .withColumn('INDICE_ABSENTEÍSMO', f.round(f.col('Total_dias_afastamento')/f.col('Total_dias_trabalhados_esp')*100,2))
       .orderBy('ANO'))

ANO_2008_2018.display()

# COMMAND ----------

#window = Window.partitionBy('ANO','CD_CNAE20_DIVISAO').orderBy(df1['Revenue'].desc())
# windowPartition = Window.partitionBy("DATA").orderBy(desc("ABS"))
# show df
# df.select('*', rank().over(windowPartition).alias('rank')).filter(col('rank') <= 5).show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## CNAE top 5 de cada(CNAE por meio do indice de absenteismo)

# COMMAND ----------

CD_CNAE20_DIVISAO_2008_2018 = (df_2008_2018_SEM_DUP_CPF_VL_AFAST
       .groupby('ANO','CD_CNAE20_DIVISAO')
       .agg(f.sum(f.col('VL_DIAS_AFASTAMENTO_TOT_CALC')).alias('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC'),
            f.round(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')),2).alias('TOTAL_DIAS_ESPERADOS_TRABALHADOS'))
       .withColumn('INDICE_ABSENTEÍSMO', f.round(f.col('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC')/f.col('TOTAL_DIAS_ESPERADOS_TRABALHADOS')*100,2))
       )
#CD_CNAE20_DIVISAO_2008_2018.display()

window = Window.partitionBy('ANO').orderBy(desc("INDICE_ABSENTEÍSMO"))
# CD_CNAE20_DIVISAO_2008_2018.select('*', rank().over(window).alias('rank')).filter(col('rank') <= 5).show() 
CD_CNAE20_DIVISAO_2008_2018.select('*', rank().over(window).alias('rank')).filter(col('rank') <= 5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## CBO4

# COMMAND ----------

CD_CBO4_2008_2018 = (df_2008_2018_SEM_DUP_CPF_VL_AFAST
       .groupby('ANO','CD_CBO4')
       .agg(f.sum(f.col('VL_DIAS_AFASTAMENTO_TOT_CALC')).alias('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC'),
            f.round(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')),2).alias('TOTAL_DIAS_ESPERADOS_TRABALHADOS'))
       .withColumn('INDICE_ABSENTEÍSMO', f.round(f.col('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC')/f.col('TOTAL_DIAS_ESPERADOS_TRABALHADOS')*100,2))
       )

CD_CBO4_2008_2018.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Agrupamento industria das top 5 CNAE (Maiores indice de absent) WINDOW()

# COMMAND ----------

# Proporcao
# Condicoes determinados col('agrupamento') == 'Indústria') & (col('CD_CNAE20_DIVISAO') == 30
# Numero_de_CPFs_total condicoes bruto, normais
# Numero_de_CPFs_10_20_30_40 condicoes 10,20,30,40

# APENAS PARA 2018

df_08_18 = df_2008_2018_SEM_DUP_CPF_VL_AFAST
df_propor_absent = df_08_18.filter(
  (col('agrupamento') == 'Indústria') & (col('CD_CNAE20_DIVISAO').isin(30,42,41,38,50)) & (col('ANO') == 2018)
)

CODIGOS = [10,20,30,40]

df_propor_absent = df_propor_absent.groupBy('ANO','CD_SEXO','CD_CNAE20_DIVISAO','CD_CBO4','DESC_CBO4','agrupamento','denominacao')\
        .agg(count(col('ID_CPF')).alias('N_CPF_totais'), 
             f.count((f.when(f.col('CD_CAUSA_AFASTAMENTO1').isin(CODIGOS) & f.col('CD_CAUSA_AFASTAMENTO2').isin(CODIGOS
  ) & f.col('CD_CAUSA_AFASTAMENTO3').isin(CODIGOS), f.col('ID_CPF')))).alias('N_CPF_10_20_30_40'),
             f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')).alias('Total_Dias_Esperados'),
             f.sum(f.when(
         f.col('CD_CAUSA_AFASTAMENTO1').isin(CODIGOS) &   # CODIGOS = [10,20,30,40]
         f.col('CD_CAUSA_AFASTAMENTO2').isin(CODIGOS) & 
         f.col('CD_CAUSA_AFASTAMENTO3').isin(CODIGOS), 
         f.col('VL_DIAS_AFASTAMENTO_TOT_CALC'))).alias('Total_Dias_Afast'))\
.withColumn('Ind_Absent_Setor',f.round(f.col('Total_Dias_Afast')/f.col('Total_Dias_Esperados')*100,2)).na.fill(0).withColumn('Prop_CPF', (f.col('N_CPF_10_20_30_40')/f.col('N_CPF_totais')))


df_propor_absent = df_propor_absent.select(
  'ANO',
  'CD_SEXO',
  'CD_CNAE20_DIVISAO',
  'CD_CBO4',
  'DESC_CBO4',
  'agrupamento',
  'denominacao',
  'N_CPF_totais',
  'N_CPF_10_20_30_40',
  'Prop_CPF',
  'Total_Dias_Esperados',
  'Total_Dias_Afast',
  'Ind_Absent_Setor')

df_propor_absent.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Custo_Afast - Agrupamento industria

# COMMAND ----------

df_custo_08_18 = df_2008_2018_SEM_DUP_CPF_VL_AFAST
df_custo_08_18 = df_custo_08_18.filter(col('VL_DIAS_MENORES_15_CALC') != 'N_SELECT')\
.withColumn('Valor_Dia_Trab', f.round(f.col('VL_MEDIA_NOM_DEZEMBRO_NOM')/22, 3))\
.withColumn('Custo_Afast_Dia_Trab', f.round( f.col('Valor_Dia_Trab') * f.col('VL_DIAS_MENORES_15_CALC')))\
.withColumn('Custo_Assist_Saude', f.round(f.col('VL_MEDIA_NOM_DEZEMBRO_NOM') * 0.2))\
.withColumn('Custo_Direto_Absent', 
            f.when (
              f.col('VL_DIAS_MENORES_15_CALC') == 0,0
            )\
.otherwise(
              f.round( f.col('Custo_Assist_Saude') + f.col('Custo_Afast_Dia_Trab'))
            )
           )

df_custo_08_18.display()

# COMMAND ----------

# MAGIC %md 
# MAGIC # Estudo dos anos 2010 2011
# MAGIC
# MAGIC ## - CNAE
# MAGIC ## - CBO4
# MAGIC ## - RANK CNAE
# MAGIC ## - ABSENT
# MAGIC ## - Custo
# MAGIC  ![#c5f015](https://via.placeholder.com/1500x20/c5f015/000000?text=+) `  `

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC ## ANO Absent

# COMMAND ----------

ANO_2010_2011 = (ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST
       .groupby('ANO')
       .agg(f.sum(f.col('VL_DIAS_AFASTAMENTO')).alias('Total_dias_afastamento'),
            f.round(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')),2).alias('Total_dias_trabalhados_esp'),
            f.count('ID_CPF'))
       .withColumn('INDICE_ABSENTEÍSMO', f.round(f.col('Total_dias_afastamento')/f.col('Total_dias_trabalhados_esp')*100,2))
       .orderBy('ANO'))

ANO_2010_2011.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## CNAE top 5 de cada (CNAE por meio do indice de absenteismo)

# COMMAND ----------

CD_CNAE20_DIVISAO_2010_2011 = (ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST
       .groupby('ANO','CD_CNAE20_DIVISAO')
       .agg(f.sum(f.col('VL_DIAS_AFASTAMENTO')).alias('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC'),
            f.round(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')),2).alias('TOTAL_DIAS_ESPERADOS_TRABALHADOS'))
       .withColumn('INDICE_ABSENTEÍSMO', f.round(f.col('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC')/f.col('TOTAL_DIAS_ESPERADOS_TRABALHADOS')*100,2))
       )
#CD_CNAE20_DIVISAO_2008_2018.display()

window = Window.partitionBy('ANO').orderBy(desc("INDICE_ABSENTEÍSMO"))
# CD_CNAE20_DIVISAO_2008_2018.select('*', rank().over(window).alias('rank')).filter(col('rank') <= 5).show() 
CD_CNAE20_DIVISAO_2008_2018.select('*', rank().over(window).alias('rank')).filter(col('rank') <= 5).display()


# COMMAND ----------

#CD_CNAE20_DIVISAO_2010_2011 = (ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST
#       .groupby('ANO','CD_CNAE20_DIVISAO')
#       .agg(f.sum(f.col('VL_DIAS_AFASTAMENTO')).alias('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC'),
#            f.round(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')),2).alias('TOTAL_DIAS_ESPERADOS_TRABALHADOS'))
#       .withColumn('INDICE_ABSENTEÍSMO', f.round(f.col('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC')/f.col('TOTAL_DIAS_ESPERADOS_TRABALHADOS')*100,2))
#       )
#
#CD_CNAE20_DIVISAO_2010_2011.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## CBO4

# COMMAND ----------

CD_CBO4_2010_2011 = (ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST
       .groupby('ANO','CD_CBO4')
       .agg(f.sum(f.col('VL_DIAS_AFASTAMENTO')).alias('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC'),
            f.round(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')),2).alias('TOTAL_DIAS_ESPERADOS_TRABALHADOS'))
       .withColumn('INDICE_ABSENTEÍSMO', f.round(f.col('TOTAL_VL_DIAS_AFASTAMENTO_TOT_CALC')/f.col('TOTAL_DIAS_ESPERADOS_TRABALHADOS')*100,2))
       )

CD_CBO4_2010_2011.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Agrupamento industria das top 5 CNAE (Maiores indice de absent)

# COMMAND ----------

# Proporcao
# Condicoes determinados col('agrupamento') == 'Indústria') & (col('CD_CNAE20_DIVISAO') == 30
# Numero_de_CPFs_total condicoes bruto, normais
# Numero_de_CPFs_10_20_30_40 condicoes 10,20,30,40

df_10_11 = ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST
df_prop_absent_10_11 = df_10_11.filter(
  (col('agrupamento') == 'Indústria') & (col('CD_CNAE20_DIVISAO').isin(11,41,36,21,16))
)

CODIGOS = [10,20,30,40]

df_prop_absent_10_11 = df_prop_absent_10_11.groupBy('ANO','CD_SEXO','CD_CNAE20_DIVISAO','CD_CBO4','DESC_CBO4','agrupamento','denominacao')\
        .agg(count(col('ID_CPF')).alias('N_CPF_totais'), 
             f.count((f.when(f.col('CD_CAUSA_AFASTAMENTO1').isin(CODIGOS) & f.col('CD_CAUSA_AFASTAMENTO2').isin(CODIGOS
  ) & f.col('CD_CAUSA_AFASTAMENTO3').isin(CODIGOS), f.col('ID_CPF')))).alias('N_CPF_10_20_30_40'),
             f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')).alias('Total_Dias_Esperados'),
             f.sum(f.when(
         f.col('CD_CAUSA_AFASTAMENTO1').isin(CODIGOS) &   # CODIGOS = [10,20,30,40]
         f.col('CD_CAUSA_AFASTAMENTO2').isin(CODIGOS) & 
         f.col('CD_CAUSA_AFASTAMENTO3').isin(CODIGOS), 
         f.col('VL_DIAS_AFASTAMENTO'))).alias('Total_Dias_Afast'))\
.withColumn('Ind_Absent_Setor',f.round(f.col('Total_Dias_Afast')/f.col('Total_Dias_Esperados')*100,2)).na.fill(0).withColumn('Prop_CPF', (f.col('N_CPF_10_20_30_40')/f.col('N_CPF_totais')))


df_prop_absent_10_11 = df_prop_absent_10_11.select(
  'ANO',
  'CD_SEXO',
  'CD_CNAE20_DIVISAO',
  'CD_CBO4',
  'DESC_CBO4',
  'agrupamento',
  'denominacao',
  'N_CPF_totais',
  'N_CPF_10_20_30_40',
  'Prop_CPF',
  'Total_Dias_Esperados',
  'Total_Dias_Afast',
  'Ind_Absent_Setor')

df_prop_absent_10_11.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Custo_Afast - Agrupamento industria

# COMMAND ----------

df_custo_10_11 = ANOS_2010_2011_SEM_DUP_CPF_VL_AFAST
df_custo_10_11 = df_custo_10_11.filter(col('VL_DIAS_MENORES_15_CALC') != 'N_SELECT')\
.withColumn('Valor_Dia_Trab', f.round(f.col('VL_MEDIA_NOM_DEZEMBRO_NOM')/22, 3))\
.withColumn('Custo_Afast_Dia_Trab', f.round( f.col('Valor_Dia_Trab') * f.col('VL_DIAS_MENORES_15_CALC')))\
.withColumn('Custo_Assist_Saude', f.round(f.col('VL_MEDIA_NOM_DEZEMBRO_NOM') * 0.2))\
.withColumn('Custo_Direto_Absent', 
            f.when (
              f.col('VL_DIAS_MENORES_15_CALC') == 0,0
            )\
.otherwise(
              f.round( f.col('Custo_Assist_Saude') + f.col('Custo_Afast_Dia_Trab'))
            )
           )

df_custo_10_11.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC  ![#c5f015](https://via.placeholder.com/1500x20/c5f015/000000?text=+) ` `

# COMMAND ----------

'''
# Obtendo dos 10 primeiros da CNAE, com 'agrupamento') == 'Indústria', e CODIGOS = [10,20,30,40]
'''

df = df_2008_2018_SEM_DUP_CPF_VL_AFAST
df_1_primeiros = df.filter(
  (col('agrupamento') == 'Indústria')
)

CODIGOS = [10,20,30,40]
DF_CNAE_OS_10_PRIMEIROS = df_1_primeiros.groupBy('CD_CNAE20_DIVISAO','DESC_CBO4','agrupamento','denominacao')\
  .agg(f.sum(f.col('DIAS_ESPERADOS_TRABALHADOS')).alias('Total_Dias_Esperados'),
       f.sum(f.when(
         f.col('CD_CAUSA_AFASTAMENTO1').isin(CODIGOS) &   # CODIGOS = [10,20,30,40]
         f.col('CD_CAUSA_AFASTAMENTO2').isin(CODIGOS) & 
         f.col('CD_CAUSA_AFASTAMENTO3').isin(CODIGOS), 
         f.col('VL_DIAS_AFASTAMENTO_TOT_CALC'))).alias('Total_Dias_Afast')).withColumn('Ind_Absent_Setor', f.round(f.col('Total_Dias_Afast')/f.col('Total_Dias_Esperados')*100,2)).na.fill(0)
# na.fil(0) por causa das condições [10, 20, 30, 40]

DF_CNAE_OS_10_PRIMEIROS.display()

'''
11,41,36,21,16
'''

# COMMAND ----------

df_teste = df_Proporcao.withColumn('N_CPF_totais', regexp_replace(col('N_CPF_totais'), '\\.',','))\
.withColumn('N_CPF_10_20_30_40', regexp_replace(col('N_CPF_10_20_30_40'), '\\.',','))\
.withColumn('Prop_CPF', regexp_replace(col('Prop_CPF'), '\\.',','))\
.withColumn('Total_Dias_Esperados', regexp_replace(col('Total_Dias_Esperados'), '\\.',','))\
.withColumn('Total_Dias_Afast', regexp_replace(col('Total_Dias_Afast'), '\\.',','))\
.withColumn('Ind_Absent_Setor', regexp_replace(col('Ind_Absent_Setor'), '\\.',','))

# COMMAND ----------

(df_teste.coalesce(1).write.format('csv').save(var_adls_uri + '/uds/uniepro/data/Vitor/2008_2018/', header = True, mode='overwrite', encoding='ISO-8859-1'))
#  ,sep=";"

##df_teste = df.withColumn('FORMACAO_INICIAL_BASE', round(col('FORMACAO_INICIAL_BASE'),2))
#df_teste = df.withColumn('FORMACAO_INICIAL_BASE', regexp_replace(col('FORMACAO_INICIAL_BASE'), '\\.',','))

# COMMAND ----------

# MAGIC %md
# MAGIC  ![#c5f015](https://via.placeholder.com/1500x20/c5f015/000000?text=+) ` `
# MAGIC
# MAGIC # FIM

# COMMAND ----------

var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net' #, sep=";"
(df_student_detail1.coalesce(1).write.format('csv').save(var_adls_uri + '/uds/uniepro/data/Edgar/Files_Edgar', header = True, mode='overwrite', encoding='UTF-8'))

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Regressão Polinomial
# MAGIC
# MAGIC  ![#c5f015](https://via.placeholder.com/1500x20/f03c15/000000?text=+) ` `
# MAGIC  
# MAGIC  ![#c5f015](https://via.placeholder.com/1500x20/1589F0/000000?text=+) ` `

# COMMAND ----------

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# assign data of lists.
data = {'Indice_Absent': [2.63, 2.64, 2.75, 3.82, 4.41, 2.84, 2.87, 2.92, 3.05, 2.83, 2.68],
'Ano': [2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018]}

# Create DataFrame
dataset = pd.DataFrame(data)

# Print the output.
print(dataset)

# COMMAND ----------

# Importing the dataset
# dataset = pd.read_csv('https://s3.us-west-2.amazonaws.com/public.gamelab.fun/dataset/position_salaries.csv')
y = dataset.iloc[:, 1:2].values
print(y)

# COMMAND ----------

y.shape

# COMMAND ----------

X = dataset.iloc[:, 0].values
print(X)

# COMMAND ----------

X.shape

# COMMAND ----------

X_1 = X.reshape(-1, 1)

# COMMAND ----------

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_1, y, test_size=0.3, random_state=42)



# Fitting Linear Regression to the dataset
from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(X_1, y)



# Visualizing the Linear Regression results
#def viz_linear():
plt.scatter(X_1, y, color='red')
plt.plot(X_1, lin_reg.predict(X_1), color='blue')
plt.title('(Linear Regression)')
plt.xlabel('Ano')
plt.ylabel('Indice')
plt.show()
#return

# COMMAND ----------

# Fitting Polynomial Regression to the dataset
from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree=1)
X_poly = poly_reg.fit_transform(X_1)
pol_reg = LinearRegression()
pol_reg.fit(X_poly, y)


# Visualizing the Polymonial Regression results
def viz_polymonial():
  plt.scatter(X_1, y, color='red')
  plt.plot(X_1, pol_reg.predict(poly_reg.fit_transform(X_1)), color='blue')
  plt.title('(Polynomial Regression)')
  plt.xlabel('Ano')
  plt.ylabel('Indice')
  plt.show()
  return
viz_polymonial()

# COMMAND ----------

# Predicting a new result with Linear Regression
lin_reg.predict([[2010]])
#output should be 249500

# COMMAND ----------

# Predicting a new result with Polymonial Regression
pol_reg.predict(poly_reg.fit_transform([[2019]]))
#output should be 132148.43750003

# COMMAND ----------

from pyspark.sql.functions import greatest
df2 = df.withColumn('max_by_rows', greatest('col_1', 'col_2', 'col_3'))

#Only if you need col
#from pyspark.sql.functions import col
#df2 = df.withColumn('max', greatest(col('col_1'), col('col_2'), col('col_3')))
df2.show()

+-----+-----+-----+-----------+
|col_1|col_2|col_3|max_by_rows|
+-----+-----+-----+-----------+
|    1|    2|    3|          3|
|    2|    1|    2|          2|
|    3|    4|    5|          5|
+-----+-----+-----+-----------+

# COMMAND ----------



# COMMAND ----------

daniel = df_salario.groupBy(col('VL_DIAS_MENORES_15_CALC')).count()

# COMMAND ----------

daniel.display()

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pyspark
 
# importing sparksessio
from pyspark.sql import SparkSession
 
# creating a sparksession object
# and providing appName
spark = SparkSession.builder.appName("pyspark_window").getOrCreate()
 
# sample data for dataframe
sampleData = (
  (2018, 28, 785),
  (2018, 33, 234),
  (2018, 40, 457),
  (2015, 25, 986),
  (2015, 29, 124),
  (2015, 46, 365),
  (2014, 26, 697),
  (2014, 30, 789),
  (2014, 29, 369),
  (2014, 39, 789)
)
 
  
# column names for dataframe
columns = ["DATA", "CNAE", "ABS"]
 
# creating the dataframe df
df = spark.createDataFrame(data=sampleData,
                           schema=columns)
df.display()

# COMMAND ----------

# importing Window from pyspark.sql.window
 
# creating a window
# partition of dataframe
windowPartition = Window.partitionBy("DATA").orderBy(desc("ABS"))
 


# COMMAND ----------

windowPartition = Window.partitionBy("DATA").orderBy(desc("ABS"))
# show df
df.select('*', rank().over(windowPartition).alias('rank')).filter(col('rank') <= 5).show()

# COMMAND ----------

# MAGIC %r
# MAGIC
# MAGIC library(pracma)
# MAGIC clear()
# MAGIC library(readxl)
# MAGIC Dados <- read_excel("C:/Users/RCQ/Desktop/2021/Danilo_Markov/Programas/Renata/Quali/Primeira_Versão/04022022/Curso_CNI/Curso_Material/Dados.xlsx")
# MAGIC Dados=data.frame(Dados)
# MAGIC Resultado=matrix(0,15,6)
# MAGIC
# MAGIC YX=matrix(0,20,4)
# MAGIC
# MAGIC YX[,1]=Dados[,1]
# MAGIC YX[,2]=Dados[,2]
# MAGIC YX[,3]=ones(20,1)
# MAGIC k=1
# MAGIC
# MAGIC for (i in 4:17){
# MAGIC YX[1:i,3]=0
# MAGIC YX[,4]=YX[,2]*YX[,3]
# MAGIC A=lm(YX[,1]~YX[,2]+YX[,3]+YX[,4])
# MAGIC B=summary(A)
# MAGIC C=B$r.squared
# MAGIC Resultado[k,1]=C
# MAGIC Resultado[k,2]=A$coefficients[1]
# MAGIC Resultado[k,3]=A$coefficients[2]
# MAGIC Resultado[k,4]=A$coefficients[3]
# MAGIC Resultado[k,5]=A$coefficients[4]
# MAGIC Resultado[k,6]=i+1
# MAGIC k=k+1
# MAGIC }
# MAGIC
# MAGIC A1=lm(YX[,1]~YX[,2])
# MAGIC B1=summary(A)
# MAGIC C1=B1$r.squared
# MAGIC Resultado[15,1]=C1
# MAGIC Resultado[15,2]=A1$coefficients[1]
# MAGIC Resultado[15,3]=A1$coefficients[2]
# MAGIC Resultado[15,4]=0
# MAGIC Resultado[15,5]=0
# MAGIC Resultado[15,6]=0
# MAGIC
# MAGIC Resultado=sortrows(Resultado,1)
# MAGIC Nomes=c("R2","Inter","X","D","X*D","Posi_D")
# MAGIC colnames(Resultado)<-Nomes
# MAGIC
# MAGIC Previ<-matrix(0,20,3)
# MAGIC
# MAGIC Previ[,1]=1:20
# MAGIC Previ[,2]=Dados[,1]
# MAGIC YX[,3]=ones(20,1)
# MAGIC x=Resultado[15,6]
# MAGIC YX[1:x,3]=0
# MAGIC YX[,4]=YX[,3]*Dados[,2]
# MAGIC
# MAGIC
# MAGIC Previ[,3]=Resultado[15,2]+Resultado[15,3]*Dados[,2]+
# MAGIC   Resultado[15,4]*YX[,3]+Resultado[15,5]*YX[,4]
# MAGIC
# MAGIC plot(Previ[,1],Previ[,2],col="red",type="b")
# MAGIC par(new=T)
# MAGIC plot(Previ[,1],Previ[,3],col="blue")

# COMMAND ----------

 Dados = ANO_2008_2018.select('INDICE_ABSENTEÍSMO', 'ANO')

# COMMAND ----------

# MAGIC %r
# MAGIC
# MAGIC Dados=data.frame(Dados)
# MAGIC Dados$INDICE_ABSENTEÍSMO = as.numeric(Dados$INDICE_ABSENTEÍSMO)
# MAGIC Resultado=matrix(0,15,6)
# MAGIC YX=matrix(0,16,4)
# MAGIC YX[,1]=Dados[,1]
# MAGIC YX[,2]=Dados[,2]
# MAGIC YX[,3]=ones(16,1)
# MAGIC k=1
# MAGIC for (i in 4:17){
# MAGIC YX[1:i,3]=0
# MAGIC YX[,4]=YX[,2]*YX[,3]
# MAGIC A=lm(YX[,1]~YX[,2]+YX[,3]+YX[,4])
# MAGIC B=summary(A)
# MAGIC C=B$r.squared
# MAGIC Resultado[k,1]=C
# MAGIC Resultado[k,2]=A$coefficients[1]
# MAGIC Resultado[k,3]=A$coefficients[2]
# MAGIC Resultado[k,4]=A$coefficients[3]
# MAGIC Resultado[k,5]=A$coefficients[4]
# MAGIC Resultado[k,6]=i+1
# MAGIC k=k+1
# MAGIC }
# MAGIC A1=lm(YX[,1]~YX[,2])
# MAGIC B1=summary(A)
# MAGIC C1=B1$r.squared
# MAGIC Resultado[15,1]=C1
# MAGIC Resultado[15,2]=A1$coefficients[1]
# MAGIC Resultado[15,3]=A1$coefficients[2]
# MAGIC Resultado[15,4]=0
# MAGIC Resultado[15,5]=0
# MAGIC Resultado[15,6]=0
# MAGIC Resultado=sortrows(Resultado,1)
# MAGIC Nomes=c("R2","Inter","X","D","X*D","Posi_D")
# MAGIC colnames(Resultado)<-Nomes
# MAGIC Previ<-matrix(0,16,3)
# MAGIC Previ[,1]=1:16
# MAGIC Previ[,2]=Dados[,1]
# MAGIC YX[,3]=ones(16,1)
# MAGIC x=Resultado[15,6]
# MAGIC YX[1:x,3]=0
# MAGIC YX[,4]=YX[,3]*Dados[,2]
# MAGIC Previ[,3]=Resultado[15,2]+Resultado[15,3]*Dados[,2]+
# MAGIC   Resultado[15,4]*YX[,3]+Resultado[15,5]*YX[,4]
# MAGIC plot(Previ[,1],Previ[,2],col="red",type="b")
# MAGIC par(new=T)
# MAGIC plot(Previ[,1],Previ[,3],col="blue")
# MAGIC resultados = data.frame(Previ)
# MAGIC resultados$X1 = Dados$ANO
# MAGIC names(resultados) = c('Ano', 'Absenteismo', 'Abs_Proj')