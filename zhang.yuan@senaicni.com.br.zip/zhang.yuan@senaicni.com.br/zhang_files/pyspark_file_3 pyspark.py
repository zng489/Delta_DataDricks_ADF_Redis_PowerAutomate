# Databricks notebook source
dbutils.notebook.run("DataBricks WorkFlows", 0, {"p_data_source":"Ergast API"})

# COMMAND ----------

v_result = dbutils.notebook.run("DataBricks WorkFlows", 0, {"p_data_source":"Ergast API"})

# COMMAND ----------

