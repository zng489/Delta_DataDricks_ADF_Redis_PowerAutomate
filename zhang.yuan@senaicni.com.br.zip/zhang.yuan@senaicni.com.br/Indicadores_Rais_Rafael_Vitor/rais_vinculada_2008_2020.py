# Databricks notebook source
# MAGIC  %run ./../pyspark_read

# COMMAND ----------

ONI.DADOS('/trs/me/rais_vinculo_publica','parquet',',').display()

# COMMAND ----------

ONI.DADOS('/trs/me/rais_vinculo_publica','parquet',',').printSchema()

# COMMAND ----------

# Creating tables!!

Table_Rais_2008_2020 = ONI.DADOS('/trs/me/rais_vinculo_publica','parquet',',')
Table_Rais_2008_2020.createOrReplaceTempView('df')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --DROP TABLE new_table
# MAGIC DROP TABLE IF EXISTS rais_vinculada_2008_2020;
# MAGIC CREATE TABLE rais_vinculada_2008_2020 AS 
# MAGIC (
# MAGIC SELECT ANO, CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO, CD_TIPO_VINCULO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT,
# MAGIC   CASE 
# MAGIC     WHEN VL_IDADE <= 18 THEN '<= 18'
# MAGIC     WHEN (18 <= VL_IDADE AND VL_IDADE <= 24) THEN '18-24'
# MAGIC     WHEN (25 <= VL_IDADE AND VL_IDADE <= 39) THEN '25-39'
# MAGIC     WHEN (40 <= VL_IDADE AND VL_IDADE <= 59) THEN '40-59'
# MAGIC    ELSE '> ou = 60 '
# MAGIC   END AS FAIXA_ETARIA
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY ANO, CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO, CD_TIPO_VINCULO
# MAGIC );
# MAGIC
# MAGIC --SELECT CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO, CD_TIPO_VINCULO, CD_SEXO_IDENT, FAIXA_ETARIA FROM rais_vinculada_2008_2020

# COMMAND ----------

# Reading SQL table as parquet file

DF = spark.table("""rais_vinculada_2008_2020""")

# COMMAND ----------

DF.write.format("parquet").mode("overwrite").saveAsTable("mapa_da_saude.f_rais_perfil")

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_UF, CD_SEXO_IDENT, FAIXA_ETARIA, COUNT(CD_SEXO_IDENT) AS CONTAGEM_SEXO
# MAGIC FROM rais_vinculada_2008_2020
# MAGIC GROUP BY CD_UF, CD_SEXO_IDENT, FAIXA_ETARIA;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO, CD_TIPO_VINCULO, CD_SEXO_IDENT, FAIXA_ETARIA, COUNT(DISTINCT CD_SEXO_IDENT) AS CONTAGEM_SEXO
# MAGIC FROM rais_vinculada_2008_2020
# MAGIC GROUP BY CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO, CD_TIPO_VINCULO, CD_SEXO_IDENT, FAIXA_ETARIA;
# MAGIC
# MAGIC -- SELECT Town, (SELECT Count(*) FROM User) `Count` FROM user GROUP BY Town;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_SEXO, CD_RACA_COR, VL_IDADE
# MAGIC   --case when vacina_numdose in ('1','2','38','37','9','8') then 1 else 0 end) as "qtvac"
# MAGIC     -- case when CD_SEXO = 02 then 50 else 100 end as GENERO
# MAGIC     ---case when GENERO = 'Homem' then 50 else 100 end as SOMA_GENERO
# MAGIC FROM rais_vinculada_2008_2020
# MAGIC -- WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_SEXO, CD_RACA_COR, VL_IDADE;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_MUNICIPIO, FL_VINCULO_ATIVO_3112, CD_SEXO, CD_RACA_COR, VL_IDADE,
# MAGIC   --case when vacina_numdose in ('1','2','38','37','9','8') then 1 else 0 end) as "qtvac"
# MAGIC     case when CD_SEXO = 02 then 50 else 100 end as GENERO
# MAGIC     ---case when GENERO = 'Homem' then 50 else 100 end as SOMA_GENERO
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1';
# MAGIC --GROUP BY CD_SEXO;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_SEXO, CD_MUNICIPIO, COUNT(CD_SEXO) as Contagem, COUNT(CD_MUNICIPIO) as Contagem_MUNICIPIO
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_SEXO,CD_MUNICIPIO;
# MAGIC
# MAGIC --https://www.youtube.com/watch?v=nNrgRVIzeHg&ab_channel=BecomingaDataScientist

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_SEXO, CD_MUNICIPIO, COUNT(CD_SEXO) as Contagem, COUNT(CD_MUNICIPIO) as Contagem_MUNICIPIO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 100
# MAGIC     ELSE 2000
# MAGIC   END AS CD_SEXO_NOVA  
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_SEXO,CD_MUNICIPIO;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_SEXO, CD_MUNICIPIO, COUNT(CD_SEXO) as Contagem, COUNT(CD_MUNICIPIO) as Contagem_MUNICIPIO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 100
# MAGIC     ELSE 2000
# MAGIC   END AS CD_SEXO_NOVA  
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_SEXO,CD_MUNICIPIO;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_SEXO, CD_MUNICIPIO, COUNT(CD_SEXO) as Contagem, COUNT(CD_MUNICIPIO) as Contagem_MUNICIPIO,
# MAGIC   CASE 
# MAGIC     WHEN SUM(CD_SEXO) = 01 THEN 100
# MAGIC     ELSE 2000
# MAGIC   END AS CD_SEXO_NOVA  
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_SEXO,CD_MUNICIPIO;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_SEXO, CD_MUNICIPIO, COUNT(CD_SEXO) as Contagem, COUNT(CD_MUNICIPIO) as Contagem_MUNICIPIO,
# MAGIC   SUM(CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 100
# MAGIC     ELSE 2000
# MAGIC   END) AS CD_SEXO_NOVA  
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_SEXO,CD_MUNICIPIO;

# COMMAND ----------

# MAGIC %md
# MAGIC SELECT 
# MAGIC     YEAR(orderDate) AS year,
# MAGIC     SUM(quantityOrdered * priceEach) AS total
# MAGIC FROM
# MAGIC     orders
# MAGIC INNER JOIN orderdetails 
# MAGIC     USING (orderNumber)
# MAGIC WHERE
# MAGIC     status = 'Shipped'
# MAGIC GROUP BY 
# MAGIC     year
# MAGIC HAVING 
# MAGIC     year > 2003;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_MUNICIPIO, CD_TIPO_VINCULO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_CNAE20_DIVISAO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1';

# COMMAND ----------

#################
#################
#################
#################


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT CD_MUNICIPIO, CD_TIPO_VINCULO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_CNAE20_DIVISAO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT,
# MAGIC   CASE 
# MAGIC     WHEN VL_IDADE < '18' THEN '< 18'
# MAGIC     WHEN '18' < VL_IDADE < '24' THEN '18-24'
# MAGIC     WHEN '18' < VL_IDADE AND VL_IDADE < '24' THEN '18-24'
# MAGIC    ELSE 'zhang'
# MAGIC   END AS FAIXA_ETARIA
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1';

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT CD_MUNICIPIO, CD_TIPO_VINCULO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_CNAE20_DIVISAO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT,
# MAGIC   CASE 
# MAGIC     WHEN VL_IDADE < '18' THEN '< 18'
# MAGIC     WHEN '18' < VL_IDADE < '24' THEN '18-24'
# MAGIC    ELSE 'zhang'
# MAGIC   END AS FAIXA_ETARIA
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1';

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT CD_MUNICIPIO, CD_TIPO_VINCULO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_CNAE20_DIVISAO, COUNT(CD_SEXO) AS CONTAGEM_SEXO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT,
# MAGIC   CASE 
# MAGIC     WHEN VL_IDADE < '18' THEN '< 18'
# MAGIC     WHEN (18 < VL_IDADE AND VL_IDADE < 24) THEN '18-24'
# MAGIC     WHEN (25 < VL_IDADE AND VL_IDADE < 39) THEN '25-39'
# MAGIC     WHEN (40 < VL_IDADE AND VL_IDADE < 59) THEN '18-24'
# MAGIC    ELSE '> ou = 60 '
# MAGIC   END AS FAIXA_ETARIA
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_MUNICIPIO, CD_TIPO_VINCULO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_CNAE20_DIVISAO;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO,  CD_TIPO_VINCULO, COUNT(CD_SEXO) AS CONTAGEM_SEXO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT,
# MAGIC   CASE 
# MAGIC     WHEN VL_IDADE < '18' THEN '< 18'
# MAGIC     WHEN '18' < VL_IDADE < '24' THEN '18-24'
# MAGIC     WHEN '18' < VL_IDADE AND VL_IDADE < '24' THEN '18-24'
# MAGIC     WHEN '25' < VL_IDADE AND VL_IDADE < '39' THEN '25-39'
# MAGIC     WHEN '40' < VL_IDADE AND VL_IDADE < '59' THEN '18-24'
# MAGIC    ELSE '> ou = 60 '
# MAGIC   END AS FAIXA_ETARIA
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO, CD_TIPO_VINCULO;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE new_table
# MAGIC CREATE TABLE new_table
# MAGIC   AS (SELECT CD_MUNICIPIO, CD_TIPO_VINCULO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_CNAE20_DIVISAO, COUNT(CD_SEXO) AS CONTAGEM_SEXO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT,
# MAGIC   CASE 
# MAGIC     WHEN VL_IDADE < '18' THEN '< 18'
# MAGIC     WHEN '18' < VL_IDADE < '24' THEN '18-24'
# MAGIC     WHEN '18' < VL_IDADE AND VL_IDADE < '24' THEN '18-24'
# MAGIC     WHEN '25' < VL_IDADE AND VL_IDADE < '39' THEN '25-39'
# MAGIC     WHEN '40' < VL_IDADE AND VL_IDADE < '59' THEN '18-24'
# MAGIC    ELSE '> ou = 60 '
# MAGIC   END AS FAIXA_ETARIA
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_MUNICIPIO, CD_TIPO_VINCULO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_CNAE20_DIVISAO);

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE new_table

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE new_table
# MAGIC   AS (SELECT CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO,  CD_TIPO_VINCULO,
# MAGIC   CASE 
# MAGIC     WHEN CD_SEXO = 01 THEN 'H'
# MAGIC     WHEN CD_SEXO = 02 THEN 'M'
# MAGIC    ELSE 'NI'
# MAGIC   END AS CD_SEXO_IDENT,
# MAGIC   CASE 
# MAGIC     WHEN VL_IDADE < '18' THEN '< 18'
# MAGIC     WHEN '18' < VL_IDADE < '24' THEN '18-24'
# MAGIC     WHEN '18' < VL_IDADE AND VL_IDADE < '24' THEN '18-24'
# MAGIC     WHEN '25' < VL_IDADE AND VL_IDADE < '39' THEN '25-39'
# MAGIC     WHEN '40' < VL_IDADE AND VL_IDADE < '59' THEN '18-24'
# MAGIC    ELSE '> ou = 60 '
# MAGIC   END AS FAIXA_ETARIA
# MAGIC FROM df
# MAGIC WHERE FL_VINCULO_ATIVO_3112 = '1'
# MAGIC GROUP BY CD_UF, CD_CNAE20_DIVISAO, CD_SEXO, CD_RACA_COR, VL_IDADE, CD_GRAU_INSTRUCAO,  CD_TIPO_VINCULO);

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC -- Join
# MAGIC
# MAGIC --DROP TABLE new_table
# MAGIC DROP TABLE IF EXISTS tabela_A;
# MAGIC CREATE TABLE tabela_A AS 
# MAGIC (
# MAGIC SELECT ANO, CD_UF, CD_CNAE20_DIVISAO
# MAGIC FROM rais_vinculada_2008_2020
# MAGIC );
# MAGIC
# MAGIC
# MAGIC DROP TABLE IF EXISTS tabela_B;
# MAGIC CREATE TABLE tabela_B AS 
# MAGIC (
# MAGIC SELECT ANO, CD_SEXO, CD_RACA_COR
# MAGIC FROM rais_vinculada_2008_2020
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM tabela_A

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM tabela_B

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT tabela_B.ANO FROM tabela_B

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT tabela_A.ANO, tabela_B.ANO
# MAGIC FROM tabela_A --as A
# MAGIC LEFT JOIN tabela_B --as B
# MAGIC                 on tabela_A.ANO = tabela_B.ANO;

# COMMAND ----------

SELECT table1.column1,table1.column2,table2.column1,....
FROM table1 
INNER JOIN table2
ON table1.matching_column = table2.matching_column;

# COMMAND ----------

# Para o painel de historia dos Estados, mas detalhando por municipio
bucket_municipio_semana_vacina = """SELECT 
    case DATE_CMP(vacina_dataaplicacao, current_date)
        when 1 then dateadd(day,-1,date_trunc('week', current_date))
        else
            case DATE_CMP(vacina_dataaplicacao, TO_DATE('2021-01-17', 'YYYY-MM-DD'))
                when 1 then dateadd(day,-1,date_trunc('week', vacina_dataaplicacao)) 
                else dateadd(day,-1, date_trunc('week', TO_DATE('2021-01-17', 'YYYY-MM-DD'))) 
            end
        end	as "semanavac"
    ,date_part(month, vacina_dataaplicacao) as mes
    ,estabelecimento_uf as uf
    ,estabelecimento_municipio_codigo
    ,estabelecimento_municipio_nome
    ,vacina_codigo
    ,count(*) as qtvac_com_descartes
    ,sum(case when vacina_numdose in ('1','2','38','37','9','8') then 1 else 0 end) as "qtvac"
    ,sum(case when vacina_numdose='1' and vacina_codigo!='88' then 1 else 0 end) as "qtvac1"
    ,sum(case when vacina_numdose='2' and vacina_codigo!='88' then 1 else 0 end) as "qtvac2"
    ,sum(case when vacina_numdose='38' then 1 else 0 end) as "qtvac3"
    ,sum(case when vacina_numdose='37' then 1 else 0 end) as "qtvac4"
    ,sum(case when (vacina_codigo='88' and vacina_numdose in ('1','2','9','8')) or (vacina_codigo!='88' and vacina_numdose in ('9','8')) then 1 else 0 end) as qtvacunica
    ,sum(case when (left(right(regexp_replace(vacina_descricao_dose,'[^[:print:]]|[[:cntrl:]]|[[:blank:]]',''),7),1)='R' or left(right(regexp_replace(vacina_descricao_dose,'[^[:print:]]|[[:cntrl:]]|[[:blank:]]',''),7),1)='i') and (paciente_idade < 60) and vacina_categoria_nome='Faixa Etária' Then 1 else 0 end) as "qtdadr_menor60"
FROM dbbni.tb_vacinometro
WHERE status = 'final'
group by uf, estabelecimento_municipio_codigo, estabelecimento_municipio_nome, semanavac, mes, vacina_codigo"""