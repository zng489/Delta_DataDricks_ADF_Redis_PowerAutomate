# Databricks notebook source
from pyspark.sql.window import Window
import pyspark.sql.functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import datediff,col,when,greatest

var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = '{uri}/tmp/dev/lnd/crw/ibge__pintec_tipo_inov_proj_po/2008/'.format(uri=var_adls_uri)
df = spark.read.format("parquet").option("header","true").load(path)
#
df.display()
df.columns

# COMMAND ----------

len(df.columns)

# COMMAND ----------



# COMMAND ----------

  df.columns

# COMMAND ----------

from pyspark.sql.window import Window
import pyspark.sql.functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import datediff,col,when,greatest

var_adls_uri = 'abfss://datalake@cnibigdatadlsgen2.dfs.core.windows.net'
path = '{uri}/tmp/dev/lnd/crw/ibge__pintec_tipo_inov_proj_po/2017/'.format(uri=var_adls_uri)
df = spark.read.format("parquet").option("header","true").load(path)
#
df.display()

# COMMAND ----------

/tmp/dev/lnd/crw/ibge__pintec_tipo_inov_proj_po/2014/

# COMMAND ----------

/tmp/dev/lnd/crw/ibge__pintec_tipo_inov_proj_po/2011/

# COMMAND ----------

/tmp/dev/lnd/crw/ibge__pintec_tipo_inov_proj_po/2008/

# COMMAND ----------

